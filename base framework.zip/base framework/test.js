/* 

	base framework 
	
	This is a mini javascript framework to allow complex  
	functions to work in many browsers and versions. 
	
	The framework can also be extended to add additional 
	functionality. 
	
*/ 

(function(global) 
{ 
	"use strict"; 
	
	/* this will check to stop setup if already setup */ 
	if(global.base) 
	{ 
		return false; 
	}
	
	/* 
		base framework constructor
		
		This will set all settings of the base framework and 
		allow all modules to be extended from the base 
		prototype. 
	*/ 
	var Base = function() 
	{ 
		this.version = '2.0.0';
		this.errors = [];
	}; 
	
	/* we want to add the intial methods to the 
	base framework as prototypes so they can be inherited */ 
	Base.prototype = { 
	
		constructor: Base, 
		
		/* this will augement the base framework 
        with new functionality
        @param (object) settings = the new functionality
		@return (object) an instance of the object */
        augment: function(settings)
        {   
			if(!settings || typeof settings !== 'object')
			{ 
				return this; 
			}
				
			var prototype = this.constructor.prototype; 
			for(var property in settings) 
			{ 
				if(settings.hasOwnProperty(property)) 
				{ 
					prototype[property] = settings[property]; 
				} 
			}
            return this;  
        }
	}; 
	
	/* this will create an auto initializing function to return 
	the base framework prototype to allow new modules to be 
	added
	@return (object) the base prototype */
	Base.prototype.extend = (function()
	{
		return Base.prototype; 
	})(); 
	
	/* we need to create a new instance of the base framework, 
	save it to the global object. shorthand and long name */  
	var base = global._b = global.base = new Base();
	
	/* this will add the object creating and extending methods 
	to allow classes to be created in es5 */ 
	base.augment(
	{ 
		/* this will convert a nodelist into an array. 
		@param (nodeList) list = the list to convert 
		@return (array) */ 
		listToArray: function(list) 
		{ 
			return Array.prototype.slice.call(list); 
		},
		
		/* this will override a method function with a new method
		@param (object) obj = the obj that the method belongs to
		@param (string) methodName 
		@param (function) overrideMethod = the new method 
		@param (collection) args = the orginal method args 
		@return (function) the curried function */
		overrideMethod: function(obj, methodName, overrideMethod, args)
		{ 
			return (obj[methodName] = overrideMethod).apply(obj, this.listToArray(args)); 
		}, 
		
		/* this will return a new object and extend it if an object it supplied. 
		@param [(object)] object = the extending object 
		@return (object) this will return a new object with the 
		inherited object */ 
		createObject: function(object) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var createObject;  
			if(typeof Object.create === 'function') 
			{ 
				// modern browsers 
				createObject = function(object) 
				{ 
					return Object.create(object); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				createObject = function(object) 
				{ 
					var obj = function(){}; 
					obj.prototype = object;
					return new obj();   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'createObject', createObject, arguments); 
		}, 
		
		/* this will extend an object and return the extedned 
		object or false.  
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		extendObject: function(sourceObj, targetObj) 
		{ 
			if(typeof sourceObj === 'undefined' || typeof targetObj === 'undefined') 
			{ 
				return false; 
			}
				 
			for(var property in sourceObj) 
			{ 
				if(sourceObj.hasOwnProperty(property) && typeof targetObj[property] === 'undefined') 
				{ 
					targetObj[property] = sourceObj[property]; 
				} 
			} 

			return targetObj; 
		}, 
		
		_getClassObject: function(object)
		{
			return (typeof object === 'function')? object.prototype : object; 
		}, 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (mixed) sourceClass = the original (class function 
		constructor or class prototype) unextended 
		@param (mixed) addingClass = the (class function constructor
		or class prototype) to add to the original */ 
		extendClass: function(sourceClass, targetClass) 
		{ 
			/* if we are using a class constructor function 
			we want to get the class prototype object */  
			var source = this._getClassObject(sourceClass), 
			target = this._getClassObject(targetClass);			
			
			if(typeof source !== 'object' || typeof target !== 'object') 
			{ 
				return false;  
			} 
			
			/* we want to create a new object and add the source 
			prototype to the new object */ 
			var obj = this.createObject(source); 

			/* we need to add any settings from the source that 
			are not on the prototype */ 
			this.extendObject(source, obj); 

			/* we want to add any additional properties from the 
			target class to the new object */ 
			for(var prop in target) 
			{ 
				obj[prop] = target[prop]; 
			} 

			return obj;
		}
	}); 
	
	/* 
		Class 
		
		this will allow classes to be extend 
		from a calss single factory. this makes 
		classes in es5 including calling super 
		methods and extending to child classes. 
		
	*/ 
	var Class = function() 
	{ 
		
	}; 
	
	Class.prototype =  
	{ 
		constructor: Class, 
		
		/* this is an alias for callParent. this will 
		allow child classes to call super methods. 
		@param (string) method name 
		@param [(mixed)] addasmany args as the super 
		method needs 
		@return (mixed) the super method return value */
		super: function()
		{ 
			var parent = this.parent; 
			if(!parent)
			{ 
				return false; 
			}
				 
			var args = base.listToArray(arguments), 
					
			// this will remove the first arg as the method
			method = args.shift(); 
			if(!method)
			{ 
				return false;  
			}
			
			var func = parent[method]; 
			if(typeof func === 'function')
			{ 
				return func.apply(this, args);
			}
		}
	}; 

	/* this will allow the classes to be extened. 
	@param (object) child = the child object to extend 
	@return (mixed) the new child prototype or false */ 
	Class.extend = function(child)
	{  
		if(!child)
		{ 
			return false; 
		} 
		
		var parent = this.prototype; 
		
		/* the child constructor must be set to set 
		the parent static methods on the child */ 
		var constructor = child.constructor || false; 
		if(child.hasOwnProperty('constructor') === false)
		{ 
			constructor = function()
			{
				var args = base.listToArray(arguments); 
				parent.constructor.apply(this, args); 
			}; 
		} 
			
		/* this will add the parent class to the 
		child class */ 
		var prototype = constructor.prototype = base.extendClass(parent, child); 
		prototype.parent = parent;

		/* this will add the static methods from the parent to 
		the child constructor. */ 
		base.extendObject(this, constructor); 
		return constructor; 
	}; 
	
	/* this will add a reference to the Class 
	object */ 
	base.extend.Class = Class;
	
	/* 
		DataTracker 
		
		this will add data tracking to allow tracking types 
		to be registered and allow data to be tracked to an object. 
	*/ 
	var TrackerTypes = 
	{
		types: {}, 
		
		add: function(type, callBack)
		{
			this.types[type] = callBack; 
		}, 
		
		get: function(type)
		{
			return this.types[type] || false; 
		}, 
		
		remove: function(type)
		{
			delete this.types[type]; 
		}
	}; 
	
	var Tracker = base.Class.extend(
	{
		constructor: function() 
		{  
			this.types = {};  
		}, 
		
		add: function(addingType, data)
		{
			var type = this.types[addingType] || (this.types[addingType] = []); 
			type.push(data);  
		}, 
		
		get: function(type)
		{
			return this.types[type] || false; 
		}, 
		
		removeByCallBack: function(callBack, data)
		{
			if(typeof callBack === 'function')
			{
				callBack(data); 
			}
		}, 
		
		removeType: function(removingType)
		{
			var types = this.types; 
			var type = types[removingType];
			if(type.length)
			{
				var callBack = TrackerTypes.get(removingType);
				for(var i = 0, length = type.length; i < length; i++)
				{
					var data = type[i]; 
					if(data)
					{
						// this will stop any circular referrences
						type[i] = null; 
						
						this.removeByCallBack(callBack, data); 
					}
				}
				delete types[type]; 
			}
		}, 
		
		remove: function(type)
		{
		 	if(type)
			{
				this.removeType(type); 
			} 
			else 
			{
				var types = this.types; 
				for(var prop in types)
				{ 
					if(types.hasOwnProperty(prop))
					{
						type = types[prop];
						if(!type)
						{
							continue; 
						}

						this.removeType(prop);
					} 
				}

				delete this.types;
			}
		}
	}); 
	
	var DataTracker = base.Class.extend(
	{ 
		constructor: function() 
		{  
			this.trackers = {};  
			this.trackingCount = 0; 
		},  
		
		addType: function(type, callBack)
		{
			TrackerTypes.add(type, callBack); 
		}, 
		
		removeType: function(type)
		{
			TrackerTypes.remove(type); 
		}, 
		
		getTrackingId: function(obj)
		{
			return obj.trackingId || (obj.trackingId = 'dt' + this.trackingCount++); 
		}, 
		
		add: function(obj, type, data)
		{
			var id = this.getTrackingId(obj); 
			var tracker = this.find(id); 
 
			tracker.add(type, data); 
		}, 
		
		get: function(obj, type)
		{
			var id = obj.trackingId; 
			var tracker = this.trackers[id]; 
			if(!tracker)
			{
				return false;  
			}
			
			return (type)? tracker.get(type) : tracker;
		}, 
		
		find: function(id)
		{
			var trackers = this.trackers; 
			return (trackers[id] || (trackers[id] = new Tracker()));
		}, 
		
		remove: function(obj, type)
		{
			var id = obj.trackingId;
			if(!id)
			{
				return true; 
			} 
			
			var tracker = this.trackers[id]; 
			if(!tracker)
			{
				return false; 
			}
				
			if(type)
			{
				tracker.remove(type); 

				/* this will remove the msg from the elements 
				if no elements are listed under the msg */ 
				if(base.isEmpty(tracker.types))
				{
					delete this.trackers[id]; 
				}
			} 
			else 
			{
				tracker.remove(); 

				delete this.trackers[id];
			}
		}
	}); 
	
	base.extend.DataTracker = new DataTracker();
	 
	/* we want to add additional methods to the base prototype 
	so they can be inherited */ 
	base.augment(
	{ 
		/* this will get the last error 
		@return (mixed) the last error object or false if no errors */ 
		getLastError: function() 
		{ 
			var errors = this.errors; 
			return (errors.length)? errors.pop() : false; 
		},  
		
		/* this will add an error object to the base 
		error array 
		@param (object) err = the error object */ 
		addError: function(err) 
		{ 
			this.errors.push(err); 
		},
	
		/* this will parse the keys and values from
		a query string. 
		@param [(string)] str
		@return (mixed) the params object or false */ 
		parseQueryString: function(str) 
		{ 
			str = str || global.location.search; 
			var objURL = {}, 
			regExp = /([^?=&]+)(=([^&]*))?/g; 
		
			str.replace(regExp, function(a, b, c, d)
			{ 
				/* we want to save the key and the 
				value to the objURL */ 
				objURL[b] = d;
			}); 
			
			/* we want to check if the url has any params */ 
			return (this.isEmpty(objURL) === false)? objURL : false;  
		}, 
		
		/* this is an alias for parse query string and will
		@param [(string)] str
		@return (mixed) an object with the params from string
		or false on error */ 
		getParams: function(str) 
		{  
			return this.parseQueryString(str);   
		},  
		
		/* this will check if an object is empty. 
		@param (object) obj = the object to check 
		@return (bool) true or false if empty */ 
		isEmpty: function(obj) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return true; 
			}
				 
			/* we want to loop through each property and 
			check if it belongs to the object directly */ 
			for(var key in obj) 
			{
				if(obj.hasOwnProperty(key)) 
				{ 
					return false;
				} 
			}
			return true;
		}, 
		
		/* this will select an html element by id. 
		@param (string) id = the id of the element 
		@return (mixed) the element or false on error */ 
		getById: function(id) 
		{ 
			if(typeof id !== 'string') 
			{ 
				return false;  
			} 
			var obj = document.getElementById(id);  
			return (obj || false); 
		}, 
		
		/* this will select html elements by name and return 
		a list. 
		@param (string) name = the name of the elements 
		@return (mixed) the elements array or false on error */ 
		getByName: function(name) 
		{ 
			if(typeof name !== 'string') 
			{ 
				return false; 
			} 
			var obj = document.getElementsByName(name);  
			return (obj)? this.listToArray(obj) : false; 
		}, 
		
		/* this will select html elements by css selector. 
		@param (string) name = the name of the elements
		@param [(int)] single = setup to only select the 
		first element 
		@return (mixed) the element or false on error */ 
		getBySelector: function(selector, single) 
		{ 
			if(typeof selector !== 'string') 
			{ 
				return false;  
			} 
			
			/* we want to check if we are only selecting 
			the first element or all elements */ 
			single = single || false; 
			if(single === true) 
			{ 
				var obj = document.querySelector(selector); 
				return (obj || false);
			} 
			else 
			{ 
				var elements = document.querySelectorAll(selector);  
				if(elements) 
				{ 
					/* if there is only one result just return the 
					first element in the node list */ 
					return (elements.length === 1)? elements[0] : this.listToArray(elements);  
				} 
				return false; 
			} 
		}, 
		
		/* this will either set the innerHTML of an object or 
		return the innerHTML of an element.
		@param object obj = the object to use  
		@param [(string)] html = the html to insert
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		html is being accessed the html will be returned */
		html: function(obj, html) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				 return false; 
			}  
			
			/* we want to check if we are getting the 
			html or adding the html */ 
			if(typeof html !== 'undefined') 
			{ 
				/* we want to check to set the value */ 
				obj.innerHTML = html; 
				return this; 
			} 
			else 
			{ 
				return obj.innerHTML; 
			}
		}, 
		
		setCss: function(obj, property, value) 
		{
			if(!obj || typeof obj !== 'object' || typeof property === 'undefined')
			{
				return this; 
			}
			
			property = this.uncamelCase(property); 
			obj.style[property] = value;
			return this; 
		}, 
		
		getCss: function(obj, property)
		{
			if(!obj || typeof property === 'undefined')
			{
				return false; 
			}
			
			property = this.uncamelCase(property);
			var css = obj.style[property]; 
			if(css === '') 
			{ 
				return css; 
			} 
			
			/* we want to check if we have an inherited 
			value */ 
			var currentValue = null; 
			var currentStyle = obj.currentStyle; 
			if(currentStyle && (currentValue = currentStyle[property]))
			{ 
				css = currentValue; 
			}
			else 
			{ 
				var inheritedStyle = window.getComputedStyle(obj, null); 
				if(inheritedStyle)
				{ 
					css = inheritedStyle[property];
				}
			}
			
			return css;
		}, 
		
		/* this will either set the css style value 
		to an object or return the value of the style property.
		@param object obj = the object to use 
		@param (string) property = the css property name 
		@param [0ptional](string) value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		css: function(obj, property, value) 
		{ 
			/* we want to check if we are getting the 
			value or setting the value */ 
			if(typeof value !== 'undefined') 
			{ 
				this.setCss(obj, property, value);   

				return this; 
			} 
			else 
			{ 
				return this.getCss(obj, property);  
			}  
		}, 
		
		/* this will setup the removeAttr function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_removeAttr: function() 
		{ 
			var removeAttr;  
			if(typeof document.documentElement.removeAttribute === 'function') 
			{ 
				removeAttr = function(obj, property) 
				{ 
					obj.removeAttribute(property); 
				}; 
			} 
			else 
			{ 
				removeAttr = function(obj, property) 
				{ 
					/* we cannot remove the attr through the remove 
					attr method so we want to null the value. 
					we want to camel caps the propety */ 
					property = base.camelCase(property); 
					obj.property = null; 
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_removeAttr', removeAttr, arguments);
		}, 
		
		/* this will remove the attribute of an object
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@return (object) a reference to the base object 
		to allow chaining */
		removeAttr: function(obj, property) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 	
				/* we want to check to set the value */ 
				this._removeAttr(obj, property);
			} 
			return this;   
		}, 
		
		/* this will setup the attr function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		setAttr: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var setAttr;  
			if(typeof document.documentElement.setAttribute === 'function') 
			{ 
				// modern browsers 
				setAttr = function(obj, property, value) 
				{ 
					obj.setAttribute(property, value); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				setAttr = function(obj, property, value) 
				{ 
					obj[property] = value;   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'setAttr', setAttr, arguments);
		}, 
		
		/* this will setup the getAttr function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		getAttr: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var getAttr;  
			if(typeof document.documentElement.getAttribute === 'function') 
			{ 
				// modern browsers 
				getAttr = function(obj, property) 
				{ 
					return obj.getAttribute(property); 
				};
			} 
			else 
			{ 
				// old browsers 
				getAttr = function(obj, property) 
				{ 
					return obj[property]; 
				};
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'getAttr', getAttr, arguments);
		},
		
		/* this will either set the attribute and value 
		to an object or return the value of an attribute.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [(string)] value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		attr: function(obj, property, value) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return false;  
			} 
			
			/* we want to check if we are getting the 
			value or setting the value */ 
			if(typeof value !== 'undefined') 
			{ 
				/* we want to check to set the value */ 
				this.setAttr(obj, property, value); 

				return this; 
			} 
			else 
			{ 
				return this.getAttr(obj, property); 
			}
		}, 
		
		_checkDataPrefix: function(prop) 
		{ 
			if(typeof prop !== 'string') 
			{ 
				return prop;   
			} 
			
			/* we want to de camelcase if set */ 
			prop = base.uncamelCase(prop); 
			if(prop.substring(0, 5) !== 'data-') 
			{ 
				prop = 'data-' + prop;   
			}

			return prop; 
		}, 
		
		_removeDataPrefix: function(prop) 
		{ 
			if(typeof prop === 'string' && prop.substring(0, 5) === 'data-') 
			{
				prop = prop.substring(5);
			} 
			return prop; 
		}, 
		
		/* this will setup the addData function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		setData: function() 
		{ 
			var self = this;
			/* create a local function to perform the check 
			once then override the function */ 
			var setData;  
			if(typeof document.documentElement.dataset !== 'undefined') 
			{ 
				// modern browsers 
				setData = function(obj, property, value) 
				{ 
					/* this will return the property without the data prefix */ 
					property = self._removeDataPrefix(property); 
					property = base.camelCase(property); 
	
					obj.dataset[property] = value; 
				}; 
			} 
			else 
			{ 
				// old browsers 
				setData = function(obj, property, value) 
				{ 
					/* we need to check the prop prefix */ 
					property = self._checkDataPrefix(property); 
					base.attr(obj, property, value);   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'setData', setData, arguments);
		}, 
		
		/* this will setup the getData function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		getData: function() 
		{ 
			var self = this;
			/* create a local function to perform the check 
			once then override the function */ 
			var getData;  
			if(typeof document.documentElement.dataset !== 'undefined') 
			{ 
				// modern browsers 
				getData = function(obj, property) 
				{ 
					property = base.camelCase(self._removeDataPrefix(property)); 
					return obj.dataset[property];  
				};
			} 
			else 
			{ 
				// old browsers 
				getData = function(obj, property) 
				{ 
					property = self._checkDataPrefix(property);
					return base.attr(obj, property); 
				};
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'getData', getData, arguments);
		},
		
		/* this will either set the data attribute and value 
		to an object or return the data value.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [(string)] value = the value to 
		add to the attribute 
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned
		*/
		data: function(obj, property, value) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return false;  
			} 
			
			if(typeof value !== 'undefined') 
			{ 
				this.setData(obj, property, value);  
				return this; 
			} 
			else 
			{ 
				/* we need to check the prop prefix */ 
				return this.getData(obj, property); 
			}
		}, 
		
		/* this will find child elements in an element.
		@param object obj = the object to use 
		@param string queryString = the query string 
		@return (mixed) a nodeList or false on error */
		find: function(obj, queryString) 
		{ 
			if(!obj || typeof queryString !== 'string') 
			{
				return false;
			}
			
			return obj.querySelectorAll(queryString); 
		}, 
		
		/* this will display an element.
		@param object obj = the object to use 
		@return (object) a referenceto the base object 
		to allow method chaining */
		show: function(obj) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this;   
			}
			
			/* we want to get the previous display style 
			from the data-style-display attr */
			var previous = this.data(obj, 'style-display'), 
			value = (typeof previous === 'string')? previous : ''; 

			this.css(obj, 'display', value); 
			return this;
		}, 
		
		/* this will hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object  
		to allow chaining */
		hide: function(obj) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this;  
			} 
			
			/* we want to set the previous display style 
			on the element as a data attr */ 
			var previous = this.css(obj, 'display'); 
			if(previous !== 'none' && previous) 
			{ 
				this.data(obj, 'style-display', previous); 
			}

			this.css(obj, 'display', 'none');
			return this; 
		}, 
		
		/* this will display or hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object 
		to allow chaining */
		toggle: function(obj) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this;  
			} 
			
			var mode = this.css(obj, 'display'); 
			if(mode !== 'none') 
			{ 
				this.hide(obj); 
			} 
			else 
			{ 
				this.show(obj); 
			}
			return this; 
		}, 
		
		/* this will camelcase a string that is separated 
		with a space, hyphen, or underscore and retun. 
		@param (string) str = the string to camelcase */ 
		camelCase: function(str) 
		{ 
			if(typeof str !== 'string') 
			{ 
				return false;  
			} 
			
			var regExp = /(-|\s|\_)+\w{1}/g; 
			return str.replace(regExp, function(match) 
			{ 
				return match[1].toUpperCase(); 
			});
		}, 
		
		/* this will uncamelcase a string and separate with a delimter 
		and retun. 
		@param (string) str = the string to camelcase
		@param [(string)] delimiter = the string delimiter */ 
		uncamelCase: function(str, delimiter) 
		{ 
			if(typeof str !== 'string') 
			{ 
				return false;  
			} 
			
			delimiter = delimiter || '-'; 
				
			var regExp = /([A-Z]{1,})/g; 
			return str.replace(regExp, function(match) 
			{ 
				return delimiter + match.toLowerCase(); 
			}).toLowerCase();
		},
		
		/* this will return an object with the width and height 
		of an object.
		@param object obj = the object to get the 
		width and height 
		@return (mixed) an object with the width and size or 
		false on error */ 
		getSize: function(obj) 
		{  
			if(!obj || typeof obj !== 'object') 
			{ 
				return false;   
			} 
			
			return {
				width: this.getWidth(obj), 
				height: this.getHeight(obj) 
			};
		},
		
		/* this will return the width of an object.
		@param object obj = the object to get the 
		width 
		@return (mixed) the width int or false on error */ 
		getWidth: function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			return (obj && typeof obj === 'object')? obj.offsetWidth : false;  
		}, 
		
		/* this will return the height of an object.
		@param object obj = the object to get the 
		height
		@return (mixed) the height int or false on error */ 
		getHeight: function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			return (obj && typeof obj === 'object')? obj.offsetHeight : false;  
		},
		
		/* this will get the scroll position of an object and 
		return an object with top and left scroll position or 
		false on error. 
		@param [(object)] obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) an object with the left and top position 
		 or false on error */ 
		getScrollPosition: function(obj) 
		{ 
			var left = 0, top = 0; 
			if(typeof obj === 'undefined') 
			{ 
				/* we want to use the document body */ 
				obj = document.documentElement;
				left = (window.pageXOffset || obj.scrollLeft);
				top = (window.pageYOffset || obj.scrollTop);  
			} 
			else if(typeof obj === 'object') 
			{ 
				left = obj.scrollLeft; 
				top = obj.scrollTop;
			}
			
			if(!obj || typeof obj !== 'object') 
			{ 
				return false;  
			}
			
			return {
				left: left - (obj.clientLeft || 0), 
				top: top - (obj.clientTop || 0)
			}; 
		}, 
		
		/* this will return the scroll top position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) the top position int or false on error */ 
		getScrollTop: function(obj) 
		{ 
			var position = this.getScrollPosition(obj); 
			return position.top;  
		}, 
		
		/* this will return the left scroll position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		*/ 
		getScrollLeft: function(obj) 
		{ 
			var position = this.getScrollPosition(obj); 
			return position.left; 
		},  
		
		/* this will get the window size and return 
		an object with the height and width */ 
		getWindowSize: function() 
		{ 
			var w = window,
			d = document,
			de = d.documentElement,
			b = d.getElementsByTagName('body')[0],
			width = w.innerWidth || de.clientWidth || b.clientWidth,
			height = w.innerHeight || de.clientHeight || b.clientHeight;  
			
			return { 
				width: width, 
				height: height 
			}; 
		}, 
		
		/* this will return the window height */ 
		getWindowHeight: function() 
		{ 
			var size = this.getWindowSize();  
			return size.height;  
		}, 
		
		/* this will return the window width */ 
		getWindowWidth: function() 
		{ 
			var size = this.getWindowSize(); 
			return size.width;  
		}, 
		
		/* this will return the document size */ 
		getDocumentSize: function() 
		{ 
			var doc = document, 
			body = doc.body,
			html = doc.documentElement;
		
			var height = Math.max(
				body.scrollHeight, 
				body.offsetHeight, 
				html.clientHeight, 
				html.scrollHeight, 
				html.offsetHeight
			); 
			
			var width = Math.max(
				body.scrollWidth, 
				body.offsetWidth, 
				html.clientWidth, 
				html.scrollWidth, 
				html.offsetWidth
			);
			
			return { 
				width: width, 
				height: height 
			}; 
		},
		
		/* this will return the document height */ 
		getDocumentHeight: function() 
		{ 
			var size = this.getDocumentSize();  
			return size.height; 
		}, 
		
		/* this is an alias for getProperty. this will check to return 
		the property value from an object or return a default value or 
		return empty string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this 
		@return (string) the object property value */ 
		getValue: function(obj, property, defaultText) 
		{ 
			return this.getProperty(obj, property, defaultText);  
		},
		
		/* this will check to return the property value from an 
		object or return a default value or return empty 
		string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this 
		@return (string) the object property value */ 
		getProperty: function(obj, property, defaultText) 
		{ 
			/* we need to check if the object is available */ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return false;  
			} 
			
			/* check if the object property has a value */ 
			var value = obj[property]; 
			if(value) 
			{ 
				/* we want to return the value */ 
				return value; 
			} 
			
			/* if no value was available 
			we want to return an empty string */ 
			return (typeof defaultText !== 'undefined')? defaultText : '';  
		},  
		
		/* this will get the offset position of an object in a parent. 
		@params object obj = the object that is requesting the offset 
		@param [(int)] depth 
		@return (object) a position object */
		position: function(obj, depth) 
		{ 
			var position = {x: 0, y: 0}; 
			
			if(!obj || typeof obj !== 'object') 
			{ 
				return position;  
			} 
			
			depth = typeof depth === 'undefined'? 1 : depth;
			
			/* if the depth is 0 we will travel to the 
			top element */ 
			var count = 0; 
			while(obj && (depth === 0 || count < depth)) 
			{ 
				count++;
				position.x += (obj.offsetLeft + obj.clientLeft);
				position.y += (obj.offsetTop + obj.clientTop);
				obj = obj.offsetParent;
			}
			
			return position; 
		}, 
		
		/* this will setup the addClass function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_addClass: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var addClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				addClass = function(obj, tmpClassName) 
				{ 
					obj.classList.add(tmpClassName); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				addClass = function(obj, tmpClassName) 
				{ 
					obj.className = obj.className + ' ' + tmpClassName;   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_addClass', addClass, arguments);
		},
		
		addClass: function(obj, tmpClassName) 
		{ 
			if(!obj || typeof obj !== 'object' || tmpClassName === '') 
			{ 
				return this;  
			} 
			
			if(typeof tmpClassName === 'string') 
			{ 
				/* we want to divide the string by spaces and 
				add any class listed */ 
				var adding = tmpClassName.split(' ');   
				for(var i = 0, maxLength = adding.length; i < maxLength; i++) 
				{ 
					this._addClass(obj, adding[i]);  
				} 
			}
			return this; 
		}, 
		
		/* this will setup the removeClass function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_removeClass: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var removeClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				removeClass = function(obj, tmpClassName) 
				{ 
					obj.classList.remove(tmpClassName); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				removeClass = function(obj, tmpClassName) 
				{ 
					/* we want to get the object classes in an array */ 
					var classNames = obj.className.split(' ');  
					
					for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
					{ 
						/* if the class matches the tmpClassName we want to remove it */ 
						if(classNames[i] === tmpClassName) 
						{ 
							classNames.splice(i, 1);  
						}
					}
				
					obj.className = classNames.join(' '); 
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_removeClass', removeClass, arguments);
		},
		
		removeClass: function(obj, tmpClassName) 
		{ 
			if(!obj || typeof obj !== 'object' || tmpClassName === '') 
			{ 
				return this; 
			} 
			
			/* if no className was specified we will remove all classes from object */ 
			if(typeof tmpClassName === 'undefined') 
			{ 
				obj.className = ''; 
			} 
			else 
			{ 
				this._removeClass(obj, tmpClassName); 
			}
			return this; 
		}, 
		
		removeClasses: function(obj, tmpClassName) 
		{ 
			this.removeClass(obj, tmpClassName);  
			return this; 
		}, 
		
		/* this will setup the hasClass function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_hasClass: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var hasClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				hasClass = function(obj, tmpClassName) 
				{ 
					return obj.classList.contains(tmpClassName); 
				};
			} 
			else 
			{ 
				// old browsers 
				hasClass = function(obj, tmpClassName) 
				{ 
					/* we want to get the object classes in an array */ 
					var check = false, 
					classNames = obj.className.split(' ');  
					
					for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
					{ 
						/* if the class matches the tmpClassName we want to remove it */ 
						if(classNames[i] === tmpClassName) 
						{ 
							check = true;
							break;    
						}
					} 
					return check; 
				};
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_hasClass', hasClass, arguments);
		},
		
		hasClass: function(obj, tmpClassName) 
		{ 
			if(!obj || typeof obj !== 'object' || tmpClassName === '') 
			{ 
				return false; 
			} 
			
			return this._hasClass(obj, tmpClassName); 
		}, 
		
		/* this will toggle a class on an element. if the element 
		has the class it will be removed if not added. 
		@param (object) obj = the element object 
		@param (string) tmpClassName = the class name 
		@return (object) the base object to allow chaining */ 
		toggleClass: function(obj, tmpClassName) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this; 
			} 
			
			var hasClass = this.hasClass(obj, tmpClassName); 
			if(hasClass === true) 
			{ 
				this.removeClass(obj, tmpClassName); 
			} 
			else 
			{ 
				this.addClass(obj, tmpClassName); 
			}
			return this; 
		}, 
		
		/* this will get the type of var. 
		@param (mixed) data = the data to check 
		@return (string) the type */ 
		getType: function(data) 
		{ 
			var type = typeof data; 
			if(type !== 'object') 
			{ 
				return type;  
			} 
			
			return (this.isArray(data))? 'array' : type; 
		}, 
		
		/* this will check if an object is an array. 
		@param (mixed) array = the array to check  
		@return (bool) true or false if array is an array */ 
		isArray: function(array) 
		{ 
            /* create a local function to perform the check once */ 
			var isArray;  
			if(typeof Array.isArray === 'function') 
			{ 
				// modern browsers 
				isArray = function(array) 
				{ 
					return Array.isArray(array); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				isArray = function(array) 
				{ 
					return (array instanceof Array);   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, 'isArray', isArray, arguments); 
		}, 
		
		/* this will setup the inArray function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_inArray: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var inArray;  
			if(typeof Array.prototype.indexOf === 'function') 
			{ 
				// modern browsers 
				inArray = function(array, element, fromIndex) 
				{ 
					return array.indexOf(element, fromIndex); 
				}; 
			} 
			else 
			{ 
				// old browsers
				inArray = function(array, element, fromIndex) 
				{ 
					var length = (array.length);  
					var start = (!isNaN(fromIndex))? fromIndex : 0; 
					
					for(var i = start; i < length; i++) 
					{ 
						if(element === array[i]) 
						{ 
							return i; 
						} 
					}  
					return -1; 
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_inArray', inArray, arguments);
		},
		
		/* this will search an array and return the index number of an array 
		or a -1 if the element is not found. 
		@param (array) array = the array to search 
		@param (mixed) element = the element to search in the array 
		@param [(int)] fromIndex = the index number to start searching from 
		@return (int) the index position or -1 if not found */ 
		inArray: function(array, element, fromIndex) 
		{ 
			if(!array || typeof array !== 'object') 
			{ 
				return -1; 
			} 
			
			return this._inArray(array, element, fromIndex);
		},  
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		extendPrototype: function(source, target) 
		{ 
			var prototype = target.prototype = new source(); 
			prototype.parent = source; 
			prototype.constructor = target;  
			
			return target; 
		}, 
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind 
		@param [(array)] argArray = the method args 
		@param [(bool)] addArgs = this will set the curried 
		args to be added to the original args 
		@return a bound method or false on error */ 
		createCallBack: function(obj, method, argArray, addArgs) 
		{ 
			if(typeof method !== 'function') 
			{ 
				return false; 
			}
			
			argArray = argArray || [];
			return function() 
			{ 
				if(addArgs === true) 
				{ 
					var args = base.listToArray(arguments); 
					argArray = argArray.concat(args);  
				} 

				return method.apply(obj, argArray);
			};
		}, 
		
		/* this will setup the bind function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_bind: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var bind;  
			if(typeof Function.prototype.bind === 'function') 
			{ 
				// modern browsers 
				bind = function(obj, method) 
				{ 
					return method.bind(obj); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				bind = function(obj, method) 
				{ 
					return function() 
					{ 
						return method.apply(obj, arguments); 
					};   
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_bind', bind, arguments);
		},
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind */ 
		bind: function(obj, method) 
		{ 
			return this._bind(obj, method);
		}, 
		
		/* this will prepare a json object to be used in an 
		xhr request to sanitize the uri compontents and json 
		encode the object.  
		@param (object) obj = the object json encode 
		@return (mixed) a json string or false */
		prepareJsonUrl: function(obj) 
		{ 
			var escapeChars = function(str) 
			{ 
				if(typeof str !== 'string') 
				{ 
					str = String(str); 
				} 
				
				var newLine = /\n/g, 
				returnCarriage = /\r/g, 
				tab = /\t/g; 
				
				return str.replace(newLine, "\\n").replace(returnCarriage, "\\r").replace(tab, "\\t");   
			}; 
			
			var sanitize = function(text) 
			{ 
				/* we needto escape chars and encode the uri 
				components */ 
				text = escapeChars(text); 
				text = encodeURIComponent(text); 
				
				/* we want to re-encode the double quotes so they 
				will be escaped by the json encoder */ 
				var pattern = /\%22/g; 
				return text.replace(pattern, '"');  
			}; 
			
			var prepareUrl = function(data) 
			{ 
				var type = typeof data; 
				if(type === "undefined") 
				{
					return data; 
				}
					 
				if(type !== 'object') 
				{ 
					data = sanitize(data); 
					return data; 
				} 
				
				for(var prop in data) 
				{ 
					if(data.hasOwnProperty(prop) && data[prop] !== null) 
					{ 
						var childType = typeof data[prop]; 
						if(childType) 
						{ 
							data[prop] = prepareUrl(data[prop]); 
						} 
						else 
						{ 
							data[prop] = sanitize(data[prop]); 
						} 
					}
				}
				return data; 
			}; 
			
			var before = obj; 
			
			/* we want to check to clone object so we wont modify the 
			original object */ 
			if(typeof before === 'object') 
			{ 
				before = JSON.parse(JSON.stringify(obj)); 
			}
			var after = prepareUrl(before); 
			return this.jsonEncode(after);  
		}, 
		
		/* this will decode a json string. 
		@param (string) data = a json encoded string */ 
		jsonDecode: function(data) 
		{ 
			return (typeof data !== "undefined" && data.length > 0)? JSON.parse(data) : false; 
		}, 
		
		/* this will encode an object or array of objects. 
		@param (string) data = an object or array of objects */
		jsonEncode: function(data) 
		{ 
			return (typeof data !== "undefined")? JSON.stringify(data) : false; 
		}, 
		
		/* this will setup the xmlParse function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_xmlParse: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var xmlParse;  
			if(typeof window.DOMParser !== 'undefined') 
			{ 
				// modern browsers 
				xmlParse = function(data) 
				{ 
					var parser = new DOMParser(); 
					return parser.parseFromString(data, "text/xml"); 
				}; 
			} 
			else 
			{ 
				// old browsers
				xmlParse = function(data) 
				{ 
					var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async = false;
					return xmlDoc.loadXML(data); 
				}; 
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_xmlParse', xmlParse, arguments);
		},
		
		/* this will parse an xml string. 
		@param (string) data = an xml string */
		xmlParse: function(data) 
		{ 
			return (typeof data !== "undefined")? this._xmlParse(data) : false; 
		} 

	});
	
	/* this will count the properties of an object 
	and any child object properties */ 
	var countProperty = function(obj) 
	{ 
		var count = 0; 
		/* we want to count each property of the object */ 
		for(var property in obj) 
		{ 
			if(obj.hasOwnProperty(property)) 
			{ 
				count++;  
				/* we want to do a recursive count to get 
				any child properties */ 
				if(typeof obj[property] === 'object') 
				{ 
					count += countProperty(obj[property]); 
				}								
			} 
		} 
		return count; 
	}; 

	var matchProperties = function(obj1, obj2) 
	{ 
		var matched = false; 

		if(typeof obj1 === 'object' && typeof obj2 === 'object') 
		{ 
			/* we want to check each object1 property to the 
			object 2 property */ 
			for(var property in obj1) 
			{ 
				/* we want to check if the property is owned by the 
				object andthat they have matching types */ 
				if(obj1.hasOwnProperty(property) && obj2.hasOwnProperty(property) && typeof obj1[property] === typeof obj2[property]) 
				{ 
					/* we want to check if the type is an object */ 
					if(typeof obj1[property] === 'object') 
					{ 
						/* this will do a recursive check to the 
						child properties */ 
						matched = matchProperties(obj1[property], obj2[property]);  
						if(matched !== true) 
						{ 
							/* if a property did not match we can stop 
							the camparison */
							break; 
						}
					} 
					else 
					{ 
						if(obj1[property] === obj2[property]) 
						{ 
							matched = true; 
						}
						else 
						{
							break;
						}
					}
				} 
				else 
				{ 
					break; 
				}
			} 
		}  

		return matched; 
	};
	
	/* this will count object properties and compare values */ 
	var propertyCountAndCompare = function(obj1, obj2) 
	{ 
		var same = false; 

		/* we want to check if they have the same number of 
		properties */ 
		var option1Count = countProperty(obj1), 
		option2Count = countProperty(obj2); 
		if(option1Count === option2Count) 
		{ 	
			/* we want to check if the properties match */ 
			var result = matchProperties(obj1, obj2); 
			if(result === true) 
			{ 
				same = true; 
			}
		}  

		return same; 
	};
	
	base.augment(
	{
		/* this will compare two values or objects 
		and return true or false if they match. 
		@param (mixed) option1 = the first option to compare 
		@param (mixed) option2 = the second option to compare 
		@return (bool) true or false if equal */ 
		equals: function(option1, option2) 
		{ 
			var same = false; 
			
			/* we want to check if there types match */ 
			var option1Type = typeof option1, 
			option2Type = typeof option2; 
			if(option1Type === option2Type) 
			{ 
				/* we need to check if the options are objects 
				because we will want to match all the 
				properties */ 
				if(option1Type === 'object' && option2Type === 'object') 
				{ 
					var matchResult = propertyCountAndCompare(option1, option2); 
					if(matchResult === true) 
					{ 
						same = true; 
					}
				}
				else 
				{ 
					if(option1 === option2) 
					{ 
						same = true; 
					} 
				}
			}  
			
			return same; 
		}
	});
	
})(this);  

/* base framework module */ 
/* 
	this adds event support  
*/ 
(function(global) 
{
	"use strict";
	
	var DataTracker = base.DataTracker; 
	
	/* this will register the event system to the 
	data tracker to remove events that have been 
	added in layouts. */ 
	DataTracker.addType('events', function(data)
	{
		base.events.removeEvent(data);
	});
	
	base.extend.events = 
	{ 
		getEvents: function(obj)
		{
			if(!obj || typeof obj !== 'object')
			{
				return false; 
			}
			return DataTracker.get(obj, 'events'); 
		}, 
		
		/* this will  create an object to use through the event 
		tracker. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@param bool swapped = tells if the even return was 
		swapped with a standardized function. 
		@param function originalFn = the original function  
		return function was swapped.  
		*/ 
		create: function(event, obj, fn, capture, swapped, originalFn) 
		{ 
			/* we want to check if the swapped param was set */ 
			swapped = (swapped === true); 

			return { 
				event: event, 
				obj: obj, 
				fn: fn, 
				capture: capture, 
				swapped: swapped, 
				originalFn: originalFn 
			}; 
		}, 

		/* this will setup the add function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_add: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var addEvent;  
			if(typeof global.addEventListener === 'function') 
			{ 
				// modern browsers
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj.addEventListener(event, fn, capture);
				}; 
			} 
			else if(typeof document.attachEvent === 'function') 
			{ 
				// old ie 
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj.attachEvent("on" + event, fn);
				}; 
			} 
			else 
			{ 
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj["on" + event] = fn;
				}; 
			} 

			/* this will override method with cached method 
			and we need to return and call with object */ 
			return base.overrideMethod(this, '_add', addEvent, arguments);
		}, 

		/* this will and an event listener and add 
		to the event tracker. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@param bool swapped = tells if the even return was 
		swapped with a standardized function. 
		@param function originalFn = the original function */ 
		add: function(event, obj, fn, capture, swapped, data) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this; 
			}
				  
			capture = (typeof capture !== 'undefined')? capture : false; 

			/* we want to create an event object and add it the 
			the active events to track */ 
			var data = this.create(event, obj, fn, capture, swapped, data);  
			DataTracker.add(obj, 'events', data); 

			this._add(obj, event, fn, capture); 

			return this; 
		}, 

		/* this remove the event and remove from the tracker. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture */ 
		remove: function(event, obj, fn, capture) 
		{ 
			capture = (typeof capture !== 'undefined')? capture : false; 

			/* we want to select the event from the active events array */ 
			var result = this.getEvent(event, obj, fn, capture); 
			if(result === false) 
			{ 
				return this; 
			}
				 
			if(typeof result === 'object') 
			{ 
				/* we want to use the remove event method and just 
				pass the listener object */ 
				this.removeEvent(result);  
			} 
			return this; 
		}, 

		/* this will setup the remove function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_remove: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var removeEvent;  
			if(typeof global.removeEventListener === 'function') 
			{ 
				// modern browsers
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj.removeEventListener(event, fn, capture);
				};
			} 
			else if(typeof document.detachEvent === 'function') 
			{ 
				// old ie 
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj.detachEvent("on" + event, fn);
				};
			} 
			else 
			{ 
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj["on" + event] = null; 
				};
			} 

			/* this will override method with cached method 
			and we need to return and call with object */ 
			return base.overrideMethod(this, '_remove', removeEvent, arguments);
		},

		/* this will remove an event object and the listener 
		from the active events array.   
		@param (object) listener = the listener object from 
		the active events array */ 
		removeEvent: function(listener) 
		{ 
			if(typeof listener === 'object') 
			{ 
				this._remove(listener.obj, listener.event, listener.fn, listener.capture); 
			} 
			return this;  
		}, 

		/* this will search for an return an active event or return 
		false if nothing found. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (mixed) the event object or false if not found */ 
		getEvent: function(event, obj, fn, capture) 
		{ 
			if(typeof eventObj !== 'object') 
			{ 
				return false; 
			}
			
			var events = this.getEvents(obj); 
			if(!events || events.length < 1)
			{
				return false; 
			}
				
			var eventObj = this.create(event, obj, fn, capture); 
			/* if the search returns anything but false we 
			found our active event */ 
			return this.search(eventObj, events);  
		}, 

		/* this will search for an return an active event or return 
		false if nothing found. 
		@param object eventObj = the listener object to search */
		search: function(eventObj, events) 
		{ 
			var swappable = this.isSwappable(eventObj.event); 
			for(var i = 0, maxLength = events.length; i < maxLength; i++) 
			{ 
				var listener = events[i]; 
				if(listener.event !== eventObj.event || listener.obj !== eventObj.obj)
				{
					continue; 
				}
				
				if(listener.fn === eventObj.fn || (swappable === true && listener.originalFn === eventObj.fn))
				{
					return listener; 
				}
			} 

			return false; 
		}, 	

		/* this will remove all events added to an element through 
		the base framework.  

		@param (object) obj = the element object */
		removeEvents: function(obj) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this; 
			}
				 
			DataTracker.remove(obj, 'events'); 
			
			return this; 
		}, 

		swap: [  
			'DOMMouseScroll', 
			'wheel', 
			'mousewheel', 
			'mousemove', 
			'popstate' 
		], 

		addSwapped: function(type)
		{
			this.swap.push(type); 
		}, 

		/* this will check if an event type could be swapped. 
		@param string event = the type of event
		 */ 
		isSwappable: function(event) 
		{ 
			/* we want to check if the event type is in the 
			swapped event array */ 
			var index = base.inArray(this.swap, event); 
			return (index > -1);  
		}
	}; 
	
	base.augment(
	{
		/* this will add an event listener. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		addListener: function(event, obj, fn, capture) 
		{  
			/* we want to add this to the active events */ 
			this.events.add(event, obj, fn, capture);  
			
			return this; 
		}, 
		
		/* this will add an event listener. 
		@param mixed event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		on: function(event, obj, fn, capture) 
		{  
			var events = this.events;
			if(this.isArray(event)) 
			{ 
				for(var i = 0, length = event.length; i < length; i++) 
				{ 
					var evt = event[i]; 
					events.add(evt, obj, fn, capture);
				} 
			} 
			else 
			{ 
				events.add(event, obj, fn, capture); 
			}			
			return this; 
		}, 
		
		/* this will remove an event listener. 
		@param mixed event = the name of the event to listen 
		@param object obj = obj to remove the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		off: function(event, obj, fn, capture) 
		{  
			var events = this.events;
			if(this.isArray(event)) 
			{ 
				for(var i = 0, length = event.length; i < length; i++) 
				{ 
					var evt = event[i]; 
					events.remove(evt, obj, fn, capture);
				} 
			} 
			else 
			{ 
				events.remove(event, obj, fn, capture); 
			}			
			return this; 
		},
		
		/* this will remove an event listener. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		removeListener: function(event, obj, fn, capture) 
		{ 
			/* we want to remove this from the active events */ 
			this.events.remove(event, obj, fn, capture);  
			
			return this; 
		}, 
		
		_createEvent: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var createEvent;  
			if('CustomEvent' in window) 
			{ 
				createEvent = function(obj, event, eventType, settings, params) 
				{ 
					var e;
					if(eventType === 'HTMLEvents') 
					{ 
						e = new Event(event); 
					} 
					else if(eventType === 'MouseEvents') 
					{ 
						e = new MouseEvent(event, settings); 
					} 
					else 
					{ 
						e = new CustomEvent(event, params);
					}
					return e; 
				};
			} 
			else if('createEventObject' in document)
			{ 
				createEvent = function(obj, event, eventType, settings, params) 
				{ 
					var e = document.createEventObject(); 
					e.eventType = event;
					return e; 
				};
			} 
			else
			{ 
				createEvent = function(obj, event, eventType, settings, params) 
				{ 
					var e = document.createEvent(eventType); 
					if (eventType === 'HTMLEvents')
					{
						obj.initEvent(event, settings.bubbles, settings.cancelable);
					}
					else if(eventType === 'MouseEvents')
					{ 
						e.initMouseEvent(
							event, 
							settings.canBubble,
							settings.cancelable,
							settings.view,
							settings.detail,
							settings.screenX,
							settings.screenY,
							settings.clientX,
							settings.clientY,
							settings.ctrlKey,
							settings.altKey,
							settings.shiftKey,
							settings.metaKey,
							settings.button,
							settings.relatedTarget
						);
					}
					else if(eventType === 'CustomEvent')
					{ 
						e.initCustomEvent(event, settings.bubbles, settings.cancelable, params);
					}
					return e; 
				};
			}

			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_createEvent', createEvent, arguments);
		},
		
		/* this will create an event object that can be used 
		to dispatch events. this supports html mouse and cu-
		stom events. 
		@param (string) event = the name of the event 
		@param (object) obj = obj to trigger the listener 
		@param (object) options = event settings options
		@param [(object)] params = custom event params object
		@return (object | false) the event or false */ 
		createEvent: function(event, obj, options, params) 
		{ 
			if(!obj || typeof obj !== 'object')
			{ 
				return false;  
			} 
			
			var settings = {
				pointerX: 0,
				pointerY: 0,
				button: 0,
				view: window,
				detail: 1, 
				screenX: 0, 
				screenY: 0, 
				clientX: 0, 
				clientY: 0, 
				ctrlKey: false,
				altKey: false,
				shiftKey: false,
				metaKey: false,
				bubbles: true,
				cancelable: true, 
				relatedTarget: null
			}; 

			if(options && typeof options === 'object')
			{ 
				settings = base.extendObject(settings, options); 
			}

			var eventType = this._getEventType(event); 
			return this._createEvent(obj, event, eventType, settings, params);
		}, 
		
		_getEventType: function(event)
		{
			var eventTypes = {
				'HTMLEvents': /^(?:load|unload|abort|error|select|change|submit|reset|focus|blur|resize|scroll)$/,
				'MouseEvents': /^(?:click|dblclick|mouse(?:down|up|over|move|out))$/
			}; 

			var eventType = 'CustomEvent'; 
			for(var prop in eventTypes)
			{ 
				if(eventTypes.hasOwnProperty(prop))
				{ 
					var value = eventTypes[prop]; 
					if(event.match(value))
					{ 
						eventType = prop; 
						break; 
					}
				}
			}
			return eventType; 
		}, 
		 
		_trigger: function() 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var trigger;  
			if('createEvent' in document) 
			{ 
				trigger = function(obj, event) 
				{ 
					obj.dispatchEvent(event);
				};
			} 
			else 
			{ 
				// old ie 
				trigger = function(obj, event) 
				{ 
					var type = event.type; 
					obj.fireEvent('on' + type, event);
				};
			} 

			/* this will override method with cached method 
			and we need to return and call with object */ 
			return this.overrideMethod(this, '_trigger', trigger, arguments);
		},
		
		/* this will trigger an event. 
		@param (mixed) event = the name of the event or event object 
		@param object obj = obj to trigger the listener 
		@param object params = event params object 
		@return (object) a reference to the base object */
		trigger: function(event, obj, params) 
		{ 
			if(!obj || typeof obj !== 'object') 
			{ 
				return this; 
			}
				 
			var e = (typeof event === 'string')? this.createEvent(event, obj, null, params) : event;  
			this._trigger(obj, e); 
			return this; 
		}, 
		
		/* this will store the mouse wheel event name */ 
		mouseWheelEventType: null, 
		
		/* this will get theclientmouse wheel event name. 
		@return (string) */ 
		getWheelEventType: function()
		{ 
			/* this will check what mouse wheel type 
			the client supports
			@return (string) the event name */ 
			var getMouseWheelType = function()
			{ 
				var type = 'wheel'; 
				if('onmousewheel' in global)
				{ 
					type = 'mousewheel'; 
				} 
				else if('DOMMouseScroll' in global)
				{ 
					type = 'DOMMouseScroll'; 
				}
				return type; 
			};
			
			/* this will get the event type or 
			one time set the type and return the type */ 
			return this.mouseWheelEventType || (
				this.mouseWheelEventType = getMouseWheelType()
			);
		}, 
		
		onMouseWheel: function(callBackFn, obj, cancelDefault, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var self = this;  
			
			/* we want to return the mousewheel data 
			to this private callback function before 
			returning to the call back function*/ 
			var mouseWeelResults = function(e) 
			{
				e = e || window.event; 
				var delta = Math.max(-1, Math.min(1, (-e.deltaY || e.wheelDelta || -e.detail))); 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof callBackFn === 'function') 
				{ 
					callBackFn(delta, e); 
				} 
				
				/* we want to check to cancel default */ 
				if(typeof cancelDefault !== 'undefined' && cancelDefault === true) 
				{ 
					self.preventDefault(e); 
				} 
			};  
			
			var event = this.getWheelEventType(); 
			this.events.add(event, obj, mouseWeelResults, capture, true, callBackFn); 
			
			return this; 
		}, 
		
		offMouseWheel: function(callBackFn, obj, capture)
		{ 
			if(typeof obj === "undefined")
			{ 
				obj = window; 
			}
			
			var event = this.getWheelEventType(); 
			this.off(event, obj, callBackFn, capture); 
		}, 
		
		/* this will prevent the default action 
		of an event 
		@param (object) e = the event object 
		@return (object) a reference to the base object */ 
		preventDefault: function(e) 
		{ 
			e = e || window.event; 
			
			if(typeof e.preventDefault === 'function') 
			{ 
				e.preventDefault(); 
			} 
			else 
			{ 
				e.returnValue = false; 
			} 
			
			return this; 
		}, 
		
		/* this will cancel the propagation of an event.
		@param (object) e = the event object 
		@return (object) a reference to the base object */
		stopPropagation: function(e) 
		{ 
			e = e || window.event; 
		
			if(typeof e.stopPropagation === 'function') 
			{ 
				e.stopPropagation();
			}
			else 
			{
				e.cancelBubble = true;
			} 
			
			return this; 
		}
	});
	
})(this);

/* base framework module */
(function()
{
	"use strict"; 
	
	/* this will add (ajax) xhr requests to the base framework */ 
	
	var XhrDefaultSettings = 
	{ 
		url: '',       
		
		/* this is the responseType of the server 
		response (string) */ 
		responseType:  'json', 
		
		/* this is the server method */ 
		method: 'POST',
		
		/* this can fix a param string to be added 
		to every ajax request */ 
		fixedParams: '',
		
		/* headers (object) */ 
		headers: 
		{ 
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' 
		}, 
		
		/* this will set the ajax request to async (bool) */ 
		async: true, 
		
		/* cross domain (bool) */ 
		crossDomain: false, 
		
		/* cors with credentials (bool) */ 
		withCredentials: false,
		
		/* events (function) */ 
		completed: null, 
		failed: null, 
		aborted: null, 
		progress: null 
	}; 
	
	/* this will setup and store the proper method for setting 
	up xhr request objects */ 
	var XhrFactory = 
	{ 
		/* this will setup the createXHR function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_createXHR: function() 
		{   
			/* create a local function to perform the check 
			once then override the function */ 
			var createXhr;  
			if(typeof XMLHttpRequest !== "undefined") 
			{ 
				// modern browsers
				createXhr = function() 
				{ 
					return new XMLHttpRequest();
				}; 
			} 
			else 
			{ 
				try{ 
					createXhr = function() 
					{ 
						return new ActiveXObject("Msxml2.XMLHTTP");
					}; 
				} 
				catch(e) 
				{ 
					try{  
						createXhr = function() 
						{ 
							return new ActiveXObject("Microsoft.XMLHTTP");
						};
					} 
					catch(err) 
					{ 
						 
					} 
				} 
				
				if(!createXhr) 
				{ 
					createXhr = function() 
					{ 
						return false;
					}; 
				}
			} 
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return base.overrideMethod(this, '_createXHR', createXhr, arguments);
		}, 
		
		/* this will setup the createCorsXHR function to cache the 
		proper function so we only check one time. 
		@return (function) the function */ 
		_createCorsXHR: function() 
		{   
			/* create a local function to perform the check 
			once then override the function */ 
			var createXhr;  
			if(typeof XMLHttpRequest !== "undefined" && typeof XDomainRequest === "undefined") 
			{ 
				// modern browsers
				createXhr = function() 
				{ 
					return new XMLHttpRequest();
				}; 
			} 
			else if(typeof XDomainRequest !== "undefined") 
			{ 
				createXhr = function() 
				{ 
					return new XDomainRequest();
				};
			} 
			else 
			{ 
				createXhr = function() 
				{ 
					return false;
				}; 
			}
			
			/* this will override method with cached method 
			and we need to return and call with object */ 
			return base.overrideMethod(this, '_createCorsXHR', createXhr, arguments);
		}
	}; 
	
	/* this will add ajax settings to the base class */ 
	base.augment(
	{
		/* this will set the deafult ajax params to the 
		base object so they can be modified */ 
		xhrSettings: XhrDefaultSettings, 
		
		/* this will add fixed params the ajax settings */
		addFixedParams: function(params) 
		{ 
			base.xhrSettings.fixedParams = params; 
		}, 
		
		/* this will allow the ajax settings to be updated */ 
		ajaxSettings: function(settingsObj) 
		{ 
			if(typeof settingsObj === 'object') 
			{ 
				base.xhrSettings = base.extendClass(base.xhrSettings, settingsObj); 
			}
		}, 
		
		/* this will resetthe ajax settings */ 
		resetAjaxSettings: function() 
		{ 
			base.xhrSettings = XhrDefaultSettings; 
		}
	}); 
	
	/* this will send an ajax request and return 
	the xhr object */ 
	/* 
		the params can either be individual params or a settings object 
		
		individual param: 
		@param (string) url = the url to connect to  
		@param (string) params = the xhr params  
		@param (function) callBackFn = the ajax callback function 
		@param [(string)] responseType = the data type of xhr response (json/xml/text) 
		@param [(string)] method = the send method to the server
		@param [(bool)] async = this will enable or disable async
		

		settings object: 
		-url (string): the ajax file url 
		-params (string): the ajax param string 
		-method (string): the server request method 
		-responseType (string): the type of data to return (text, html, json) 
		if the responseType is json or xml the return text will be parsed 
		before it is return to the callback function 
		-async (bool): default is set to async 
		-headers (object): the headers to use 
		-crossDomain (bool): set true if performings cors 
		-withCredentials (bool): with credentials for cors
		-completed (function): the function to perform 
		when completed 
		-failed (function): the function to perform 
		if failed 
		-progress (function): the function to perform 
		during progress 
		-aborted (function): the function to perform 
		if aborted
		
	*/ 
	base.extend.ajax = function()
	{ 
		/* we want to save the args so we can check 
		which way we are adding the ajax settings */ 
		var args = base.listToArray(arguments); 
		
		/* we want to create a new ajax request and 
		return the xhr object */ 
		var ajax = new XhrRequest(args);   
		return ajax.xhr;
	}; 
	
	/* this will create an xhr request and perform all 
	the steps to setup and return the response */ 
	var XhrRequest = base.Class.extend(
	{ 
		constructor: function(args) 
		{ 
			/* this will be the ajax request settings */ 
			this.settings = null;  
			/* this will be the xhr object */ 
			this.xhr = null;
			
			this.setup(args); 
		}, 
		
		/* this will setup a new xhr request and send it. if it 
		can setup it will return true else false */ 
		setup: function(args) 
		{ 
			/* we want to setup the ajax settings */ 
			this.getXhrSettings(args);  
			
			/* create a new xhr object */ 
			var xhr = this.xhr = this.createXHR(); 
			if(xhr === false) 
			{ 
				return false; 
			}
				 
			var settings = this.settings; 
			xhr.open(settings.method, settings.url, settings.async); 

			this.setupHeaders(); 
			this.addXhrEvents(); 

			/* this will setup the params and send the 
			xhr request */ 
			xhr.send(this.getParams()); 
		}, 
		
		parseParamString: function(paramStr) 
		{ 
			var objURL = {};  
		
			if(typeof paramStr !== 'string') 
			{ 
				return objURL; 
			}
			 
			var regExp = /([^?=&]+)(=([^&]*))?/g;
			paramStr.replace(regExp, function(a, b, c, d)
			{ 
				/* we want to save the key and the 
				value to the objURL */ 
				objURL[b] = d;
			});
			return objURL;  
		},
		
		objectToString: function(object)
		{ 
			var params = [];
			for (var prop in object)
			{
				if(object.hasOwnProperty(prop))
				{ 
					params.push(prop + '=' + object[prop]);
				}
			}
			return params.join('&');
		}, 
		
		/* this will add params to the base params. this will convert 
		the adding params to match the params type. Supported types 
		include: query string, FormData object, and object
		@param (mixed) params 
		@params(mixed) addingParams 
		@return (mixed) the new params */ 
		setupParams: function(params, addingParams)
		{ 
			var paramsType = typeof params;
			if(addingParams)
			{ 
				/* this will convert the adding params to match 
				the params type */ 
				var addingType = typeof addingParams;
				if(paramsType === 'string') 
				{ 
					if(addingType !== 'string')
					{ 
						addingParams = this.objectToString(addingParams); 
					}

					var char = (params === '')? '?' : '&'; 
					params += char + addingParams; 
				}
				else 
				{ 
					if(addingType === 'string')
					{ 
						addingParams = this.parseParamString(addingParams); 
					} 

					if(params instanceof FormData) 
					{ 
						for(var key in addingParams) 
						{ 
							if(addingParams.hasOwnProperty(key))
							{ 
								params.append(key, addingParams[key]);
							}
						}
					}
					else if(paramsType === 'object')
					{ 
						/* we dont want to modify the original object 
						so we need to clone the object before extending */ 
						params = JSON.parse(JSON.stringify(params)); 

						params = base.extendObject(addingParams, params); 
						params = this.objectToString(params);
					}
				}
			}
			else 
			{ 
				if((params instanceof FormData) === false && paramsType === 'object') 
				{ 
					params = this.objectToString(params);
				}
			}
			return params; 
		}, 
		
		/* this will setup fixed params with params being 
		sent in the xhr request. this method supports 
		param types of string, FormData, and objects. 
		@return (mixed) string or FormData object */ 
		getParams: function() 
		{ 
			var settings = this.settings, 
			params = settings.params;  
			
			var fixedParams = settings.fixedParams;
			if(params) 
			{
				params = this.setupParams(params, fixedParams); 
			}
			else if(fixedParams)
			{ 
				params = this.setupParams(fixedParams); 
			}
 
			return params; 
		},
		
		/* this will setup the request settings from the default 
		xhr settings and any settings being updated from the 
		ajax args */ 
		getXhrSettings: function(args) 
		{ 
			/* we want to create a clone of the default 
			settings before adding the new settings */ 
			var settings = this.settings = base.createObject(base.xhrSettings);  
			
			/* we want to check if we are adding the ajax settings by 
			individual args or by a settings object */ 
			if(args.length >= 2 && typeof args[0] !== 'object') 
			{ 
				/* we want to add each arg as one of the ajax 
				settings */ 
				for(var i = 0, maxLength = args.length; i < maxLength; i++) 
				{ 
					var arg = args[i]; 
					
					switch(i) 
					{ 
						case 0: 
							settings.url = arg; 
							break; 
						case 1: 
							settings.params = arg; 
							break; 
						case 2: 
							settings.completed = arg; 
							settings.failed = arg;
							break; 
						case 3: 
							settings.responseType = arg || 'json'; 
							break; 
						case 4: 
							settings.method = (arg)? arg.toUpperCase() : 'POST'; 
							break; 
						case 5: 
							settings.async = (typeof arg !== 'undefined')? arg : true; 
							break; 
					} 
				} 
			}
			else 
			{ 
				/* override the default settings with the args 
				settings object */ 
				settings = this.settings = base.extendClass(this.settings, args[0]); 
				
				/* we want to check to add the completed callback 
				as the error and aborted if not set */ 
				if(typeof settings.completed === 'function') 
				{ 
					if(typeof settings.failed !== 'function') 
					{ 
						settings.failed = settings.completed; 
					} 
					
					if(typeof settings.aborted !== 'function') 
					{ 
						settings.aborted = settings.failed; 
					} 
				} 
			} 
		},
		
		/* this will create and return an xhr object or return 
		false if not able. 
		@return (mixed) the xhr object or false */ 
		createXHR: function() 
		{ 			
			/* we want to check to setup the xhr by 
			the crossDomain settings */ 
			var settings = this.settings; 
			var xhr = (settings && settings.crossDomain === true)? XhrFactory._createCorsXHR() : XhrFactory._createXHR(); 
			if(!xhr)
			{
				return false; 
			} 
			
			if(xhr.hasOwnProperty('responseType'))
			{
				xhr.responseType = settings.responseType; 
			}
			
			if(settings.withCredentials === true) 
			{ 
				xhr.withCredentials = true;
			}
 
			return xhr;  
		}, 
		
		/* this will setup the xhr headers */ 
		setupHeaders: function() 
		{ 
			var settings = this.settings; 
			if(settings && typeof settings.headers === 'object') 
			{ 
				/* we want to add a header for each 
				property in the object */ 
				var headers = settings.headers;  
				for(var header in headers) 
				{ 
					if(headers.hasOwnProperty(header)) 
					{ 
						this.xhr.setRequestHeader(header, headers[header]);
					}
				} 
			} 
		}, 
		
		/* this will get the server response and check the 
		ready state and status to return response to 
		request call back function 
		@param (object) e = the event object 
		@param [(string)] overrideType = the type of event that 
		is overriding the default event type. this is used with the older 
		style callback for older browsers */ 
		update: function(e, overrideType) 
		{ 
			e = e || window.event; 
			
			var xhr = this.xhr; 
			
			/* this will remove the xhr events from the active events 
			after thevents are completed, aborted, orerroed */
			var removeEvents = function() 
			{ 	
				var events = base.events; 
				events.removeEvents(xhr.upload); 
				events.removeEvents(xhr); 
			};
			
			var settings = this.settings; 
			if(!settings)
			{
				return false; 
			} 
			
			var type = overrideType || e.type; 
			switch(type) 
			{ 
				case 'load':  
					if(typeof settings.completed === 'function') 
					{ 
						var response = this.getResponseData();  
						settings.completed(response, this.xhr);  
					} 
					/* the xhr is complete so we need to clean up 
					the events */ 
					removeEvents();
					break; 
				case 'error':  
					if(typeof settings.failed === 'function') 
					{ 
						settings.failed(false, this.xhr); 
					} 
					/* the xhr has errored so we need to clean up 
					the events */ 
					removeEvents();
					break; 
				case 'progress':  
					if(typeof settings.progress === 'function') 
					{  
						settings.progress(e); 
					} 
					break; 
				case 'abort':  
					if(typeof settings.aborted === 'function') 
					{  
						settings.aborted(false, this.xhr); 
					} 
					removeEvents();
					break; 
			} 
		}, 
		
		/* this will get the response data and check to decode the data type 
		if required. 
		@return (mixed) the response data */ 
		getResponseData: function() 
		{ 
			var xhr = this.xhr; 
			var response = xhr.responseText; 
				
			if(xhr.responseType || typeof response !== 'string') 
			{ 
				return response; 
			}
				 
			var encoded = false; 
			/* we want to check to decode the response by the type */ 
			switch(this.settings.responseType.toLowerCase()) 
			{ 
				case 'json': 

					encoded = base.jsonDecode(response); 
					if(encoded !== false) 
					{ 
						response = encoded; 
					} 
					else 
					{ 
						response = response; 
						this.error = 'yes'; 
					}
					break; 
				case 'xml': 
					encoded = base.xmlParse(response); 
					if(encoded !== false) 
					{ 
						response = encoded; 
					} 
					else 
					{ 
						response = response; 
						this.error = 'yes'; 
					} 
					break; 
				case 'text': 
					break;

			} 
			
			return response; 
		}, 
		
		checkReadyState: function(e) 
		{ 
			e = e || window.event; 
			
			var xhr = this.xhr; 
			if(xhr.readyState != 4)
			{ 
				/* the response is not ready */ 
				return; 
			} 
			
			var type; 
			if(xhr.status == 200) 
			{ 
				 /* the ajax was successful 
				 but we want to change the event type to load */ 
				 type = 'load';  
			} 
			else 
			{ 
				/* there was an error */ 
				type = 'error'; 
			} 
			
			this.update(e, type);
		}, 
		
		/* this will add the event listeners to the xhr object. */ 
		addXhrEvents: function() 
		{ 
			var settings = this.settings; 
			if(settings) 
			{ 
				var xhr = this.xhr; 
				/* we need to check if we can add new event listeners or 
				if we have to use the old ready state */ 
				if(typeof xhr.onload !== 'undefined') 
				{ 
					var callBack = base.bind(this, this.update); 
					base.on(['load', 'error', 'abort'], xhr, callBack); 
					base.on('progress', xhr.upload, callBack); 
				} 
				else 
				{ 
					var self = this;
					xhr.onreadystatechange = function(e)
					{ 
						self.checkReadyState(e); 
					}; 
				}
			} 
		}  
	}); 
})();

/* base framework module */
(function()
{
	"use strict"; 
	
	/* 
		DataPubSub 
		
		this will create a pub sub object 
		to allow messages to be subscribed to and 
		publish changes that will be pushed to the 
		subscribers. 

	*/ 
	var DataPubSub = base.Class.extend(
	{ 
		constructor: function()
		{ 
			this.callBacks = {}; 
			this.lastToken = -1; 
		}, 

		/* this will get the subscriber array for the 
		message or create a new subscriber array if none 
		is setup already. 
		@param (string) msg 
		@return (array) subscriber array */ 
		get: function(msg) 
		{ 
			var callBacks = this.callBacks;
			return (callBacks[msg] || (callBacks[msg] = []));
		},

		reset: function() 
		{ 
			this.callBacks = {}; 
		}, 

		on: function(msg, callBack) 
		{ 
			var token = (++this.lastToken); 
			var list = this.get(msg);
			list.push({
				token: token, 
				callBack: callBack
			});
			return token; 
		}, 
		
		off: function(msg, token) 
		{ 
			var list = this.callBacks[msg] || false;
			if(list === false)
			{
				return false; 
			}
			
			var length = list.length; 
			for (var i = 0; i < length; i++ ) 
			{
				var item = list[i]; 
				if(item.token === token)
				{
					list.splice(i, 1);
					break;
				}
			}
		}, 
		
		remove: function(msg) 
		{ 
			var callBacks = this.callBacks; 
			if(callBacks[msg])
			{ 
				delete callBacks[msg]; 
			}
		}, 
		
		publish: function(msg) 
		{ 
			var i, length,
			list = this.callBacks[msg] || false; 
			if(list === false)
			{ 
				return false; 
			}
			
			var args = Array.prototype.slice.call(arguments, 1);
			
			length = list.length;
			for (i = 0; i < length; i++) 
			{
				list[i].callBack.apply(this, args);
			}
		}
	});
	
	var pubSub = new DataPubSub(); 
	base.extend.DataPubSub = DataPubSub;
	
	var Source = base.Class.extend(
	{
		constructor: function()
		{ 
			this.msg = null; 
			this.token = null; 
		}, 
		
		setToken: function(token)
		{
			this.token = token; 
		}
	}); 
	
	var OneWaySource = Source.extend(
	{
		constructor: function(data)
		{ 
			Source.call(this);  
			this.data = data; 
		}, 
		
		subscribe: function(msg, callBack)
		{
			this.msg = msg; 
			this.token = this.data.on(msg, callBack); 
		}, 
		
		unsubscribe: function()
		{
			this.data.off(this.msg, this.token); 
		}
	});
	
	var TwoWaySource = Source.extend(
	{
		callBack: null, 
		
		subscribe: function(msg)
		{
			this.msg = msg; 
			var callBack = base.bind(this, this.callBack); 
			this.token = pubSub.on(msg, callBack); 
		}, 
		
		unsubscribe: function()
		{
			pubSub.off(this.msg, this.token); 
		}
	});
	
	var DataSource = TwoWaySource.extend(
	{
		constructor: function(data, prop)
		{
			TwoWaySource.call(this); 
			this.data = data;  
			this.prop = prop;   
		}, 
		
		set: function(value)
		{
			this.data.set(this.prop, value); 
		}, 
		
		get: function()
		{
			return this.data.get(this.prop);
		}, 
		
		callBack: function(value, committer) 
		{
			if(this.data !== this.committer) 
			{
				this.data.set(this.prop, value, committer); 
			}
		}
	}); 
	
	var ElementSource = TwoWaySource.extend(
	{
		constructor: function(element, attr, filter)
		{
			TwoWaySource.call(this);   
			this.element = element; 
			this.attr = this.getAttrBind(attr); 
			
			if(typeof filter === 'string')
			{
				filter = this.setupFilter(filter);  
			}
			this.filter = filter; 
		}, 
		
		getAttrBind: function(customAttr)
		{
			/* this will setup the custom attr if the prop 
			has specified one. */ 
			if(customAttr)
			{
				return customAttr; 
			}
			
			var attr = 'textContent';
			/* if no custom attr has been requested we will get the 
			default attr of the element */ 
			var element = this.element; 
			if(!(element && typeof element === 'object')) 
			{ 
				return attr; 
			}
			
			var tagName = element.tagName.toLowerCase();
			if (tagName === "input" || tagName === "textarea" || tagName === "select") 
			{
				var type = element.type; 
				if(type && (type === 'checkbox' || type === 'radio')) 
				{ 
					attr = 'checked'; 
				}
				else 
				{ 
					attr = 'value';
				}
			} 
			return attr; 
		}, 
		
		setupFilter: function(filter)
		{
			var pattern = /(\[\[[^\]]+\]\])/;
			return function(value)
			{
				return filter.replace(pattern, value);
			}; 
		}, 
		
		/* this will set a value on an elememnt.  
		@param (mixed) value */ 
		set: function(value) 
		{ 
			var element = this.element; 
			if(!(element && typeof element === 'object')) 
			{ 
				return false; 
			}
				
			/* this will check to apply the option filter before 
			settings the value */ 
			if(this.filter)
			{
				value = this.filter(value); 
			} 

			var attr = this.attr, 
			type = element.type; 
			if(type && (type === 'checkbox' || type === 'radio')) 
			{ 
				value = (value == 1); 
			}

			if(attr.substring(0, 5) === 'data-')
			{
				base.data(element, attr, value); 
			}
			else 
			{
				element[attr] = value; 
			} 
		}, 

		/* this will get a value on an elememnt.  
		@return (mixed) the element value */ 
		get: function() 
		{ 
			var value = '', 
			element = this.element;
			if(!(element && typeof element === 'object')) 
			{ 
				return value; 
			}
				
			var attr = this.attr; 
			if(attr.substring(0, 5) === 'data-')
			{
				value = base.data(element, attr); 
			}
			else 
			{
				value = element[attr];  
			} 
			return value;
		}, 
		
		callBack: function(value, committer) 
		{
			if(committer !== this.element)
			{
				this.set(value);
			}
		}
	});
	
	var Connection = base.Class.extend(
	{
		unsubscribe: function()
		{
			
		}
	}); 
	
	var OneWayConnection = Connection.extend(
	{
		constructor: function()
		{
			this.source = null; 
		}, 
		
		addSource: function(data)
		{
			return (this.source = new OneWaySource(data)); 
		}, 
		
		unsubscribe: function()
		{
			this.source.unsubscribe();  
			this.source = null; 
		}
	});
	
	var TwoWayConnection = Connection.extend(
	{
		constructor: function()
		{
			this.element = null; 
			this.data = null; 
		}, 
		
		addElement: function(element, attr, filter)
		{
			return (this.element = new ElementSource(element, attr, filter)); 
		}, 
		
		addData: function(data, prop)
		{
			return (this.data = new DataSource(data, prop));  
		}, 
		
		unsubscribeSource: function(source)
		{
			if(source)
			{
				source.unsubscribe(); 
			}
		}, 
		
		unsubscribe: function()
		{
			this.unsubscribeSource(this.element); 
			this.unsubscribeSource(this.data); 
			
			this.element = null; 
			this.data = null;
		}
	});
	
	var ConnectionTracker = base.Class.extend(
	{ 
		constructor: function() 
		{  
			this.connections = {};  
		},  
		
		add: function(id, attr, connection)
		{
			var connections = this.find(id); 
			return (connections[attr] = connection);  
		}, 
		
		get: function(id, attr)
		{
			var connections = this.connections[id]; 
			if(connections)
			{
				return (connections[attr] || false); 
			}
			return false; 
		}, 
		
		find: function(id)
		{
			var connections = this.connections; 
			return (connections[id] || (connections[id] = {}));
		},
		
		remove: function(id, attr)
		{
			var connections = this.connections[id]; 
			if(connections)
			{
				var connection; 
				if(attr)
				{
					connection = connections[attr]; 
					if(connection)
					{
						connection.unsubscribe(); 
						delete connections[attr]; 
					}
					
					/* this will remove the msg from the elements 
					if no elements are listed under the msg */ 
					if(base.isEmpty(connections))
					{
						delete this.connections[id]; 
					}
				} 
				else 
				{
					for(var prop in connections)
					{
						if(connections.hasOwnProperty(prop))
						{
							connection = connections[prop];
							if(connection)
							{
								connection.unsubscribe(); 
							}
						} 
					}
					
					delete this.connections[id];
				}
			}
		}
	});

	/*
		DataBinder

		this create a data bind module to add 
		two way data binding to base models. 
	*/
	var DataBinder = base.Class.extend(
	{ 
		constructor: function() 
		{ 
			this.version = "1.0.1";
			this.attr = 'data-bind-id'; 

			this.connections = new ConnectionTracker(); 

			this.idCount = 0; 
			this.setup(); 
		}, 

		setup: function() 
		{ 
			this.setupEvents();
		}, 

		/* this will add the data bind attr on an 
		element for a model property. 
		@param (object) element 
		@param (object) data 
		@param (string) prop
		@return (object) the instance of the data binder */
		bind: function(element, data, prop, filter) 
		{ 
			var bindSettings = this.getPropSettings(prop); 
			prop = bindSettings.prop; 
			
			/* this will setup the model bind attr to the 
			element and assign a bind id attr to support 
			two way binding */ 
			var connection = this.setupConnection(element, data, prop, bindSettings.attr, filter);   

			/* we want to get the starting value of the 
			data and set it on our element */ 
			var connectionElement = connection.element, 
			value = data.get(prop); 
			if(typeof value !== 'undefined') 
			{ 
				connectionElement.set(value); 
			}
			else 
			{ 
				/* this will set the element value 
				as the prop value */ 
				value = connectionElement.get(); 
				if(value !== '')
				{ 
					connection.data.set(value);
				} 
			}
			return this; 
		}, 
		
		setupConnection: function(element, data, prop, customAttr, filter)
		{
			var connection = new TwoWayConnection();
			
			var id = this.getBindId(element);
			var dataSource = connection.addData(data, prop); 
			dataSource.subscribe(id); 
			
			/* this will add the data binding 
			attr to out element so it will subscribe to 
			the two data changes */
			var dataId = data.getDataId(), 
			msg = dataId + ':' + prop; 
			
			var elementSource = connection.addElement(element, customAttr, filter); 
			elementSource.subscribe(msg); 
			
			this.addConnection(id, 'bind', connection);
			
			return connection;  
		}, 
		
		addConnection: function(id, attr, connection)
		{
			this.connections.add(id, attr, connection);
		}, 
		
		setBindId: function(element)
		{
			var id = 'bs-db-' + this.idCount++; 
			base.attr(element, this.attr, id);
			return id; 
		}, 
		
		getBindId: function(element)
		{
			var id = base.attr(element, this.attr); 
			if(!id) 
			{
				id = this.setBindId(element); 
			}
			return id; 
		}, 
		
		getPropSettings: function(prop)
		{
			var bindProp = prop, 
			bindAttr = null; 
			
			/* this will setup the custom attr if the prop 
			has specified one. */ 
			var parts = prop.split(':'); 
			if(parts.length > 1)
			{
				bindProp = parts[1]; 
				bindAttr = parts[0]; 
			}
			
			return {
				prop: bindProp, 
				attr: bindAttr
			}; 
		}, 
		
		/* this will remove an element from the data binder
		@param (object) element
		@return (object) the instance of the data binder*/ 
		unbind: function(element) 
		{ 
			var id = base.data(element, this.attr); 
			if(id)
			{
				this.connections.remove(id);
			} 
			return this;
		}, 
		
		watch: function(element, data, prop, callBack)
		{
			if(!element || typeof element !== 'object')
			{
				return false; 
			}
			
			var connection = new OneWayConnection();
			
			var source = connection.addSource(data); 
			source.subscribe(prop, callBack);
			
			var id = this.getBindId(element);
			var attr = data.getDataId() + ':' + prop; 
			this.addConnection(id, attr, connection);  
		}, 
		
		unwatch: function(element, data, prop)
		{
			if(!element || typeof element !== 'object')
			{
				return false; 
			} 
			
			var id = base.attr(element, this.attr); 
			if(id)
			{
				var attr = data.getDataId() + ':' + prop;
				this.connections.remove(id, attr);
			} 
		}, 

		/* this will publish a change to the data binder. 
		@param (string) message e.g id:change 
		@param (mixed) the prop value 
		@param (object) the object committing the change */ 
		publish: function(msg, value, committer)
		{ 
			pubSub.publish(msg, value, committer);
			return this;
		}, 
		
		isDataBound: function(element) 
		{ 
			if(element)
			{ 
				var id = base.data(element, this.attr); 
				if(id)
				{
					return id; 
				}
			}
			return false; 
		}, 
		
		blockedKeys: [
			17, //ctrl 
			9, //tab 
			16, //shift
			18, //alt 
			20, //caps lock 
			37, //arrows 
			38, 
			39, 
			40 
		], 
		
		bindHandler: function(evt) 
		{
			if(evt.type === 'keyup')
			{ 
				/* this will check to block ctrl, shift or alt + 
				buttons */ 
				if(evt.ctrlKey !== false || evt.shiftKey !== false || evt.altKey !== false || base.inArray(this.blockedKeys, evt.keyCode) !== -1)
				{ 
					return true; 
				}
			} 

			var target = evt.target || evt.srcElement; 
			var id = this.isDataBound(target); 
			if(id)
			{ 
				var connection = this.connections.get(id, 'bind'); 
				if(connection)
				{
					var value = connection.element.get(); 
					/* this will publish to the ui and to the
					model that subscribes to the element */ 
					pubSub.publish(id, value, target);
				} 
			}
			evt.stopPropagation();
		}, 

		/* this will setup the on change handler and 
		add the events. this needs to be setup before adding 
		the events. */ 
		changeHandler: null, 
		setupEvents: function() 
		{  
			this.changeHandler = base.bind(this, this.bindHandler); 

			this.addEvents();  
		}, 

		/* this will add the binder events */ 
		addEvents: function() 
		{ 
			base.on(["change", "keyup"], document, this.changeHandler, false); 
		}, 

		/* this will remove the binder events */
		removeEvents: function() 
		{ 
			base.off(["change", "keyup"], document, this.changeHandler, false);
		}
	}); 
	
	base.extend.DataBinder = new DataBinder(); 
})();

/* base framework module */ 
(function() 
{
	"use strict"; 
	
	/* this will get the model attributes. 
	@param (object) settings = the model settings 
	@return (object) the attributes */ 
	var setupAttrSettings = function(settings)
	{ 
		var attributes = {};
		if(!settings && typeof settings !== 'object')
		{ 
			return attributes; 
		}
		
		for(var prop in settings) 
		{ 
			if(settings.hasOwnProperty(prop)) 
			{ 
				var setting = settings[prop]; 
				if(typeof setting !== 'function')
				{ 
					attributes[prop] = setting;
					delete settings[prop]; 
				}
			}
		}
		return attributes; 
	}; 
	
	var DataBinder = base.DataBinder; 

	var Data = base.Class.extend(
	{ 
		constructor: function(settings)
		{  
			this._init();

			this.dirty = false; 

			/* this will setup the attributes object and the 
			attribute stage object */ 
			this.attributes = {};
			this.stage = {};

			/* this will setup the event sub for 
			one way binding */ 
			this.eventSub = new base.DataPubSub();

			/* this will set the construct attributes */ 
			var attributes = setupAttrSettings(settings); 
			this.set(attributes);     
		}, 

		dataTypeId: 'bd', 

		/* this will setup the data number and unique 
		instance id */ 
		_init: function()
		{
			var constructor = this.constructor; 
			this._dataNumber = (typeof constructor._dataNumber === 'undefined')? constructor._dataNumber = 0 : (++constructor._dataNumber);

			var dataId = this.dataTypeId + '-'; 
			this._id = dataId + this._dataNumber; 
		}, 

		/* this will get the unique model id 
		@return (string) the id */ 
		getDataId: function() 
		{ 
			return this._id; 
		}, 

		remove: function()
		{ 

		}, 

		on: function(attrName, callBack)
		{ 
			var message = attrName + ':change'; 
			return this.eventSub.on(message, callBack); 
		}, 

		off: function(attrName, token)
		{ 
			var message = attrName + ':change'; 
			this.eventSub.off(message, token); 
		}, 
		
		link: function(prop)
		{
			return {
				data: this, 
				prop: prop
			}; 
		}, 
		
		_deepDataPattern: /(\w+)|(?:\[(\d)\))/g,
		_deepDataTest: /(\.|\[)/,

		/* this will update an attr value. this supports 
		deep nested data. 
		@param (object) obj 
		@param (string) attr 
		@param (string) val */ 
		_updateAttr: function(obj, attr, val)
		{ 
			/* this will check if we need to update 
			deep nested data */ 
			var test = this._deepDataTest; 
			if(test.test(attr))
			{ 
				var prop, 
				pattern = this._deepDataPattern; 
				var props = attr.match(pattern), 
				length = props.length, 
				end = length - 1; 

				for (var i = 0; i < length; i++)
				{
					prop = props[i]; 

					/* this will add the value t0 the last prop */ 
					if(i === end)
					{
						obj[prop] = val;
						break;  
					} 

					if (obj[prop] === undefined) 
					{
						/* this will check to setup a new object 
						or an array if the prop is a number */ 
						obj[prop] = isNaN(prop)? {} : []; 
					}
					obj = obj[prop];
				}
			} 
			else 
			{ 
				obj[attr] = val; 
			}
		}, 

		_setAttr: function(id, attr, val, committer, stopMerge)
		{  
			/* this will check to update the model based on who 
			updated it. if the data binder updated the data only 
			the stage data is updated */ 
			if(!committer && stopMerge !== true)
			{ 
				/* this will update the attribute data because 
				it was updated outside the data binder */ 
				this._updateAttr(this.attributes, attr, val);
			}
			else 
			{ 
				if(this.dirty === false)
				{ 
					this.dirty = true;
				}
			}

			this._updateAttr(this.stage, attr, val);

			committer = committer || this;

			/* this will publish the data to the data binder 
			to update any ui elements that are subscribed */ 
			this._publish(id, attr, val, committer); 
		}, 

		set: function() 
		{
			var id = this._id + ':';

			var args = arguments; 
			if(typeof args[0] === 'object') 
			{ 
				var self = this; 
				var setupObject = function(object, committer, stopMerge) 
				{ 
					var items = object; 
					for(var attr in items) 
					{ 
						if(items.hasOwnProperty(attr)) 
						{ 
							var item = items[attr]; 
							if(typeof item === 'function')
							{ 
								continue; 
							} 
							self._setAttr(id, attr, item, committer, stopMerge);
						}
					}
				}; 

				setupObject(args[0], args[1], args[2]); 
			}
			else 
			{ 
				this._setAttr(id, args[0], args[1], args[2], args[3]); 
			}
		}, 

		/* this will recursivley update the data binder to 
		publish updates on values. this will convert the value
		to a string path to where the object is stored to allow 
		deep nested data to update on the bound elements. 
		@param (mixed) obj 
		@param (string) pathString */
		_publish: function(id, pathString, obj, committer)
		{ 
			pathString = pathString || ""; 
			if(obj && typeof obj === 'object')
			{ 
				var subPath, value; 
				if(Array.isArray(obj))
				{ 
					this._publishAttr(id, pathString, obj, committer); 

					var length = obj.length; 
					for(var i = 0; i < length; i++)
					{ 
						value = obj[i]; 
						subPath = pathString + '[' + i + ']';
						if(value && typeof value === 'object')
						{  
							this._publish(id, subPath, value, committer);
						} 
						else 
						{ 
							this._publishAttr(id, subPath, value, committer);
						}
					}
				}
				else 
				{ 
					this._publishAttr(id, pathString, obj, committer); 

					for(var prop in obj)
					{ 
						if(obj.hasOwnProperty(prop))
						{ 
							value = obj[prop]; 
							subPath = pathString + '.' + prop;
							if(value && typeof value === 'object')
							{ 
								this._publish(id, subPath, value, committer);
							}
							else 
							{ 
								this._publishAttr(id, subPath, value, committer);
							}
						}
					}
				}
			}
			else 
			{ 
				this._publishAttr(id, pathString, obj, committer); 
			}
			return pathString; 
		}, 

		_publishAttr: function(id, subPath, value, committer) 
		{
			/* save path and value */ 
			DataBinder.publish(id + subPath, value, committer); 
			/* this will check to update any local events 
			on the model */ 

			var message = subPath + ':change'; 
			this.eventSub.publish(message, value, committer);
		},

		mergeStage: function()
		{ 
			/* this will clone the stage object to the 
			attribute object */ 
			this.attributes = JSON.parse(JSON.stringify(this.stage)); 
			this.dirty = false; 
		}, 

		getModelData: function()
		{ 
			this.mergeStage(); 
			return this.attributes; 
		}, 

		revert: function() 
		{ 
			/* this will reset the stage to the previous 
			attributes */ 
			this.set(this.attributes); 
			this.dirty = false;
		}, 
		
		_getAttr: function(obj, attr) 
		{ 
			var test = this._deepDataTest; 
			if(test.test(attr))
			{ 
				var pattern = this._deepDataPattern; 
				var props = attr.match(pattern), 
				length = props.length, 
				end = length - 1; 

				for (var i = 0; i < length; i++)
				{
					var prop = props[i];
					var propValue = obj[prop];
					if (propValue !== undefined) 
					{
						obj = propValue;

						if(i === end)
						{
							return obj; 
						}
					} 
					else 
					{
						break;
					} 
				}

				return undefined;
			} 
			else 
			{ 
				return obj[attr]; 
			}
		}, 

		get: function(attrName) 
		{
			if(typeof attrName !== 'undefined')
			{ 
				return this._getAttr(this.stage, attrName);
			}
			else 
			{ 
				return this.getModelData();
			}
		}
	}); 
	
	/* 
		SimpleData 

		this will create a simple data object that supports
		flat data without allowing deep nesting. 

		@param [object] settings
	*/  

	var SimpleData = Data.extend(
	{ 
		constructor: function(settings)
		{  
			this._init();

			this.dirty = false; 
			this.stage = {};
			
			/* this will setup the event sub for 
			one way binding */ 
			this.eventSub = new base.DataPubSub();

			/* this will set the construct attributes */ 
			var attributes = setupAttrSettings(settings); 
			this.set(attributes);     
		}, 

		_setAttr: function(id, attr, val, committer, stopMerge)
		{  
			var prevValue = this.stage[attr]; 
			if(val === prevValue)
			{
				return false; 
			}
			
			this._updateAttr(this.stage, attr, val);

			committer = committer || this;

			/* this will publish the data to the data binder 
			to update any ui elements that are subscribed */ 
			this._publish(id, attr, val, committer, prevValue); 
		}, 
		
		_publish: function(id, attr, val, committer, prevValue)
		{
			var message = attr + ':change'; 
			this.eventSub.publish(message, val, prevValue, committer);

			committer = committer || this;

			DataBinder.publish(id + attr, val, committer);
		}
	});

	base.extend.Data = Data;
	base.extend.SimpleData = SimpleData; 

	/*
		Model

		this create a model module that can bind 
		the data using the dase data binder. 
		
		@param (object) settings = the new model properties 
		and methods 
	*/
	var Model = Data.extend(
	{ 
		constructor: function(settings)
		{  
			Data.call(this, settings);    

			this.initialize(); 

			this.xhr = null;  
		}, 

		initialize: function() 
		{ 

		}
	}); 
	
	/* this will get the model attributes. 
	@param (object) settings = the model settings 
	@return (object) the attributes */ 
	var setupDefaultAttr = function(settings)
	{ 
		var attributes = {};
		if(!settings || typeof settings !== 'object')
		{ 
			return attributes; 
		}
			
		var defaults = settings.defaults;
		if(!defaults)
		{ 
			return attributes; 
		}
			
		for(var prop in defaults) 
		{ 
			if(defaults.hasOwnProperty(prop)) 
			{ 
				var attr = defaults[prop]; 
				if(typeof attr !== 'function')
				{ 
					attributes[prop] = attr;
				}
			}
		}
		delete settings.defaults;
		return attributes; 
	}; 
	
	/* this will get the model attributes. 
	@param (object) settings = the model settings 
	@return (object) the attributes */ 
	var getXhr = function(settings)
	{ 
		if(!settings || typeof settings.xhr !== 'object')
		{ 
			return {}; 
		}
		
		var settingsXhr = settings.xhr; 
		var xhr = base.createObject(settingsXhr);
		delete settings.xhr; 
		return xhr;
	};

	/* this will track the number of model types */ 
	var modelTypeNumber = 0; 

	/* this will extend the model. 
	@param (object) settings = the new model properties 
	and methods 
	@param (object) the new model */ 
	Model.extend = function(settings)
	{   
		var parent = this; 
		
		var xhr = getXhr(settings); 
		var modelService = this.prototype.xhr.extend(xhr); 
		
		settings = settings || {}; 

		/* this will setup the default attribute settings for 
		the model */ 
		var defaultAttributes = setupDefaultAttr(settings); 
		var model = function(instanceSettings)
		{ 
			/* this will clone the original 
			instance settings object */ 
			if(instanceSettings && typeof instanceSettings === 'object')
			{ 
				instanceSettings = JSON.parse(JSON.stringify(instanceSettings)); 
			} 
			
			/* this will get the instance attributes that 
			the model will set as attribute data */ 
			var instanceAttr = setupAttrSettings(instanceSettings);

			/* we want to extend the default attr with the 
			instance attr before we set the data and call 
			the parent constructor */ 
			instanceAttr = base.extendObject(defaultAttributes, instanceAttr); 
			parent.call(this, instanceAttr);  
			
			/* this will setup the model service and 
			pass the new model instance to the service */ 
			this.xhr = new modelService(this);
		};  

		/* this will extend the model and add the static 
		methods to the new object */ 
		var extended = model.prototype = base.extendClass(this.prototype, settings); 
		extended.constructor = model;  
		extended.xhr = modelService; 

		/* this will assign a unique id to the model type */ 
		extended.dataTypeId = 'bm' + (modelTypeNumber++); 

		/* this will extend the static methods */ 
		base.extendObject(parent, model); 
		return model;  
	};

	base.extend.Model = Model; 
	
	/* 
		ModelService 
		
		this is a service that can connect a model to 
		a web service api. 
		
		@param (object) model 
	*/ 
	var ModelService = function(model)
	{ 
		this.model = model; 
		this.url = ''; 
		
		this.init(); 
	}; 
	
	ModelService.prototype = 
	{ 
		constrcutor: ModelService, 
		
		init: function() 
		{ 
			var model = this.model; 
			if(model && model.url)
			{ 
				this.url = model.url; 
			}
		}, 
		
		validateCallBack: null, 
		
		isValid: function()
		{ 
			var result = this.validate(); 
			if(result !== false)
			{ 
				var callBack = this.validateCallBack; 
				if(typeof callBack === 'function')
				{ 
					callBack(result); 
				}
			}
			return result; 
		},
		
		/* this is a method to use to override to set 
		a default validate methode to check the model 
		before sending data. 
		@return (bool) true or false to submit */
		validate: function()
		{ 
			return true;  
		},
		
		/* this is a method to use to override to set 
		a default param string to be appended to each 
		xhr request
		@return (string) params */ 
		getDefaultParams: function() 
		{ 
			return ''; 
		}, 
		
		/* this will add the individual params with the default 
		params. 
		@param (string) params 
		@return (string) the appended params */ 
		setupParams: function(params)
		{ 
			var defaults = this.getDefaultParams();
			params = this.addParams(params, defaults); 
			return params; 
		}, 
		
		parseQueryString: function(str) 
		{
			str = str || ''; 
			var objURL = {},
			regExp = /([^?=&]+)(=([^&]*))?/g;

			str.replace(regExp, function(a, b, c, d) 
			{
				/* we want to save the key and the
				value to the objURL */
				objURL[b] = d;
			});

			/* we want to check if the url has any params */
			return objURL;
		}, 
		
		/* this will add params strings. 
		@param (mixed) params 
		@param (mixed) addingParams 
		@return (string) the params combined */ 
		addParams: function(params, addingParams)
		{ 
			params = params || {};
			if(typeof params === 'string')
			{ 
				params = this.parseQueryString(params); 
			} 
			
			if(!addingParams)
			{ 
				return params;
			}
				
			if(typeof addingParams === 'string')
			{  
				addingParams = this.parseQueryString(addingParams);  
			} 

			if(this._isFormData(params))
			{ 
				for(var key in addingParams) 
				{ 
					if(addingParams.hasOwnProperty(key))
					{ 
						params.append(key, addingParams[key]);
					}
				}
			}
			else 
			{ 
				params = base.extendObject(params, addingParams);
			}
			
			return params; 
		}, 
		
		/* this is a property to override the return type 
		used in the the request and response xhr calls. this 
		will define what the web service defines as the object type. */ 
		objectType: 'item',  
		
		/* this will get a model object from the  service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance 
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@return (object) xhr object */ 
		get: function(instanceParams, callBack)
		{ 
			var id = this.model.get('id'); 
			var params = 'op=get' + 
						 '&id=' + id;  
			
			var model = this.model, 
			self = this; 
			return this.request(params, instanceParams, callBack, function(response)
			{ 
				if(response) 
				{ 
					/* this will update the model with the get request 
					response */ 
					var object = self.getObject(response); 
					if(object)
					{ 
						model.set(object);
					}
				}
			}); 
		}, 
		
		getObject: function(response)
		{ 
			/* this will update the model with the get request 
			response */ 
			var object = response[this.objectType] || response; 
			return object || false; 
		}, 
		
		setupObjectData: function()
		{
			var item = this.model.get();
			return this.objectType + '=' + base.prepareJsonUrl(item); 
		}, 
		
		/* this will add or update a model object to the service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance 
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@return (object) xhr object or false on error */
		setup: function(instanceParams, callBack)
		{ 
			if(!this.isValid())
			{ 
				return false; 
			}
				
			var params = 'op=setup' + 
						 '&' + this.setupObjectData(); 

			/* this will add the instance params with the 
			method params */ 
			params = this.addParams(params, instanceParams, instanceParams);

			return this.request(params, callBack); 
		}, 
		
		/* this will add a model object from the service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance 
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@return (object) xhr object or false on error*/
		add: function(instanceParams, callBack)
		{ 
			if(!this.isValid())
			{
				return false;
			}
			 
			var params = 'op=add' + 
						 '&' + this.setupObjectData(); 

			return this.request(params, instanceParams, callBack);
		}, 
		
		/* this will update a model object from the service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance 
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@return (object) xhr object or false on error*/
		update: function(instanceParams, callBack)
		{ 
			if(!this.isValid())
			{
				return false; 
			}
			
			var params = 'op=update' + 
						 '&' + this.setupObjectData(); 

			return this.request(params, instanceParams, callBack);
		}, 
		
		/* this will delete a model object from the service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance 
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@return (object) xhr object */
		delete: function(instanceParams, callBack)
		{ 
			var id = this.model.get('id'); 
			var params = 'op=delete' + 
						 '&id=' + id;  
			
			return this.request(params, instanceParams, callBack);
		}, 
		
		/* this will get a list of model object from the service. 
		@param [(string)] instanceParams = the params to add 
		to the service instance
		@param [(function)] callBack = the callBack to handle 
		the service xhr response
		@param [(int)] start = the row start count 
		@param [(int)] count = the row numbers to get 
		@param [(string)] filter = the filter
		@return (object) xhr object */
		all: function(instanceParams, callBack, start, count, filter)
		{ 
			filter = filter || ''; 
			start = !isNaN(start)? start : 0; 
			count = !isNaN(count)? count : 50;
			
			var params = 'op=all' + 
						 '&option=' + filter + 
						 '&start=' + start + 
						 '&stop=' + count; 
			
			return this.request(params, instanceParams, callBack);
		}, 
		
		setupRequest: function(method, params, callBack, requestCallBack)
		{ 
			var self = this;
			var settings = { 
				url: this.url, 
				type: method, 
				params: params, 
				completed: function(response, xhr)
				{ 
					if(typeof requestCallBack === 'function') 
					{ 
						requestCallBack(response);
					}
					 
					self.getResponse(response, callBack, xhr);
				}
			}; 
			
			var overrideHeader = this._isFormData(params);
			if(overrideHeader)
			{
				settings.headers = {}; 
			}
			
			return base.ajax(settings);
		}, 
		
		_isFormData: function(data)
		{
			return data instanceof FormData; 
		}, 
		
		/* this will make the xhr request to the 
		service. 
		@param (string) params 
		@param (string) instanceParams = the params to add 
		to the service instance
		@param (function) callBack 
		@param [(function)] requestCallBack = the call back for the
		service method
		@return (object) xhr object */ 
		request: function(params, instanceParams, callBack, requestCallBack)
		{ 
			return this._request('POST', params, instanceParams, callBack, requestCallBack); 
		}, 
		
		_get: function(params, instanceParams, callBack, requestCallBack)
		{ 
			return this._request('GET', params, instanceParams, callBack, requestCallBack); 
		}, 
		
		_post: function(params, instanceParams, callBack, requestCallBack)
		{ 
			return this._request('POST', params, instanceParams, callBack, requestCallBack); 
		}, 
		
		_put: function(params, instanceParams, callBack, requestCallBack)
		{ 
			return this._request('PUT', params, instanceParams, callBack, requestCallBack); 
		}, 
		
		_delete: function(params, instanceParams, callBack, requestCallBack)
		{ 
			return this._request('DELETE', params, instanceParams, callBack, requestCallBack); 
		}, 
		
		_request: function(method, params, instanceParams, callBack, requestCallBack)
		{
			params = this.setupParams(params); 
			params = this.addParams(params, instanceParams);
			
			return this.setupRequest(method, params, callBack, requestCallBack);
		}, 
		
		/* this will handle the xhr response. 
		@param (mixed) response = the xhr response 
		@param (function) callBack
		@param (object) the xhr object */
		getResponse: function(response, callBack, xhr)
		{ 
			/* this will check to return the response 
			to the callBack function */ 
			if(typeof callBack === 'function')
			{ 
				callBack(response, xhr); 
			}
		}
	}; 
	
	/* this will setup the service object to extend itself. 
	@param (object) settings = the new service settings to 
	extend 
	@return (object) the new model service */ 
	ModelService.extend = function(settings)
    { 
    	var parent = this; 
        
		/* this will setup a new model service constructor */ 
		var modelService = function(model)
		{ 
			/* this will call the parent contructor */ 
			parent.call(this, model);
		};  

		/* this will extend the model and add the static 
		methods to the new object */ 
		modelService.prototype = base.extendClass(this.prototype, settings); 
		modelService.prototype.constructor = modelService;
        
        base.extendObject(parent, modelService); 

		return modelService;
    };
	
	/* we need to add the service object to the 
	model prototype as the xhr service */ 
	Model.prototype.xhr = ModelService; 
})();

/* base framework module */ 
/* 
	this will create dynamic html to be 
	added and modified  
*/ 
(function() 
{
	"use strict"; 
	
	var DataTracker = base.DataTracker, 
	DataBinder = base.DataBinder; 
	
	var filterProperty = function(prop) 
	{ 
		switch(prop) 
		{ 
			case 'class': 
				prop = 'className'; 
				break; 
			case 'text': 
				prop = 'textContent'; 
				break;
			case 'for': 
				prop = 'htmlFor'; 
				break; 
			case 'readonly': 
				prop = 'readOnly'; 
				break; 
			case 'maxlength': 
				prop = 'maxLength'; 
				break; 
			case 'cellspacing': 
				prop = 'cellSpacing'; 
				break; 
			case 'rowspan': 
				prop = 'rowSpan'; 
				break; 
			case 'colspan': 
				prop = 'colSpan'; 
				break; 
			case 'tabindex': 
				prop = 'tabIndex'; 
				break; 
			case 'cellpadding': 
				prop = 'cellPadding'; 
				break; 
			case 'usemap': 
				prop = 'useMap'; 
				break; 
			case 'frameborder': 
				prop = 'frameBorder'; 
				break; 
			case 'contenteditable': 
				prop = 'contentEditable'; 
				break;
		} 

		return prop; 
	}; 

	/* this will return the property without the on prefix */ 
	var removePrefix = function(prop) 
	{ 
		if(typeof prop !== 'undefined') 
		{ 
			if(prop.substring(0, 2) === 'on') 
			{ 
				prop = prop.substring(2);   
			}  
		} 
		return prop; 
	};
	
	/* we want to save the methods to the prototype 
	to allow inheritance */ 
	var htmlBuilder = base.Class.extend( 
	{ 
		constructor: function()
		{ 

		}, 
		
		/* this will create an html element by nodeType, add to 
		the specified parent container and return the new 
		element. 
		@param (string) nodeType = the element node type name
		@param (object) attrObject = the node attributes to add 
		to the element. 
		@param (mixed) container = the parent container element 
		or id 
		@param (bool) prepend = this will add the element 
		to the begining of theparent */
		create: function(nodeName, attrObject, container, prepend)
		{ 
			var obj = document.createElement(nodeName);
			this._addElementAttrs(obj, attrObject); 
			
			/* we want to check if the new element should be 
			added to the begining or end */ 
			if(prepend === true) 
			{ 
				this.prepend(container, obj); 
			} 
			else 
			{ 
				this.append(container, obj); 
			} 
			return obj;  
		}, 
		
		_addElementAttrs: function(obj, attrObject)
		{
			/* we want to check if we have attrributes to add */ 
			if(!attrObject || typeof attrObject !== 'object') 
			{ 
				return false; 
			}
			
			/* we need to add the type if set to stop ie 
			from removing the value if set after the value is 
			added */ 
			var type = attrObject.type; 
			if(typeof type !== 'undefined') 
			{ 
				base.attr(obj, 'type', type); 
			} 

			/* we want to add each attr to the obj */ 
			for(var prop in attrObject) 
			{   
				/* we have already added the type so we need to 
				skip if the prop is type */
				if(attrObject.hasOwnProperty(prop) === false || prop === 'type')
				{ 
					continue; 
				} 

				var attrPropValue = attrObject[prop]; 

				/* we want to check to add the attr settings
				 by property name */  
				if(prop === 'innerHTML') 
				{ 
					this.addHtml(obj, attrPropValue); 
				} 
				else if(prop.substring(0, 5) === 'data-') 
				{ 
					base.data(obj, prop, attrPropValue); 
				}
				else 
				{ 
					this.addAttr(obj, prop, attrPropValue);
				}
			}
		}, 
		
		addHtml: function(obj, content)
		{
			if(typeof content !== 'undefined' && content !== '') 
			{
				/* we need to check if we are adding inner 
				html content or just a string */
				var pattern = /(?:<[a-z][\s\S]*>)/i; 
				if(pattern.test(content)) 
				{ 
					/* html */ 
					obj.innerHTML = content; 
				} 
				else 
				{ 
					/* string */ 
					obj.textContent = content;
				}
			}
		}, 
		
		addAttr: function(obj, attr, value)
		{
			if(value === '' || !attr) 
			{ 
				return false; 
			}
			
			var attrName = filterProperty(attr); 
				
			/* we want to check to add a value or an event listener */ 
			var type = typeof value;
			if(type === 'function') 
			{ 
				/* this will add the event using the base events 
				so the event istracked */ 
				attrName = removePrefix(attrName); 
				base.addListener(attrName, obj, value); 
			} 
			else 
			{ 
				obj[attrName] = value;
			}
		}, 
		
		/* this will create a document fragment to allow elements 
		to be added to a container element without rendering until the 
		fragment gets appended to an element. 
		@return (object) the document fragment */ 
		createDocFragment: function() 
		{ 
			return document.createDocumentFragment();  
		}, 
		
		/* this will create a text node 
		@param (string) text 
		@param (mixed) container = the element parent id or parent object 
		to the begining */
		createTextNode: function(text, container)
		{ 
			var obj = document.createTextNode(text); 
			
			if(container)
			{ 
				this.append(container, obj);
			}
			return obj; 
		}, 
		
		/* this will add options to a select   
		@param (mixed) selectElem = the select element or id  
		@param (array) optionArray = and array with objects 
		to use as options 
		@param [(string)] defaultValue = the select default 
		value */ 
		setupSelectOptions: function(selectElem, optionArray, defaultValue) 
		{ 
			if(!selectElem || typeof selectElem !== 'object') 
			{ 
				return false; 
			}
				
			if(!optionArray || optionArray.length) 
			{ 			
				return false;  
			} 
			
			/* create each option then add it to the select */   
			for(var n = 0, maxLength = optionArray.length; n < maxLength; n++) 
			{ 
				var settings = optionArray[n];
				var option = selectElem.options[n] = new Option(settings.label, settings.value); 

				/* we can select an option if a default value 
				has been sumbitted */ 
				if(defaultValue !== null) 
				{ 
					if(option.value == defaultValue) 
					{ 
						option.selected = true;   
					} 
				} 
			}
		}, 
		
		/* this will remove the elmenents data and events 
		for the elmeent and all child elements. 
		@param (object) ele */ 
		removeElementData: function(ele)
		{ 
			/* we want to do a recursive remove child 
			removal */ 
			var children = ele.childNodes; 
			if(children) 
			{ 
				var length = children.length;  
				for(var i = 0; i < length; i++) 
				{ 

					var child = children[i]; 
					if(child) 
					{ 
						/* this will remove the child elmenet data 
						before the parent is removed */ 
						this.removeElementData(child); 
					}
				} 
			} 
			
			DataTracker.remove(ele); 

			/* this will loop though the element attrs to 
			check for any event listeners to cancel and 
			remove any data binding */ 
			var attributes = ele.attributes; 
			if(attributes) 
			{ 
				var db = DataBinder || false;
				/* this will only remove the data bind */ 
				var bound = attributes['data-bind-id']; 
				if(bound)
				{ 
					/* this will check to remove any data bindings 
					to the element */ 
					db.unbind(ele);
				} 
			}
		}, 
		
		/* this will remove an element from a parent and 
		remove all attr and events added to the element and its child 
		elements. 
		@param (object) child = the child element */
		removeElement: function(obj) 
		{ 
			var container; 
			
			if(!obj || !(container = obj.parentNode)) 
			{ 
				return this; 
			}  

			/* this will remove all element data and binding 
			and remove from the parent container */ 
			this.removeElementData(obj);
			container.removeChild(obj); 

			return this;
		}, 
		
		/* this is an alias for removeElement. This will remove a 
		child element.   
		@param (object) child = the child element */
		removeChild: function(child) 
		{ 
			this.removeElement(child);   
		}, 
		
		/* this will remove all child elements.    
		@param (object) container = the container element */
		removeAll: function(container) 
		{ 
			if(typeof container === 'object') 
			{ 
				var children = container.childNodes; 
				for(var child in children) 
				{  
					if(children.hasOwnProperty(child))
					{
						this.removeElementData(children[child]);
					}
				} 
				container.innerHTML = ''; 
			}
		},  
		
		changeParent: function(child, newParent) 
		{ 
			if(typeof child === 'string') 
			{ 
				child = document.getElementById(child);  
			}  
			
			var container = (typeof newParent === 'string')? document.getElementById(newParent) : newParent; 
			container.appendChild(child); 
		}, 
		
		append: function(parent, child) 
		{ 
			switch(typeof parent) 
			{
				case "object": 
					break;
				case "string": 
					parent = document.getElementById(parent);
					break;
				case "undefined": 
					parent = document.body;
					break;	
			}
			 
			parent.appendChild(child);  
		},  
		
		prepend: function(parent, child) 
		{ 
			switch(typeof parent) 
			{
				case "object": 
					break;
				case "string": 
					parent = document.getElementById(parent);
					break;
				case "undefined": 
					parent = document.body;
					break;
			}
		 
			parent.insertBefore(child, parent.firstChild); 
		},  
		
		/* this will clone a node and return the 
		copy or false */ 
		clone: function(node, deepCopy) 
		{ 
			if(node && typeof node === 'object') 
			{ 
				deepCopy = deepCopy || false; 
				return node.cloneNode(deepCopy); 
			} 
			else 
			{ 
				return false; 
			} 
		} 
	}); 
	
	/* we want to use a few private functions to add input selection 
	to an element and reduce any closures */ 
	var focusElement = function(e)
	{ 
		e = e || window.event; 
		var src = e.srcElement || e.target; 
		src.select();  
	}; 
	
	base.extend.htmlBuilder = htmlBuilder; 
	
})();

/* base framework module */
/*
	this will create a layout builder object
	and shortcut functions.
*/
(function()
{
	"use strict"; 

	/*
		LayoutParser

		this will parse json object layouts.
	*/
	var LayoutParser = base.Class.extend(
	{
		_excludedProperties: [
			'tag', 
			'bind',
			'onCreated', 
			'route', 
			'onSet', 
			'onState', 
			'watch'
		], 
		
		getElementTag: function(obj)
		{
			var type = 'div';

			var node = obj.tag || obj.t; 
			if (typeof node !== 'undefined')
			{
				type = obj.tag = node;
			}

			return type;
		}, 

		/* this will parse a layout element.
		@param (object) obj
		@param (mixed) container = a container element
		object or container id string */
		parseElement: function(obj)
		{
			var attr = {},
			children = [];

			var tag = this.getElementTag(obj); 
			if(tag === 'button') 
			{ 
				attr.type = 'button'; 
			}
			
			var excluded = this._excludedProperties; 

			for (var key in obj)
			{
				if (obj.hasOwnProperty(key))
				{
					if (base.inArray(excluded, key) !== -1)
					{
						continue;
					}

					var value = obj[key];
					/* we need to filter the children from the attr
					settings. the children need to keep their order. */
					if (typeof value !== 'object')
					{
						attr[key] = value;
					}
					else
					{
						if (key === 'children')
						{
							children = children.concat(value);
						}
						else
						{
							children.push(value);
						}
					}
				}
			} 

			return {
				tag: tag,
				attr: attr,
				children: children
			}; 
		}
	}); 
	
	var WatcherHelper = 
	{
		_getWatcherProps: function(string)
		{
			var pattern = /\[\[([^\]]+)\]\]/g; 
			var matches = string.match(pattern); 
			if(matches)
			{
				pattern = /(\[\[|\]\])/g; 
				for(var i = 0, length = matches.length; i < length; i++) 
				{
					matches[i] = matches[i].replace(pattern, ''); 
				}
			}
			return matches; 
		}, 
		
		updateAttr: function(ele, attr, value)
		{
			if(attr === 'text' || attr === 'textContent')
			{
				ele.textContent = value; 
			}
			else if(attr === 'innerHTML')
			{
				ele.textContent = value; 
			}
			else 
			{
				base.attr(ele, attr, value);
			}
		}, 
		
		_getWatcherCallBack: function(ele, data, string, attr, isArray)
		{
			var self = this;
			var pattern = /(\[\[([^\]]+)\]\])/g; 
			return function()
			{
				var count = -1; 
				var value = string.replace(pattern, function()
				{
					var watcherData = (isArray)? data[count] : data;
					count++; 
					return watcherData.get(arguments[2]); 
				}); 
				self.updateAttr(ele, attr, value);  
			}; 
		}, 
		
		_getData: function(isArray, settings, parent)
		{
			return (isArray)? settings.value[1] : (parent.data || parent.state);
		}, 
		
		_getString: function(isArray, settings)
		{
			return (isArray)? settings.value[0] : settings.value;
		}, 
		
		addDataWatcher: function(ele, settings, parent)
		{
			var isStringArray = base.isArray(settings.value);
			var data = this._getData(isStringArray, settings, parent); 
			if(!data)
			{
				return false; 
			}
			
			var string = this._getString(isStringArray, settings), 
			isDataArray = base.isArray(data);
			
			var callBack, 
			overrideCallBack = settings.callBack; 
			if(typeof overrideCallBack === 'function')
			{
				callBack = function()
				{
					overrideCallBack(ele); 
				}; 
			} 
			else 
			{
				var attr = settings.attr || 'textContent'; 
				callBack = this._getWatcherCallBack(ele, data, string, attr, isDataArray); 
			}
			
			var props = this._getWatcherProps(string);
			for(var i = 0, length = props.length; i < length; i++)
			{
				var watcherData = (isDataArray)? data[i] : data; 
				this.addWatcher(ele, watcherData, props[i], callBack);
			}
		}, 
		
		setup: function(ele, settings, parent)
		{
			if(!settings)
			{
				return false; 
			}
			
			this.addDataWatcher(ele, settings, parent);
		}, 
		
		addWatcher: function(ele, data, prop, callBack)
		{
			/* we need to initilize the watcher to set the 
			initial data. */ 
			callBack(); 
			
			base.DataBinder.watch(ele, data, prop, callBack);
		}
	};
	
	var parser = new LayoutParser(); 

	/*
		LayoutBuilder

		this will build json object layouts.
	*/
	var LayoutBuilder = base.htmlBuilder.extend(
	{
		/* this will build a layout object.
		@param (object) obj
		@param (mixed) container = a parent element
		object or parent id string
		@param [(object)] parent = the parent component
		@return (object) a doc frag element with the layout */
		build: function(obj, container, parent)
		{
			var fragment = this.createDocFragment();

			if (base.isArray(obj))
			{
				var item; 
				for (var i = 0, length = obj.length; i < length; i++)
				{
					item = obj[i];
					this.buildElement(item, fragment, parent);
				}
			} 
			else
			{
				this.buildElement(obj, fragment, parent);
			}

			if(container && typeof container === 'object')
			{ 
				container.appendChild(fragment);
			}
			return fragment;
		},

		/* this will parse a layout element.
		@param (object) obj
		@param (mixed) container = a container element
		object or container id string */
		buildElement: function(obj, container, parent)
		{
			if(obj.component || obj instanceof base.Component)
			{
				this.createComponent(obj, container);
			} 
			else 
			{
				this.createElement(obj, container, parent); 
			}
		}, 

		/* this will override the parent append method to remove 
		the checks. 
		@param (object) parent
		@param (object) child */ 
		append: function(parent, child) 
		{ 
			parent.appendChild(child);  
		}, 

		createElement: function(obj, container, parent)
		{
			var settings = parser.parseElement(obj);
			var ele = this.createNode(settings, container); 

			if(typeof obj.onCreated === 'function') 
			{ 
				obj.onCreated(ele); 
			} 

			/* this will check to bind the element to 
			the prop of a data */ 
			var bind = obj.bind;
			if(bind)
			{ 
				this.bindElement(ele, bind, parent);  
			} 
			
			if(obj.route)
			{
				this.addRoute(ele, obj.route); 
			}
			
			var onState = obj.onState; 
			if(onState && onState.length)
			{
				this.onState(ele, onState[0], onState[1], parent);
			}
			
			var onSet = obj.onSet; 
			if(onSet && onSet.length)
			{
				this.onSet(ele, onSet[0], onSet[1], parent);
			}
			
			if(obj.watch)
			{
				this.watch(ele, obj.watch, parent); 
			}

			/* we want to recursively add the children to
			the new element */
			var children = settings.children;
			if (children.length > 0)
			{
				var child; 
				for (var i = 0, length = children.length; i < length; i++)
				{
					child = children[i];
					this.buildElement(child, ele, parent);
				}
			}
		}, 
		
		bindElement: function(ele, bind, parent)
		{
			var data, prop, filter; 
			
			if(typeof bind === 'string')
			{ 
				if(!parent || !parent.data)
				{
					return false; 
				} 
				
				data = parent.data; 
				prop = bind; 
			} 
			else if(base.isArray(bind)) 
			{
				if((typeof bind[0] !== 'object'))
				{
					if(!parent)
					{
						return false; 
					} 
					
					var dataSource = (parent.data || parent.state); 
					if(dataSource)
					{
						bind.unshift(dataSource); 
					}
				}
				
				data = bind[0]; 
				prop = bind[1]; 
				filter = bind[2]; 
			}
			
			base.DataBinder.bind(ele, data, prop, filter);
		}, 
		
		addRoute: function(ele, route)
		{
			if(!route)
			{
				return false; 
			} 
			
			if(base.isArray(route))
			{
				for(var i = 0, length = route.length; i < length; i++)
				{
					this.setupRoute(ele, route[i]); 
				}
			} 
			else 
			{
				this.setupRoute(ele, route);
			}
		}, 
		
		setupRoute: function(ele, route)
		{
			route.container = ele; 
			var newRoute = base.router.add(route); 
			
			base.DataTracker.add(ele, 'routes', 
			{
				route: newRoute
			});
		}, 
		
		watch: function(ele, watcher, parent)
		{
			if(!watcher)
			{
				return false; 
			} 
			
			if(base.isArray(watcher))
			{
				for(var i = 0, length = watcher.length; i < length; i++)
				{
					WatcherHelper.setup(ele, watcher[i], parent); 
				}
			}
			else 
			{
				WatcherHelper.setup(ele, watcher, parent);
			}
		}, 
		
		onState: function(ele, action, callBack, parent)
		{
			if(!parent)
			{
				return false; 
			}
			
			this.onUpdate(ele, parent.state, action, callBack);
		}, 
		
		onSet: function(ele, prop, callBack, parent)
		{
			if(!parent)
			{
				return false; 
			}
			
			this.onUpdate(ele, parent.data, prop, callBack); 
		}, 
		
		onUpdate: function(ele, data, prop, callBack)
		{
			if(!data || !prop)
			{
				return false; 
			}
			
			var self = this, 
			type = typeof callBack, 
			update = function(value) 
			{
				self.updateElement(type, ele, callBack, value); 
			}; 

			base.DataBinder.watch(ele, data, prop, update);

			var value = data.get(prop); 
			if(typeof value !== 'undefined')
			{
				update(value); 
			}
		}, 
		
		updateElement: function(type, ele, callBack, value)
		{
			if(type === 'function')
			{
				var result = callBack(ele, value); 
				switch(typeof result)
				{
					case 'object':
						this.resetAndBuild(ele, result, parent);
						break; 
					case 'string':
						this.addHtml(ele, result);
						break;
				}
			} 
			else 
			{
				this.addClass(ele, callBack, value); 
			}
		}, 
		
		addClass: function(ele, stateStyles, newValue)
		{
			if(!stateStyles || typeof stateStyles !== 'object')
			{
				return false; 
			}
			
			for(var prop in stateStyles)
			{
				if(!stateStyles.hasOwnProperty(prop) || !prop)
				{
					continue; 
				}
				
				var value = stateStyles[prop];
				if(value === newValue)
				{
					base.addClass(ele, prop);
				} 
				else 
				{
					base.removeClass(ele, prop);
				}
			}
		}, 
		
		resetAndBuild: function(ele, layout, parent)
		{
			this.removeAll(ele); 
			this.build(layout, ele, parent);
		}, 

		createComponent: function(obj, container)
		{
			// this will allow both cached components or native components
			var component = obj.component || obj; 
			component.setup(container);  

			if(typeof obj.onCreated === 'function') 
			{ 
				obj.onCreated(component); 
			}
		}, 

		createNode: function(settings, container)
		{ 
			var tag = settings.tag; 
			if(tag !== 'text')
			{ 
				return this.create(tag, settings.attr, container); 
			}

			var attr = settings.attr; 
			var text = attr.textContent || attr.text; 
			return this.createTextNode(text, container);
		}
	});

	var builder = base.extend.builder = new LayoutBuilder(); 

	/* this will build a layout object.
	@param (object) obj
	@param (object) container = a parent element 
	@param [(object)] parent = the parent component
	@return (object) a reference to the object */
	base.extend.buildLayout = function(obj, container, parent)
	{
		builder.build(obj, container, parent);
	};
})();

/* base framework module */ 
(function() 
{
	"use strict"; 
	
	/* 
		EventHelper 

		this will create an event manager used to 
		add and remove events.  
	*/ 
	var EventHelper = base.Class.extend(
	{
		constructor: function()
		{ 
			this.events = []; 
		}, 
		
		addEvents: function(events)
		{
			if(events.length < 1)
			{
				return false; 
			}
				
			for(var i = 0, length = events.length; i < length; i++)
			{ 
				var event = events[i]; 
				this.on(event[0], event[1], event[2], event[3]);   
			}
		},

		/* this will add an event to the events array 
		and setup the event listener. 
		@param (string) event 
		@param (object) obj 
		@param (function) callBack 
		@param [(bool)] capture */ 
		on: function(event, obj, callBack, capture)
		{ 
			base.on(event, obj, callBack, capture); 

			this.events.push({
				event: event, 
				obj: obj, 
				callBack: callBack, 
				capture: capture
			}); 
		}, 

		/* this will remove an event from the events array 
		and setup the event listener. 
		@param (string) event 
		@param (object) obj 
		@param (function) callBack 
		@param [(bool)] capture */
		off: function(event, obj, callBack, capture)
		{ 
			base.off(event, obj, callBack, capture); 

			var option, 
			events = this.events; 
			for(var i = 0, length = events.length; i < length; i++) 
			{ 
				option = events[i]; 
				if(option.event === event && option.obj === obj) 
				{ 
					events.splice(i, 1); 
					break; 
				}
			}
		}, 

		set: function()
		{
			var event, 
			events = this.events; 
			for(var i = 0, length = events.length; i < length; i++) 
			{ 
				event = events[i]; 
				base.on(event.event, event.obj, event.callBack, event.capture); 
			}
		}, 

		unset: function()
		{
			var event, 
			events = this.events; 
			for(var i = 0, length = events.length; i < length; i++) 
			{ 
				event = events[i]; 
				base.off(event.event, event.obj, event.callBack, event.capture); 
			}
		}, 

		/* this will remove and reset all the events */ 
		reset: function()
		{ 
			this.unset();  
			this.events = []; 
		}
	}); 

	base.extend.EventHelper = EventHelper; 
	
	/* this will register the component system to the 
	data tracker to remove components that have been 
	nested in layouts. */ 
	base.DataTracker.addType('components', function(data)
	{
		if(!data)
		{
			return false; 
		}
		
		var component = data.component; 
		if(component && component.rendered === true)
		{
			component.destroy(); 
		}
	});
	
	var StateHelper = 
	{
		/* this will create a state object used to initilize 
		component states 
		@param (string) action = the state action 
		@param [(string)] state = the default state 
		@param [(function)] callBack = the callBack that is called 
		when the state is changed 
		@return (object) */ 
		createState: function(action, state, callBack, targetId)
		{ 
			return {
				action: action, 
				state: state, 
				callBack: callBack, 
				targetId: targetId
			}; 
		}, 

		_convertActionObject: function(action)
		{
			var actions = []; 
			for(var prop in action)
			{
				if(action.hasOwnProperty(prop) === false)
				{
					continue; 
				}
					
				var value = action[prop]; 
				if(value && typeof value === 'object')
				{
					actions.push(this.createState(
						prop, 
						value.state, 
						value.callBack, 
						value.targetId
					)); 
				}
				else 
				{
					actions.push(this.createState(
						prop, 
						value
					)); 
				}
			}
			return actions; 
		}, 
		
		removeActions: function(actions)
		{
			if(actions.length < 1)
			{
				return false; 
			}
				
			for(var i = 0, length = actions.length; i < length; i++)
			{ 
				var action = actions[i]; 
				base.state.remove(action.targetId, action.action, action.token);
			}
		}, 
		
		bindRemoteState: function(target, actionEvent, remoteTargetId)
		{
			var token, 
			remoteTarget = base.state.getTarget(remoteTargetId); 
			
			var value = remoteTarget.get(actionEvent); 
			if(typeof value !== 'undefined')
			{
				target.set(actionEvent, value); 
			}

			token = remoteTarget.on(actionEvent, function(state, prevState, committer)
			{
				if(committer === target)
				{
					return false; 
				}

				target.set(actionEvent, state, remoteTarget); 
			});

			target.on(actionEvent, function(state, prevState, committer)
			{
				if(committer === remoteTarget)
				{
					return false; 
				}

				remoteTarget.set(actionEvent, state, target); 
			});
			
			return token; 
		}, 
		
		addAction: function(target, action)
		{
			var token,  
			actionEvent = action.action;
			
			/* this will check to select the remote target if set */ 
			var targetId = action.targetId; 
			if(targetId)
			{
				token = this.bindRemoteState(target, actionEvent, targetId); 
			}

			if(typeof action.state !== 'undefined')
			{
				target.addAction(actionEvent, action.state);
			} 
			
			var callBack = action.callBack; 
			if(typeof callBack === 'function')
			{ 
				target.on(actionEvent, callBack);
			}
			
			return token; 
		}, 

		setupActions: function(actions)
		{
			if(base.isEmpty(actions))
			{
				return [];
			}
			
			/* this will convert the state object to a
			state array */ 
			return this._convertActionObject(actions);
		}
	}; 
	

	/* 
		Component 

		this will allow components to be extend 
		from a single factory. 

		example: 

		var QuickFlashPanel = base.Component.extend(
		{ 
			constructor: function(container)
			{ 
				// this will setup the component id  
				base.Component.call(this, container); 
			}, 

			render: function()
			{ 
				return {

				}; 
			}
		});  

	*/ 

	var Component = base.Class.extend( 
	{ 
		constructor: function(props) 
		{ 
			this.init(); 
			this.setupProps(props); 

			this.rendered = false; 
			this.container = null; 
		},

		/* this will setup the component number and unique 
		instance id for the component elements. */ 
		init: function()
		{
			var constructor = this.constructor; 
			this.number = (typeof constructor.number === 'undefined')? constructor.number = 0 : (++constructor.number);

			var name = this.overrideTypeId || this.componentTypeId; 
			this.id = name + this.number; 
		}, 
		
		setupProps: function(props)
		{
			if(!props || typeof props !== 'object')
			{
				return false; 
			}
			
			for(var prop in props)
			{
				if(props.hasOwnProperty(prop))
				{
					this[prop] = props[prop]; 
				}
			}
		}, 

		/* this will return the json layout object.   
		@return (object) layout */
		render: function()
		{ 
			return {

			}; 
		}, 

		_cacheRoot: function(layout)
		{
			if(!layout)
			{
				return layout; 
			}

			if(!layout.id)
			{
				layout.id = this.getId(); 
			}

			if(typeof layout.onCreated !== 'function')
			{
				layout = this.cache('panel', layout); 
			}
			return layout; 
		}, 

		prepareLayout: function()
		{
			var layout = this.render(); 
			return this._cacheRoot(layout); 
		}, 

		buildLayout: function()
		{ 
			var layout = this.prepareLayout(); 
			this.build(layout, this.container); 
			
			base.DataTracker.add(this.panel, 'components', 
			{
				component: this
			}); 
			
			this.rendered = true; 
		}, 

		/* this will build a json layout object. 
		@param (object) layout 
		@param [(object)] container 
		@return (object) the doc fragment used to create the 
		layout */ 
		build: function(layout, container) 
		{ 
			return base.builder.build(layout, container, this);
		}, 

		/* this will cache an element by saving a pointer property
		from the element to the component after it has been created. 
		@param (string) propName 
		@param (object) layout = the json layout of the element or
		component to be cached
		@param (object) callBack
		@return (object) the modifiedjson layout code */ 
		cache: function(propName, layout, callBack) 
		{ 
			if(!layout || typeof layout !== 'object')
			{ 
				return false; 
			}
			
			if(layout instanceof base.Component)
			{
				layout = 
				{
					component: layout
				};
			} 

			var self = this;
			layout.onCreated = function(element)
			{ 
				self[propName] = element; 

				if(typeof callBack === 'function')
				{
					callBack(element); 
				}
			};
			return layout; 
		}, 

		/* if an id is set this will return a namespace id 
		that can be set on an element or the defualt id 
		will be returned 
		@param (string) id 
		@return (string) */ 
		getId: function(id)
		{ 
			var mainId = this.id; 
			if(typeof id === 'string')
			{ 
				mainId += '-' + id; 
			}
			return mainId; 
		}, 

		/* this will create a bind object for the layout parser.  
		@param (object) data 
		@param (string) prop

		or if the component has a model set you can leave out 
		the data
		@param (string) prop */ 
		bind: function(data, prop, filter) 
		{ 
			/* this will check to set the default data if the 
			data was not set */ 
			if(typeof data !== 'object')
			{ 
				var mainData = this.data; 
				if(mainData)
				{
					filter = prop; 
					prop = data; 
					data = mainData; 
				}
			} 

			return {
				data: data, 
				prop: prop, 
				filter: filter
			}; 
		},  

		initialize: function()
		{ 
			this.beforeSetup(); 
			this.addStates();
			this.buildLayout(); 
			this.addEvents(); 
			this.afterSetup(); 
		}, 

		beforeSetup: function()
		{

		}, 

		afterSetup: function()
		{

		}, 

		/* this is a method that should be overridden to 
		setup and render the component
		@param (object) container */ 
		setup: function(container) 
		{ 
			this.container = container; 
			this.initialize();  
		}, 

		/* this will allow the component to override the 
		state target id to add a custom id */ 
		stateTargetId: null, 

		/* this will setup the component state manager. 
		@param [(string)] id */ 
		setupStateManager: function(id)
		{
			/* this will block the setup if the state has been 
			setup previously. */ 
			if(this.state)
			{ 
				return false; 
			}
				
			var targetId = id || this.stateTargetId || this.id; 
			this.state = base.state.getTarget(targetId); 
		}, 

		/* this should be overriden to pass an array with 
		all of the component states. 
		@return (mixed) an array or state object */ 
		setupStates: function()
		{ 
			/* 
			return {
				action: 'state'
			}; 

			or 

			return {
				action: 
				{
					state: 'state', 
					callBack: function(state, prevState)
					{

					}
				}
			};*/ 
			
			return {
				
			}; 
		}, 

		_getStateHelper: function()
		{
			var actions = this.setupStates(); 
			/* this will convert the state object to a
			state array */ 
			return StateHelper.setupActions(actions);
		}, 

		_setupStateHelper: function(actions)
		{
			this._remoteStates = []; 
			this.setupStateManager(); 
			
			var state = this.state, 
			stateActions = StateHelper; 
			
			for(var i = 0, length = actions.length; i < length; i++)
			{ 
				var action = actions[i], 
				token = stateActions.addAction(state, action);
				
				if(action.targetId)
				{
					action.token = token; 
					this._remoteStates.push(action);
				}   
			}
		}, 

		/* this will setup all the states returned by the 
		setupStates method. */ 
		addStates: function()
		{ 
			/* this will only setupa state manager if 
			we have states */ 
			var actions = this._getStateHelper(); 
			if(actions.length < 1)
			{ 
				return false; 
			} 

			this._setupStateHelper(actions);
		}, 

		/* this will remove all the states on the component. */ 
		removeStates: function()
		{ 
			var state = this.state; 
			if(!state)
			{ 
				return false; 
			}
				
			var remoteStates = this._remoteStates; 
			if(remoteStates)
			{
				StateHelper.removeActions(remoteStates);  
				remoteStates = [];
			}
			state.remove();
		}, 

		/* this will setup an event manager to add and remove events 
		to elements outside of the component when created. */ 
		setupEventHelper: function()
		{ 
			if(!this.events)
			{ 
				this.events = new EventHelper();
			}
		}, 

		/* this should be overriden to pass an array with 
		all of the component events. 
		@return (array) */
		setupEvents: function()
		{ 
			return [
				//['action', element, function(e){}, false]
			]; 
		}, 

		/* this will setup all the events returned by the 
		setupEvents method. */
		addEvents: function()
		{ 
			var events = this.setupEvents(); 
			if(events.length < 1)
			{ 
				return false; 
			}

			this.setupEventHelper();
			this.events.addEvents(events);
		}, 

		/* this will remove all of the component events. */ 
		removeEvents: function() 
		{ 
			var events = this.events; 
			if(events)
			{ 
				events.reset(); 
			}
		}, 

		/* this will remove all the component events, states, 
		and elements. */ 
		remove: function()
		{ 
			this.rendered = false; 
			this.beforeDestroy(); 
			this.removeEvents(); 
			this.removeStates(); 

			var panel = this.panel || this.id; 
			base.builder.removeElement(panel);
		}, 

		/* this will be called before the component is destroyed. */ 
		beforeDestroy: function()
		{

		}, 

		/* this is a method that should be overridden to 
		destroy the component */ 
		destroy: function() 
		{ 
			this.remove();  
		},

		/* this will bind an element to a property 
		of a data. 
		@param (object) element 
		@param (object) data 
		@param (string) prop */ 
		bindElement: function(element, data, prop, filter) 
		{ 
			if(element) 
			{ 
				base.DataBinder.bind(element, data, prop, filter);
			}
		}
	}); 

	var componentTypeNumber = 0; 

	/* this will allow the components to be extened. 
	@param (object) child = the child object to extend 
	@return (mixed) the new child prototype or false */ 
	Component.extend = function(child)
	{  
		if(!child)
		{ 
			return false; 
		} 

		var parent = this.prototype; 

		/* the child constructor must be set to set 
		the parent static methods on the child */ 
		var constructor = child && child.constructor? child.constructor : false; 
		if(child.hasOwnProperty('constructor') === false)
		{ 
			constructor = function()
			{
				var args = base.listToArray(arguments); 
				parent.constructor.apply(this, args); 
			}; 
		} 

		/* this will add the parent class to the 
		child class */ 
		constructor.prototype = base.extendClass(parent, child); 
		constructor.prototype.parent = parent; 

		/* this will assign a unique id to the type of 
		component */ 
		constructor.prototype.componentTypeId = 'bs-cp-' + (componentTypeNumber++) + '-'; 

		/* this will add the static methods from the parent to 
		the child constructor. could use assign but ie doesn't 
		support it */ 
		//Object.assign(constructor, this);
		base.extendObject(this, constructor); 
		return constructor; 
	}; 

	/* this will add a reference to the component 
	object */ 
	base.extend.Component = Component; 
 
})();

/* base framework module */
/*
	this will create a layout builder object
	and shortcut functions.
*/
(function()
{
	"use strict"; 

	/* 
		StateTarget 

		this will create a state target that can store 
		all actions that should be watched. 

		@param (string) id = the target id (should be unique)
	*/  

	var StateTarget = base.SimpleData.extend(
	{ 
		constructor: function(id)
		{ 
			this._init();

			/* this will setup the event sub for 
			one way binding */ 
			this.eventSub = new base.DataPubSub();

			this.stage = {};
			this.id = id;  
		}, 
		
		/* this will the target and all the actions 
		from the controller. */ 
		remove: function()
		{ 
			var controller = base.state; 
			if(controller)
			{ 
				return controller.remove(this.id); 
			}
		}, 

		/* this will add a new action to watch. 
		@param (string) action 
		@param [(string)] state = the action primary state */ 
		addAction: function(action, state)
		{ 
			if(typeof state !== 'undefined')
			{
				this.set(action, state);
			}
		}, 

		/* this will get the state of an action 
		@param (string) action */ 
		getState: function(action)
		{ 
			return this.get(action); 
		}, 

		/* this will remove an action or a callBack 
		from an action. if no callBack is set the whole 
		action is removed. 
		@param (string) action 
		@param [string] token */
		removeAction: function(action, token)
		{ 
			/* if we have a token then the token will be 
			the only item removed */ 
			if(token)
			{ 
				this.off(action, token); 
			} 
			else 
			{
				var actions = this.stage; 
				if(typeof actions[action] !== 'undefined')
				{ 
					delete actions[action];
				}
			} 
		}
	}); 

	/* 
		StateController 

		this will create a new state controller that can 
		add and remove state targets, actions, and action 
		subsriber callBack functions.
	*/
	var StateController = base.Class.extend(
	{ 
		constructor: function()
		{ 
			this.targets = {}; 
		}, 

		/* this will get the subscriber array for the 
		message or create a new subscriber array if none 
		is setup already. 
		@param (string) id 
		@return (array) subscriber array */ 
		getTarget: function(id) 
		{ 
			var targets = this.targets;
			return (targets[id] || (targets[id] = new StateTarget(id)));
		}, 

		/* this will get the state of a target action. 
		@param (string) targetId = the target id (should be unique)
		@param [(string)] action = the first target action to watch 
		@param (object) the state target */ 
		getActionState: function(targetId, action)
		{ 
			var target = this.getTarget(targetId); 
			return target.get(action);
		},

		/* this will add a new target to the state controller. 
		@param (string) targetId = the target id (should be unique)
		@param [(string)] action = the first target action to watch 
		@param [(string)] state = the primary action state 
		@param (object) the state target */ 
		add: function(targetId, action, state)
		{ 
			var target = this.getTarget(targetId); 
			if(action)
			{ 
				target.addAction(action, state);
			}
			return target; 
		}, 

		/* this will add a new action to a target.  
		@param (string) targetId = the target id
		@param (string) action 
		@param [(string)] state = the primary action state 
		@param (object) the state action */
		addAction: function(targetId, action, state)
		{ 
			return this.add(targetId, action, state);  
		}, 

		/* this will remove an action from a state 
		@param (string) targetId = the target id
		@param (string) action 
		@param [string] token 
		@param (object) the state action */
		removeAction: function(targetId, action, token)
		{ 
			this.off(targetId, action, token);  
		},

		/* this will add a new subscriber to an action.  
		@param (string) targetId = the target id
		@param (string) action 
		@param (string) callBack 
		@param (object) the state action */
		on: function(targetId, action, callBack)
		{ 
			var target = this.getTarget(targetId); 
			if(action)

			{ 
				return target.on(action, callBack);
			}
			return false; 
		}, 

		/* this will remove a subscriber from an action.  
		@param (string) targetId = the target id
		@param (string) action 
		@param (string) token 
		@param (object) the state action */
		off: function(targetId, action, token)
		{ 
			this.remove(targetId, action, token); 
		},  

		/* this will remove a target or action or callback. 
		@param (string) targetId = the target id
		@param [(string)] action 
		@param [(string)] token 
		@param (object) the state target */
		remove: function(targetId, action, token)
		{ 
			var targets = this.targets; 
			var target = targets[targetId]; 
			if(!target)
			{ 
				return false; 
			}
				
			if(action)
			{ 
				target.off(action, token); 
			}
			else 
			{ 
				delete targets[targetId];
			}
		}, 

		set: function(targetId, action, state)
		{
			var target = this.getTarget(targetId); 
			target.set(action, state); 
		}
	}); 

	base.extend.StateController = StateController; 
	base.extend.state = new StateController();
})();

/* base framework module */
(function()
{
	"use strict"; 
	
	/* this will register the route system to the 
	data tracker to remove routes that have been 
	nested in layouts. */ 
	base.DataTracker.addType('routes', function(data)
	{
		if(!data)
		{
			return false; 
		}
		
		var route = data.route; 
		if(route)
		{
			base.router.removeRoute(route);  
		}
	});
	
	var Utils = 
	{ 
		/* this will remove the begining and ending slashes on a url. 
		@param (string) uri = the uri to remove 
		@return (string) the uri */ 
		removeSlashes: function(uri) 
		{ 
			if(typeof uri === 'string') 
			{ 
				var pattern = /(^\/|\/$)/g; 
				uri = uri.toString().replace(pattern, '');  
			} 

			return uri; 
		}
	};
	
	/* 
		router 
		
		this will add client side routing to allow routes to be 
		setup and the router to navigate and activate the routes 
		that match the uri. 
		
		@param (string) baseURI = the root of the router uri 
		@param (string) title = the root title 
	*/ 
	var Router = base.Class.extend(
	{ 
		constructor: function(baseURI, title) 
		{ 
			this.version = '1.0.2'; 

			/* this is the root of the uri for the routing object 
			and the base title */ 
			this.baseURI = baseURI || '/'; 
			this.title = (typeof title !== 'undefined')? title : ''; 

			/* this will be used to accessour history object */ 
			this.history = null;
			this.callBackLink = null;
			
			/* this will store each route added to the 
			router. */ 
			this.routes = [];
			/* this will setup the router and check 
			to add the history support */ 
			this.setup();  
			
			base.router = this; 
		},  
		
		/* this will setup our route history */ 
		setupHistory: function() 
		{ 
			this.history = new History(this);  
			this.history.setup();
		}, 
		
		/* this will add a route to the router. 
		
		@param (object) settings 
		
		or 
		
		@param (string) uri = the route uri 
		@param (function) component 
		@param [(function)] callBack = the call back function 
		@param [(string)] title = the route title 
		@param [(string)] id = the route id
		@param [(string)] container = the container
		@return (object) reference to the object */ 
		add: function(settings) 
		{  
			if(typeof settings !== 'object') 
			{ 
				var args = arguments;
				settings = 
				{
					uri: args[0], 
					component: args[1], 
					callBack: args[2], 
					title: args[3], 
					id: args[4],
					container: args[5]
				};
			} 
			
			/* we need to format the uri */
			settings.uri = this.createURI(settings.uri);  
			
			var route = new Route(settings);  
			this.routes.push(route);
			return route; 
		}, 
		
		getBasePath: function()
		{
			if(!this.basePath)
			{
				var pathURI = this.baseURI || '';  
				if((pathURI[pathURI.length - 1] !== '/'))
				{
					pathURI += '/'; 
				}
				this.basePath = pathURI; 
			}
			return this.basePath; 
		}, 
		
		/* this will create a uri with the base path and 
		the route uri. 
		@param (string) uri = the uri 
		@return (string) the uri */
		createURI: function(uri) 
		{ 
			var baseUri = this.getBasePath(); 
			return (baseUri + Utils.removeSlashes(uri));  
		}, 
		
		/* this will get a route by the route settings. 
		@param (string) uri = the route uri  
		@return (mixed) the routeobject or false on error */
		getRoute: function(uri) 
		{ 
			var routes = this.routes, 
			length = routes.length; 
			if(length > 0) 
			{
				for(var i = 0; i < length; i++) 
				{ 
					var route = routes[i]; 
					if(route.uri === uri) 
					{ 
						return route; 
					} 
				} 
			} 
			return false; 
		}, 
		
		/* this will get a route by the route settings. 
		@param string id  
		@return object|bool the route object or false on error */
		getRouteById: function(id) 
		{ 
			var routes = this.routes, 
			length = routes.length; 
			if(length > 0) 
			{
				for(var i = 0; i < length; i++) 
				{ 
					var route = routes[i]; 
					if(route.id === id) 
					{ 
						return route; 
					} 
				} 
			} 
			return false; 
		}, 
		
		removeRoute: function(route)
		{
			var routes = this.routes;
			var index = base.inArray(routes, route); 
			if(index > -1) 
			{ 
				routes.splice(index, 1); 
			}
		}, 
		
		/* this will remove a route from the router by the route settings. 
		@param (string) uri = the route uri 
		@param (string) template = the template name 
		@param [(function)] callBack = the call back function  
		@return (object) reference to the object */
		remove: function(uri) 
		{ 
			uri = this.createURI(uri); 
			
			var route = this.getRoute(uri); 
			if(route !== false) 
			{ 
				this.removeRoute(route);  
			} 
			return this;  
		}, 
		
		/* this will setup the history object  
		@return (object) reference to the object */
		setup: function() 
		{ 
			this.setupHistory(); 
			
			this.callBackLink = base.bind(this, this.checkLink);
			base.on('click', document, this.callBackLink);
			
			/* this will route to the first url entered 
			when the router loads. this will fix the issue 
			that stopped the first endpoint from being 
			added to the history */ 
			var endPoint = this.getEndPoint(); 
			this.navigate(endPoint, null, true);
			return this;  
		}, 
		
		checkLink: function(evt)
		{ 
			var target = evt.target || evt.srcElement; 
			var nodeName = target.nodeName.toLowerCase(); 
			if(nodeName !== 'a')
			{ 
				/* this will check to get the parent to check 
				if the child is contained in a link */ 
				target = target.parentNode; 
				if(target === null)
				{ 
					return true; 
				}

				nodeName = target.nodeName.toLowerCase(); 
				if(nodeName !== 'a')
				{ 
					return true; 
				}
			}

			if(target.target === '_blank' || base.data(target, 'cancel-route'))
			{ 
				return true; 
			}
				
			var href = target.getAttribute('href'); 
			if(typeof href !== 'undefined')
			{ 
				var path = href.replace(this.baseURI, ''); 
				this.navigate(path);

				evt.preventDefault(); 
				evt.stopPropagation();
				return false;
			}
		}, 
		
		/* this will reset the router  
		@return (object) reference to the object */
		reset: function() 
		{ 
			this.routes = []; 
			return this;  
		}, 
		
		/* this will activate any active routes   
		@return (object) reference to the object */
		activate: function() 
		{ 
			this.checkActiveRoutes(); 
			return this;  
		}, 
		
		/* this will navigate the router to the uri. 
		@param (string) uri = the relative uri 
		@param [(object)] data = a data object that will 
		be added to the history state object 
		@param [(bool)] replace = settrue to replace state
		@return (object) a reference to the router object */ 
		navigate: function(uri, data, replace) 
		{ 
			uri = this.createURI(uri); 
			this.history.addState(uri, data, replace); 
			this.activate(); 
			return this; 
		},  
		
		/* this will update the window title with the route title. 
		@param (object) route = a route that has a title 
		@return (object) a reference to the router object */ 
		updateTitle: function(route) 
		{ 
			if(!route || !route.title) 
			{ 
				return this;  
			} 
			
			var title = route.title, 
			parent = this; 

			var getTitle = function(title) 
			{ 
				/* this will uppercase each word in a string
				@param (string) str = the string to uppercase 
				@return (string) the uppercase string */ 
				var toTitleCase = function(str)
				{
					var pattern = /\w\S*/; 
					return str.replace(pattern, function(txt)
					{
						return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
					});
				}; 


				/* this will replace the params in the title 
				@param (string) str = the route title 
				@return (string) the title string */ 
				var replaceParams = function(str)
				{
					if(str.indexOf(':') > -1) 
					{ 
						var params = route.stage; 
						for(var prop in params) 
						{ 
							if(params.hasOwnProperty(prop)) 
							{
								var param = params[prop];
								var pattern = new RegExp(':' + prop, 'gi');  
								str = str.replace(pattern, param); 
							}
						} 
					} 
					return str; 
				}; 

				if(title) 
				{  
					/* we want to replace any params in the title 
					and uppercase the title */ 
					title = replaceParams(title);
					var pattern = /-/g; 
					title = toTitleCase(title.replace(pattern, ' ')); 

					/* we want to check to add the base title to the 
					to the end of the title */ 
					if(parent.title !== '') 
					{ 
						title += " - " + parent.title; 
					}
				} 
				return title; 
			}; 

			document.title = getTitle(title);
		}, 
		
		/* this will get all active routes from a path. 
		@param [(string)] path = the path or the current 
		url path will be used 
		@return (array) an array of active routes */ 
		checkActiveRoutes: function(path) 
		{ 
			path = path || this.getPath();
			
			var active = [], 
			routes = this.routes, 
			length = routes.length; 
			if(length < 1) 
			{ 
				return active; 
			}
				 
			var route, 
			check; 

			for(var i = 0; i < length; i++) 
			{ 
				route = routes[i]; 
				if(typeof route === 'undefined')
				{ 
					continue; 
				}
					
				check = this.check(route, path); 
				if(check !== false) 
				{ 
					active[active.length] = route; 
				} 
				else 
				{ 
					route.deactivate(); 
				}
			} 
			return active; 
		}, 
		
		/* this will check to select a route if it the route uri 
		matches the path. 
		@param (object) route = the route 
		@param [(string)] path = the path. if left null the 
		active path will beused 
		@return (bool) true or false if active */ 	
		check: function(route, path) 
		{ 
			/* we want to check if the route has been 
			deleted from the routes */ 
			if(!route) 
			{ 
				return false; 
			} 
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			path = path || this.getPath(); 
			
			/* we want to check if the route uri matches the path uri */ 
			var match = route.match(path); 
			if(match === false) 
			{ 
				return false;   
			}  
			
			this.select(route);
			return true;
		}, 
		
		/* this will get the param names from the route uri. 
		@param (object) route = the route object */
		select: function(route) 
		{ 
			if(!route) 
			{ 
				return false; 
			}
				  
			route.select(); 
			this.updateTitle(route); 
		},  
		
		/* this will return the set endpoint not including the
		base uri. 
		@return (string) the last endpoint */
		getEndPoint: function() 
		{  
			var path = this.getPath(); 
			return (path.replace(this.baseURI, '') || '/');  
		}, 

		destroy: function()
		{
			base.off('click', document, this.callBackLink);
		}, 
		
		/* this will get the location pathname. 
		@return (string) the location pathname */ 
		getPath: function()
		{ 
			/* we want to get the window location path */  
			var location = window.location; 
			return location.pathname + location.search + location.hash;  
		}
	}); 
	
	var routerNumber = 0;
	
	/* 
		History 
		
		this will setup the history controller for 
		a router. 
		
		@param (object) router 
	*/ 
	var History = base.Class.extend( 
	{ 
		constructor: function(router)
		{ 
			this.router = router; 


			/* this will check if the history api is supported 
			and enabled */
			this.enabled = false;
			this.locationId = 'base-app-router-' + routerNumber++; 
			this.callBack = null;
		},  
				
		/* this will check to add history support is 
		the browser supports it */ 
		setup: function() 
		{ 
			/* we want to check if history is enabled */ 
			this.enabled = this.isSupported(); 

			/* we want to check to add the history event listener 
			that will check the popsate events and select the  
			nav option by the history state object */ 
			if(this.enabled !== true) 
			{ 
				return this; 
			}
				  
			this.callBack = base.bind(this, this.check); 
			this.addEvent(); 
			return this; 
		},
		
		/* this will check if history api is supported and if so 
		return true else return false */ 
		isSupported: function() 
		{ 
			if('history' in window && 'pushState' in window.history) 
			{ 
				return true; 
			} 
			else 
			{ 
				return false; 
			} 
		}, 

		/* this will add an event history listener that will 
		trigger when the window history is changed */ 
		addEvent: function() 
		{   
			base.on('popstate', window, this.callBack);
			return this; 
		}, 

		removeEvent: function() 
		{ 
			base.off('popstate', window, this.callBack); 
			return this; 
		}, 

		check: function(evt) 
		{ 
			/* we want to check if the event has a state and if the 
			state location is from the background */ 
			var state = evt.state; 
			if(!state || state.location !== this.locationId) 
			{ 
				return false; 
			}
				  
			evt.preventDefault(); 
			evt.stopPropagation(); 

			this.router.checkActiveRoutes(state.uri);   
		}, 

		createState: function(uri, data) 
		{ 
			var stateObj = { 
				location: this.locationId, 
				uri: uri  
			};  

			if(data && typeof data === 'object') 
			{ 
				stateObj = base.extendObject(stateObj, data); 
			} 

			return stateObj; 
		}, 

		addState: function(uri, data, replace) 
		{ 
			if(this.enabled !== true) 
			{
				return this; 
			}
				
			var history = window.history, 
			lastState = history.state;   
			
			if(lastState && lastState.uri === uri)
			{
				return this; 
			}

			var stateObj = this.createState(uri, data);

			/* this will check to push state or 
			replace state */ 
			replace = (replace === true); 
			var method = (replace === false)? 'pushState' : 'replaceState'; 
			history[method](stateObj, null, uri); 

			return this; 
		}
	}); 
	
	var routePattern = function(uri)
	{ 
		var uriQuery = ""; 
		if(uri) 
		{ 
			/* we want to setup the wild card and param 
			checks to be modified to the route uri string */ 
			var allowAll = /(\*)/g, 
			param = /(:[^\/|?]*)/g, 
			optionalParams = /(\?\/+\*?)/g, 
			optionalSlash = /(\/):[^\/]*?\?/g, 
			filter = /\//g; 
			uriQuery = uri.replace(filter, "\/").replace(allowAll, '.*'); 

			/* this will setup for optional slashes before the optional params */ 
			uriQuery = uriQuery.replace(optionalSlash, function(str)
			{  
				var pattern = /\//g; 
				return str.replace(pattern, '\/*');  
			}); 

			/* this will setup for optional params and params 
			and stop at the last slash or query start */ 
			uriQuery = uriQuery.replace(optionalParams, '?\/*').replace(param, '([^\/|?]+)'); 
		} 

		/* we want to set and string end if the wild card is not set */ 
		uriQuery += (uri[uri.length - 1] === '*')? '' : '$'; 
		return uriQuery;
	}; 
	
	var paramPattern = function(uri)
	{ 
		var params = []; 
		if(!uri) 
		{ 
			return params; 
		}
			 
		var pattern = /:(.[^\/]*)/g, 
		matches = uri.match(pattern); 
		if(matches === null) 
		{ 
			return params; 
		}
			 
		for(var i = 0, maxLength = matches.length; i < maxLength; i++) 
		{ 
			var param = matches[i]; 
			if(param) 
			{ 
				pattern = /(:|\?)/g; 
				var filter = /\*/g; 
				/* we need to remove the colon, question mark, or asterisk
				 from the key name */ 
				param = param.replace(pattern, '').replace(filter, ''); 
				params.push(param); 
			} 
		}
		return params;
	}; 
	
	var routeCount = 0; 
	
	/* 
		Route 
		
		@param (string) uri = the route uri 
		@param (string) template = the template name 
		@param [(function)] callBack = the call back function 
		@param [(string)] title = the route title 
		@param [(string)] id = the route id 
	*/
	var Route = base.SimpleData.extend( 
	{ 
		constructor: function(settings)
		{  
			this.setupRoute(settings);    
			
			var params = this.getParamDefaults(); 
			base.SimpleData.call(this, params); 
			
			this.set('active', false); 
		}, 
		
		setupRoute: function(settings)
		{
			this.id = settings.id || 'bs-rte-' + routeCount++;
			
			var uri = settings.uri; 
			this.uri = uri; 

			/* route reg ex */ 
			var uriMatch = routePattern(uri); 
			this.uriQuery = new RegExp('^' + uriMatch); 

			/* params */ 
			this.paramKeys = paramPattern(uri); 
			this.params = null;

			/* this will setup the template and route component 
			if one has been set */   
			this.setupComponentHelper(settings.component, settings.container); 

			this.callBack = settings.callBack;
			this.title = settings.title;
		}, 
		
		getParamDefaults: function()
		{
			var params = this.paramKeys; 
			if(params.length)
			{
				var defaults = {}; 
				for(var i = 0, length = params.length; i < length; i++)
				{
					defaults[params[i]] = null; 
				}
				return defaults; 
			}
			return null; 
		}, 
		
		deactivate: function()
		{ 
			this.set('active', false);
			
			var controller = this.controller; 
			if(controller)
			{ 
				controller.remove(); 
			}
		},
		
		setupComponentHelper: function(component, container)
		{ 
			if(typeof component !== 'undefined')
			{
				this.controller = new ComponentHelper(this, component, container); 
			}
		}, 
		
		select: function()
		{ 
			this.set('active', true);
			
			var params = this.stage; 
			var callBack = this.callBack; 
			if(typeof callBack === 'function') 
			{ 
				callBack(params); 
			} 

			var controller = this.controller; 
			if(controller)
			{ 
				controller.focus(params); 
			}
		}, 
		
		match: function(path)
		{
			var matched = false;
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			var result = path.match(this.uriQuery); 
			if(result === null)
			{
				return matched; 
			}
			
			if(result && typeof result === 'object') 
			{   
				/* this will remove the first match from the 
				the params */
				result.shift(); 
				matched = result; 
				/* this will get the uri params of the route 
				and if set will save them to the route */    
				this.setParams(result);
			}

			return matched;
		}, 
		
		/* this will get the param names from the route uri. 
		@param (array) values = the path param values 
		@return (mixed) an empty object or an object with key 
		and values of the params */
		setParams: function(values)
		{ 
			if(values && typeof values === 'object') 
			{ 
				var keys = this.paramKeys;  
				if(keys) 
				{ 
					var params = {}; 
					for(var i = 0, maxL = keys.length; i < maxL; i++) 
					{ 
						var key = keys[i]; 
						if(typeof key !== 'undefined') 
						{ 
							params[key] = values[i]; 
						} 
					} 
					this.set(params);
				} 
			}
		},
		
		/* this will get the param names from the route uri. 
		@param (array) values = the path param values 
		@return (mixed) an empty object or an object with key 
		and values of the params */
		getParams: function()
		{ 
			return this.stage; 
		}
	}); 
	
	var ComponentHelper = base.Class.extend( 
	{ 
		constructor: function(route, template, container)
		{ 
			this.route = route; 
			
			this.template = template;
			this.component = null; 
			this.hasTemplate = false; 
			
			this.setup = false; 
			this.container = container; 
			
			this.setupTemplate(); 
		}, 
		
		focus: function(params)
		{ 
			/* this will check to setup the component if 
			the component has notbeen setup */ 
			if(this.setup === false && this.component === null)
			{ 
				this.create();
			}

			this.update(params);
		}, 
		
		setupTemplate: function()
		{
			var template = this.template; 
			if(typeof template === 'string')
			{
				template = this.template = window[template]; 
			} 
			
			if(typeof template === 'function')
			{
				this.hasTemplate = true; 
			}
		}, 
		
		/* this will create and setup a component 
		from a route template. 
		@param (object) route */ 
		create: function()
		{ 
			if(!this.hasTemplate)
			{ 
				return false; 
			}
			
			this.setup = true;
			
			var comp = this.component = new this.template({
				route: this.route
			});
 
			comp.setup(this.container); 
		}, 
		
		/* this will remove a route component */
		remove: function()
		{ 
			if(this.setup !== true)
			{ 
				return false; 
			}
				
			this.setup = false;
			
			var component = this.component;
			if(!component)
			{ 
				return false; 
			}
				
			if(typeof component.destroy === 'function')
			{ 
				component.destroy();
			}
			this.component = null; 
		}, 
		
		update: function(params)
		{ 
			var component = this.component;
			if(!component)
			{ 
				return false; 
			}
			
			if(typeof component.update === 'function')
			{ 
				component.update(params);
			}
		}
	}); 
	
	base.extend.Router = Router; 
})();