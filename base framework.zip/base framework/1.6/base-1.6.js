/* 

	base framework 
	
	This is a mini javascript framework to allow complex  
	functions to work in many browsers and versions. 
	
	The framework can also be extended to add additional 
	functionality. 
	
*/ 

(function(global) 
{ 
	"use strict"; 
	
	/* 
		base framework constructor
		
		This will set all settings of the base framework and 
		allow all modules to be extended from the base 
		prototype. 
	*/ 
	var base = function() 
	{ 
		this.version = '1.6.0';   
	};  
	 
	/* we want to add the intial methods to the 
	base framework as prototypes so they can be inherited */ 
	base.prototype = (function()
	{  
		/* we want to reset the constructor to ensure that 
		we still have our base constructor */ 
		this.constructor = base;  
		
		/* we want to create an instance of the object 
		to use in the methods */ 
		var self = this;
		
		/* this will store all the errors */ 
		this.errors = [];  
		
		/* this will get the last error */ 
		this.getLastError = function() 
		{ 
			return self.errors.pop(); 
		};  
		
		/* this will add an error object to the base 
		error array */ 
		this.addError = function(err) 
		{ 
			self.errors.push(err); 
		};  
	
		/* this will return an object with the params 
		from the url or false if none found. 
		@return (mixed) an object with the key and value pairs 
		of the param string or false if no params are set */ 
		this.parseQueryString = function() 
		{ 
			var str = window.location.search, 
			objURL = {}, 
			regExp = /([^?=&]+)(=([^&]*))?/g; 
		
			str.replace(regExp, function($0, $1, $2, $3)
				{ 
					/* we want to save the key and the 
					value to the objURL */ 
					objURL[ $1 ] = $3;
				}
			); 
			
			/* we want to check if the url has any params */ 
			return (self.isEmpty(objURL) == false)? objURL : false;  
		};  
		
		/* this is an alias for parse query string and will
		return an object with the params from the url. 
		@return (mixed) an object with the key and value pairs 
		of the param string or false if no params are set */ 
		this.getParams = function() 
		{ 
			/* can check for args */ 
			return self.parseQueryString();   
		};   
		
		/* this will check if an object is empty. 
		@param (object) obj = the object to check 
		@return (bool) true or false if empty */ 
		this.isEmpty = function(obj) 
		{ 
			/* we want to loop through each property and 
			check if it belongs to the object directly */ 
			for(var key in obj) 
			{
				if(obj.hasOwnProperty(key)) 
				{ 
					return false;
				}
				return true; 
			}
		};  
		
		/* this will select an html element by id. 
		@param (string) id = the id of the element 
		@return (mixed) the element or false on error */ 
		this.getById = function(id) 
		{ 
			if(typeof id !== 'undefined') 
			{ 
				var obj = document.getElementById(id);  
				return (obj)? obj : false; 
			} 
			return false; 
		};  
		
		/* this will select html elements by name and return 
		a list. 
		@param (string) name = the name of the elements 
		@return (mixed) the element or false on error */ 
		this.getByName = function(name) 
		{ 
			if(typeof name !== 'undefined') 
			{ 
				var obj = document.getElementsByName(name);  
				return (obj)? obj : false;
			} 
			return false; 
		};  
		
		/* this will select html elements by css selector. 
		@param (string) name = the name of the elements
		@param [(int)] single = setup to only select the 
		first element 
		@return (mixed) the element or false on error */ 
		this.getBySelector = function(selector, single) 
		{ 
			if(typeof selector !== 'undefined') 
			{ 
				/* we want to check if we are only selecting 
				the first element or all elements */ 
				single = single || false; 
				if(single == true) 
				{ 
					var obj = document.querySelector(selector); 
					return (obj)? obj : false;
				} 
				else 
				{ 
					var elements = document.querySelectorAll(selector);  
					if(elements) 
					{ 
						/* if there is only one result just return the 
						first element in the node list */ 
						return (elements.length == 1)? elements[0] : elements;  
					} 
				} 
			} 
			return false; 
		}; 
		
		/* this will either set the innerHTML of an object or 
		return the innerHTML of an element.
		@param object obj = the object to use  
		@param [(string)] html = the html to insert
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		html is being accessed the html will be returned */
		this.html = function(obj, html) 
		{ 
			if(typeof obj === 'object') 
			{ 
				/* we want to check if we are getting the 
				html or adding the html */ 
				if(typeof html !== 'undefined') 
				{ 
					try{ 
						/* we want to check to set the value */ 
						obj.innerHTML = html; 
					} 
					catch(e) 
					{ 
						self.addError(e); 
					} 
					
					return this; 
				} 
				else 
				{ 
					return obj.innerHTML; 
				} 
			}  
		};
		
		/* this will either set the css style value 
		to an object or return the value of the style property.
		@param object obj = the object to use 
		@param (string) property = the css property name 
		@param [0ptional](string) value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		this.css = function(obj, property, value) 
		{ 
			if(typeof obj === 'object' && typeof property !== 'undefined') 
			{ 
				/* we want to check if we are getting the 
				value or setting the value */ 
				if(typeof value !== 'undefined') 
				{ 
					property = self.uncamelCase(property); 
					obj.style[property] = value;  
					
					return this; 
				} 
				else 
				{ 
					property = self.uncamelCase(property);
					var css = obj.style[property]; 
					if(css === '') 
					{ 
						/* we want to check if we have an inherited 
						value */ 
						css = obj.currentStyle ? obj.currentStyle[property] : window.getComputedStyle(obj, null)[property]; 
					} 
					return css; 
				} 
			}  
		}; 
		
		/* this will remove the attribute of an object
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@return (object) a reference to the base object 
		to allow chaining */
		this.removeAttr = function(obj, property) 
		{ 
			if(typeof obj === 'object') 
			{ 	
				try{ 
					/* we want to check to set the value */ 
					removeAttr(obj, property); 
				} 
				catch(e) 
				{ 
					self.addError(e); 
				}
			} 
			
			return this; 
		}; 
		
		/* this will either set the attribute and value 
		to an object or return the value of an attribute.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [0ptional](string) value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		this.attr = function(obj, property, value) 
		{ 
			if(typeof obj === 'object') 
			{ 
				/* we want to check if we are getting the 
				value or setting the value */ 
				if(typeof value !== 'undefined') 
				{ 
					try{ 
						/* we want to check to set the value */ 
						addAttr(obj, property, value); 
					} 
					catch(e) 
					{ 
						self.addError(e); 
					} 
					
					return this; 
				} 
				else 
				{ 
					return getAttr(property); 
				} 
			}  
		}; 
		
		/* we only want to do one check if the system supports 
		modern attriubute checks and save them to a private 
		functions */ 
		var addAttr, 
		removeAttr, 
		getAttr; 
		
		if(typeof document.documentElement.setAttribute === 'function') 
		{ 
			// modern browsers 
			addAttr = function(obj, property, value) 
			{ 
				obj.setAttribute(property, value); 
			}; 
			
			removeAttr = function(obj, property) 
			{ 
				obj.removeAttribute(property); 
			}; 
			
			getAttr = function(obj, property) 
			{ 
				return obj.getAttribute(property); 
			};
		} 
		else 
		{ 
			// old browsers 
			addAttr = function(obj, property, value) 
			{ 
				obj[property] = value;   
			}; 
			
			removeAttr = function(obj, property) 
			{ 
				/* we cannot remove the attr through the remove 
				attr method so we want to null the value. 
				we want to camel caps the propety */ 
				property = self.camelCase(property); 
				obj.property = null; 
			}; 
			
			getAttr = function(obj, property) 
			{ 
				return obj[property]; 
			};
		}
		
		/* this will either set the data attribute and value 
		to an object or return the data value.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [0ptional](string) value = the value to 
		add to the attribute 
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned
		*/
		this.data = function(obj, property, value) 
		{ 
			if(typeof obj === 'object') 
			{ 
				if(typeof value !== 'undefined') 
				{ 
					addData(obj, property, value);  
					
					return this; 
				} 
				else 
				{ 
					/* we need to check the prop prefix */ 
					property = checkDataPrefix(property);
					return self.attr(obj, property); 
				} 
			}  
		}; 
		
		/* we only want to do one check if the system supports 
		modern attriubute checks and save them to a private 
		functions */ 
		var addData; 
		
		/* this will check if the property is not 
		prefixed with data for loder browsers */ 
		var checkDataPrefix = function(prop) 
		{ 
			if(typeof prop !== 'undefined') 
			{ 
				/* we want to de camelcase if set */ 
				prop = self.uncamelCase(prop); 
				if(prop.substring(0, 5) != 'data-') 
				{ 
					prop = 'data-' + prop;   
				}  
			} 
			return prop; 
		};
		
		if(typeof document.documentElement.dataset !== 'undefined') 
		{ 
			// modern browsers 
			addData = function(obj, property, value) 
			{ 
				/* this will return the property without the data prefix */ 
				var removePrefix = function(prop) 
				{ 
					if(typeof prop !== 'undefined') 
					{ 
						if(prop.substring(0, 5) == 'data-') 
						{ 
							prop = prop.substring(5);   
						}  
					} 
					return prop; 
				}; 
				
				property = removePrefix(property); 
				property = self.camelCase(property); 

				obj.dataset[property] = value; 
			}; 
		} 
		else 
		{ 
			// old browsers 
			addData = function(obj, property, value) 
			{ 
				/* we need to check the prop prefix */ 
				property = checkDataPrefix(property); 
				self.attr(obj, property, value);   
			}; 
		} 
		
		/* this will find child elements in an element.
		@param object obj = the object to use 
		@param string queryString = the query string 
		@return (mixed) a nodeList or false on error */
		this.find = function(obj, queryString) 
		{ 
			var result = false; 
			
			if(obj && typeof obj === 'object' && typeof queryString === 'string') 
			{ 
				try{ 
					result = obj.querySelectorAll(queryString); 
				} 
				catch(e) 
				{ 
					self.addError(e);
				} 
			} 
			return result; 
		}; 
		
		/* this will display an element.
		@param object obj = the object to use 
		@return (object) a referenceto the base object 
		to allow method chaining */
		this.show = function(obj) 
		{ 
			if(typeof obj === 'object') 
			{ 
				/* we want to get the previous display style 
				from the data-style-display attr */
				var previous = self.data(obj, 'style-display'), 
				value = (typeof previous === 'string')? previous : ''; 
				
				self.css(obj, 'display', '');  
			}
			
			return this; 
		}; 
		
		/* this will hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object  
		to allow chaining */
		this.hide = function(obj) 
		{ 
			if(typeof obj === 'object') 
			{ 
				/* we want to set the previous display style 
				on the element as a data attr */ 
				var previous = self.css(obj, 'display'); 
				self.data(obj, 'style-display', previous); 
				
				self.css(obj, 'display', 'none'); 
			} 
			
			return this; 
		}; 
		
		/* this will display or hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object 
		to allow chaining */
		this.toggle = function(obj) 
		{ 
			if(typeof obj === 'object') 
			{ 
				var mode = self.css(obj, 'display'); 
				if(mode != 'none') 
				{ 
					this.hide(obj); 
				} 
				else 
				{ 
					this.show(obj); 
				} 
			} 
			
			return this; 
		}; 
		
		/* this will camelcase a string that is separated 
		with a space, hyphen, or underscore and retun. 
		@param (string) str = the string to camelcase 
		@return (mixed) a camel case string or false */ 
		this.camelCase = function(str) 
		{ 
			if(typeof str === 'string') 
			{ 
				var regExp = /(-|\s|\_)+\w{1}/g; 
				
				return str.replace(regExp, function(match) 
				{ 
					return match[1].toUpperCase(); 
				}); 
			} 
			return false; 
		}; 
		
		/* this will uncamelcase a string and separate with a delimter 
		and retun. 
		@param (string) str = the string to camelcase
		@param [(string)] delimiter = the string delimiter 
		@return (mixed) an uncamel cased string or false if 
		no string was sent */ 
		this.uncamelCase = function(str, delimiter) 
		{ 
			if(typeof str == 'string') 
			{ 
				delimiter = delimiter || '-'; 
				var regExp = /([A-Z]{1,})/g; 
				
				return str.replace(regExp, function(match) 
				{ 
					return delimiter + match.toLowerCase(); 
				}).toLowerCase(); 
			} 
			return false; 
		}; 
		
		/* this will return an object with the width and height 
		of an object.
		@param object obj = the object to get the 
		width and height 
		@return (mixed) an object with the width and size or 
		false on error */ 
		this.getSize = function(obj) 
		{ 
			var size = { 
				width: 0, 
				height: 0 
			}; 
			
			/* we want to check if the object is not supplied */ 
			if(typeof obj === 'object') 
			{ 
				size.width = self.getWidth(obj); 
				size.height = self.getHeight(obj); 
				
				return size; 
			} 
			else 
			{ 
				return false;  
			} 
		}; 
		
		/* this will return the width of an object.
		@param object obj = the object to get the 
		width 
		@return (mixed) the width int or false on error */ 
		this.getWidth = function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			if(obj && typeof obj === 'object') 
			{ 
				return obj.offsetWidth; 
			} 
			else 
			{ 
				return false;  
			} 
		}; 
		
		/* this will return the height of an object.
		@param object obj = the object to get the 
		height
		@return (mixed) the height int or false on error */ 
		this.getHeight = function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			if(obj && typeof obj === 'object') 
			{ 
				return obj.offsetHeight; 
			} 
			else 
			{ 
				return false;  
			} 
		}; 
		
		/* this will get the scroll position of an object and 
		return an object with top and left scroll position or 
		false on error. 
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) an object with the left and top position 
		 or false on error */ 
		this.getScrollPosition = function(obj) 
		{ 
			var position = { 
				left: 0, 
				top: 0 
			}; 
			
			/* we wantto check if the object is not supplied */ 
			if(typeof obj === 'undefined') 
			{ 
				/* we want to use the document body */ 
				var doc = document.documentElement;
				position.left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
				position.top = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0); 
				
				return position; 
			} 
			else 
			{ 
				/* we want to use the object */ 
				if(obj && typeof obj === 'object') 
				{ 
					position.left = (obj.scrollLeft) - (obj.clientLeft || 0);
					position.top = (obj.scrollTop)  - (obj.clientTop || 0); 
					
					return position;
				} 
				else 
				{ 
					return false; 
				} 
			} 
		}; 
		
		/* this will return the scroll top position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) the top position int or false on error */ 
		this.getScrollTop = function(obj) 
		{ 
			var position = self.getScrollPosition(obj); 
			return (position !== false)? position.top : false;  
		}; 
		
		/* this will return the left scroll position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		*/ 
		this.getScrollLeft = function(obj) 
		{ 
			var position = self.getScrollPosition(obj); 
			return (position !== false)? position.left : false; 
		}; 
		
		/* this will get the window size and return 
		an object with the height and width */ 
		this.getWindowSize = function() 
		{ 
			var size = { 
				width: 0, 
				height: 0 
			}; 
			
			var w = window,
			d = document,
			e = d.documentElement,
			g = d.getElementsByTagName('body')[0],
			x = w.innerWidth || e.clientWidth || g.clientWidth,
			y = w.innerHeight || e.clientHeight || g.clientHeight; 
			
			size.width = x; 
			size.height = y; 
			
			return size; 
		}; 
		
		/* this will return the window height */ 
		this.getWindowHeight = function() 
		{ 
			var size = self.getWindowSize();  
			return size.height;  
		}; 
		
		/* this will return the window width */ 
		this.getWindowWidth = function() 
		{ 
			var size = self.getWindowSize(); 
			return size.width;  
		}; 
		
		/* this will return the document size */ 
		this.getDocumentSize = function() 
		{ 
			var size = { 
				width: 0, 
				height: 0 
			}; 
			
			var body = document.body,
			html = document.documentElement;
		
			size.height = Math.max(body.scrollHeight, body.offsetHeight, 
			html.clientHeight, html.scrollHeight, html.offsetHeight); 
			
			size.width = Math.max(body.scrollWidth, body.offsetWidth, 
			html.clientWidth, html.scrollWidth, html.offsetWidth);
			
			return size; 
		}; 
		
		/* this will return the document height. 
		@return (object) an object with the height and width 
		of the document */ 
		this.getDocumentHeight = function() 
		{ 
			var size = self.getDocumentSize();  
			return size.height; 
		}; 
		
		/* this object will add, remove and track active active 
		event listeners */ 
		this.events = (function() 
		{ 
			var events = this;  
			
			/* this will store all active ebents */ 
			this.activeEvents = []; 
			
			/* this will  create an object to use through the event 
			tracker. 
			@param (string) event = the name of the event to listen 
			@param (object) obj = obj to add the listener 
			@param (function) fn = function to perform on event 
			@param [(bool)] capture = event capture or false for default
			@param [(bool)] swapped = tells if the even return was 
			swapped with a standardized function. 
			@param [(function)] originalFn = the original function  
			return function was swapped.  
			*/ 
			this.createEventObj = function(event, obj, fn, capture, swapped, originalFn) 
			{ 
				/* we want to check if the swapped param was set */ 
				swapped = (typeof swapped !== 'undefined')? swapped : false; 
				
				var activeEvent = { 
					event: event, 
					obj: obj, 
					fn: fn, 
					capture: capture, 
					swapped: swapped, 
					originalFn: originalFn 
				}; 
				return activeEvent; 
			};  
			
			/* this will and an event listener and add 
			to the event tracker. 
			@param (string) event = the name of the event to listen 
			@param (object) obj = obj to add the listener 
			@param (function) fn = function to perform on event 
			@param [(bool)] capture = event capture
			@param [(bool)] swapped = tells if the even return was 
			swapped with a standardized function. 
			@param [(function)] originalFn = the original function  
			return function was swapped.
			*/ 
			this.add = function(event, obj, fn, capture, swapped, data) 
			{ 
				capture = (typeof capture !== 'undefined')? capture : false; 
				var activeEvent = events.createEventObj(event, obj, fn, capture, swapped, data);  
				
				events.activeEvents.push(activeEvent);  
				
				if(obj && typeof obj === 'object') 
				{ 
					try{ 
						addEvent(obj, event, fn, capture);  
					} 
					catch(e) 
					{ 
						self.addError(e); 
					}  
				}
			};  
			
			/* we want to do only one check to get the event adding and removing 
			method and save it to private methods to optimize adding and removing 
			event listeners */ 
			var addEvent, 
			removeEvent; 
			
			if(typeof global.addEventListener === 'function') 
			{ 
				// modern browsers
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj.addEventListener(event, fn, capture);
				}; 
				
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj.removeEventListener(event, fn, capture);
				};
			} 
			else if(typeof document.addEventListener === 'function') 
			{ 
				// old ie 
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj.attachEvent("on" + event, fn);
				}; 
				
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj.detachEvent("on" + event, fn);
				};
			} 
			else 
			{ 
				addEvent = function(obj, event, fn, capture) 
				{ 
					obj["on" + event] = fn;
				}; 
				
				removeEvent = function(obj, event, fn, capture) 
				{ 
					obj["on" + event] = null; 
				};
			}
			
			/* this remove the eventand remove from the tracker. 
			@param (string) event = the name of the event to listen 
			@param (object) obj = obj to add the listener 
			@param (function) fn = function to perform on event 
			@param [(bool)] capture = event capture or false for 
			the default value 
			*/ 
			this.remove = function(event, obj, fn, capture) 
			{ 
				capture = (typeof capture !== 'undefined')? capture : false; 
				
				/* we want to select the event from the active events array */ 
				var searchEvent = events.getActiveEvent(event, obj, fn, capture);  
				if(searchEvent !== false) 
				{ 
					var listener = searchEvent; 
					if(typeof listener === 'object') 
					{ 
						/* we want to use the remove event method and just 
						pass the listener object */ 
						events.removeEvent(listener); 
					} 
				}
			}; 
			
			/* this will remove an event object and the listener 
			from the active events array.   
			@param (object) listener = the listener object from 
			the active events array */ 
			this.removeEvent = function(listener) 
			{ 
				if(typeof listener === 'object') 
				{ 
					var object = listener.obj; 
					try{ 
						removeEvent(object, listener.event, listener.fn, capture);  
					} 
					catch(e) 
					{ 
						self.addError(e); 
					} 
				} 
				
				/* we want to remove the event from the active events array */ 
				var index = self.inArray(events.activeEvents, searchEvent);
				if(index >= 0) 
				{ 
					events.activeEvents.splice(index, 1); 
				} 
			}; 
			
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param (string) event = the name of the event to listen 
			@param (object) obj = obj to add the listener 
			@param (function) fn = function to perform on event 
			@param [(bool)] capture = event capture or false for default 
			value 
			@return (mixed) the event object or false if not found */ 
			this.getActiveEvent = function(event, obj, fn, capture) 
			{ 
				/* we want to create an object to search by */ 
				var listener = events.createEventObj(event, obj, fn, capture); 
				var searchEvent = events.searchEvent(listener); 
				
				/* if the search returns anything but false we 
				found our active event */ 
				return (searchEvent !== false)? searchEvent : false;  
			};  
				
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param (object) eventObj = the listener object to search  
			*/
			this.searchEvent = function(eventObj) 
			{ 
				if(typeof eventObj == 'object') 
				{ 
					/* we want to get the event listener from 
					the active event array */ 
					var searchEvent = events.searchAllEvents(eventObj); 
					
					/* if the search returns anything but false we 
					found our active event */ 
					if(searchEvent !== false) 
					{ 
						return searchEvent; 
					} 
					else 
					{ 
						/* we want to check if the event was swapped for 
						a standardized return function */ 
						var searchSwappedEvent = events.searchAllEvents(eventObj, true); 
						
						/* if the search returns anything but false we 
						found our active event */ 
						if(searchSwappedEvent !== false) 
						{ 
							return searchSwappedEvent; 
						}
					}
				} 
				
				return false; 
			};  
			
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param (object) eventObj = the listener object to search  
			@param [(bool)] swappedSearch = will enable checking of swapped events 
			*/
			this.searchAllEvents = function(eventObj, swappedSearch) 
			{ 
				if(typeof eventObj == 'object') 
				{ 
					var activeEvents = events.activeEvents; 
				
					/* check if the swapped search was setup */ 
					swappedSearch = (typeof swappedSearch !== 'undefined')? swappedSearch : false;  
				
					/* we want to check if the search is a swapped search to 
					verfiy the event type is swappable */ 
					if(swappedSearch == true) 
					{ 
						var swappable = events.isSwappedEventType(eventObj.event); 
						
						/* if the event type is not swappable we need to return 
						without checking */ 
						if(swappable == false) 
						{ 
							return false; 
						} 
					}					
					
					/* we want to search the active events for a match*/ 
					for(var i = 0, maxLength = activeEvents.length; i < maxLength; i++) 
					{ 
						var listener = activeEvents[i]; 
						
						/* we want to check if we are search by swapped 
						events or normal events */ 
						if(swappedSearch == false) 
						{ 
							/* we want to check the listener event with the
							 event object */ 
							if(listener.event == eventObj.event && listener.obj == eventObj.obj && listener.fn == eventObj.fn) 
							{ 
								return listener; 
								break; 
							} 
						} 
						else 
						{ 
							if(listener.swapped == true) 
							{ 
								/* we wantto check the listener event using 
								its swapped settings with the event object */
								if(listener.event == eventObj.event && listener.obj == eventObj.obj && listener.originalFn == eventObj.fn) 
								{ 
									return listener; 
									break; 
								} 
							}
						}
					} 
				} 
				
				return false; 
			}; 
			
			/* this will remove all events added to an element through 
			the base framework.  
			@param (object) obj = the element object */
			this.removeElementEvents = function(obj) 
			{ 
				if(typeof obj === 'object') 
				{ 
					var activeEvents = events.activeEvents, 
					removeEvents = []; 
					for(var i = 0, maxLength = activeEvents.length; i < maxLength; i++) 
					{ 
						var listener = activeEvents[i]; 
						if(listener && listener.obj === obj) 
						{ 
							removeEvents.push(listener); 
						}
					} 
					
					for(var i = 0, maxLength = removeEvents.length; i < maxLength; i++) 
					{ 
						var listener = removeEvents[i]; 
						if(listener) 
						{ 
							this.removeEvent(listener); 
						} 
					} 
				} 
			}; 
			
			/* these event types can have standardized return 
			functions*/ 
			this.swappedEvents = [ 
				'keydown', 
				'keyup', 
				'keypress', 
				'DOMMouseScroll', 
				'mousewheel', 
				'mousemove', 
				'popstate' 
			];		
			
			/* this will check if an event type could be swapped. 
			@param (string) event = the type of event
			 */ 
			this.isSwappedEventType = function(event) 
			{ 
				/* these event types can have standarized return 
				functions*/ 
				var swappedEvents = events.swappedEvents;  
				
				/* we want to check if the event type is in the 
				swapped event array */ 
				var index = self.inArray(swappedEvents, event); 
			
				/* we have found an event that may have been swapped 
				by our standardizedreturn functions */ 
				if(index >= 0) 
				{
					return true;  
				} 
				
				return false; 
			}; 
			
			/* we need to return the instance of the object 
			to add this object as the prototype object */ 
			return this; 
			
			/* we want to bind an object to the IIFE 
			to allow strict mode */ 
		}).call({});  
		
		/* this will add an event listener. 
		@param (string) event = the name of the event to listen 
		@param (object) obj = obj to add the listener 
		@param (function) fn = function to perform on event 
		@param [(bool)] capture = event capture
		@return (object) a reference to the base object */
		this.addListener = function(event, obj, fn, capture) 
		{  
			/* we want to add this to the active events */ 
			self.events.add(event, obj, fn, capture);  
			
			return this; 
		}; 
		
		/* this will remove an event listener. 
		@param (string) event = the name of the event to listen 
		@param (object) obj = obj to add the listener 
		@param (function) fn = function to perform on event 
		@param [(bool)] capture = event capture
		@return (object) a reference to the base object */
		this.removeListener = function(event, obj, fn, capture) 
		{ 
			/* we want to remove this from the active events */ 
			self.events.remove(event, obj, fn, capture);  
			
			return this; 
		}; 
		
		this.onLoad = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			 
			self.events.add('load', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onClick = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('click', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onDoubleClick = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('dblclick', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onMouseOver = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('mouseover', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onMouseOut = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('mouseout', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onMouseDown = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('mousedown', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onMouseUp = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('mouseup', obj, fn, capture); 
			
			return this; 
		}; 
		
		this.onMouseMove = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			self.events.add('mousemove', obj, fn, capture); 
			
			return this; 
		}; 
		
		/* this will enable the mouse tracking to be enabled 
		and disabled and the position can be set to page, 
		client, or screen */ 
		this.mouse = (function()
		{ 
			var mouse = this; 
			
			/* this will store the mouse position */ 
			this.position = { x: null, y: null };  
			
			/* the mouse can be tracked by different modes 
			and this will control the tracking position mode */ 
			this.mode = 'page';  
			
			/* this will update the mouse position mode. 
			@param (string) mode = the position mode */ 
			this.updatePositionMode = function(mode) 
			{ 
				switch(mode) 
				{ 
					case 'client': 
						mouse.mode = mode;  
						break; 
					case 'screen': 
						mouse.mode = mode; 
						break; 
					default: 
						mouse.mode = 'page'; 
				}
			}; 
			
			/* this will add onmousemove event listener and return 
			standardized return of position then event. 
			@param [(function)] callBackFn = the callback function 
			@param [(object)] obj = the object to bind the listener 
			@param [(bool)] capture = event capture mode */
			this.enableTracking = function(callBackFn, obj, capture) 
			{ 
				if(typeof obj === "undefined") 
				{ 
					 obj = window; 
				}
				/* we want to update mouse position and 
				standardize the return */ 
				var mouseResults = function(e) 
				{
					// cross-browser result
					e = e || window.event; 
					
					var position = this.position = self.getMousePosition(e, self.mouse.mode); 

					/* we can now send the mouse wheel results to 
					the call back function */ 
					if(typeof callBackFn == 'function') 
					{ 
						callBackFn.call(position, e); 
					} 
				}; 
				
				self.events.add('mousemove', obj, mouseResults, capture, true, callBackFn);  
			}; 
			
			/* this will remove onmousemove event listener. 
			@param [(function)] callBackFn = the callback function 
			@param [(object)] obj = the object to bind the listener 
			@param [(bool)] capture = event capture mode */
			this.removeTracking = function(callBackFn, obj, capture) 
			{ 
				if(typeof obj === "undefined") 
				{ 
					 obj = window; 
				} 
				
				self.removeListener('mousemove', obj, callBackFn, capture); 
			}; 
			
			return this; 
			
			/* we want to bind an object to the IIFE 
			to allow strict mode */
		}).call({}); 
		
		/* this will get the current position of the 
		mouse position. You must first be tracking the 
		mouse to get the position. 
		@param (event) e = the event response 
		@param [(string)] = the request mode can be set
		to client */ 
		this.getMousePosition = function(e, requestMode) 
		{ 
			var position = { x: 0, y: 0 }; 
			
			// cross-browser event result
			e = e || window.event;
			
			if(e) 
			{ 
				/* we need to check if the mode is set to 
				client or return page position */ 
				if(requestMode == 'client') 
				{ 
					position.x = e.clientX || e.pageX; 
					position.y = e.clientY || e.pageY; 
				} 
				else if(requestMode == 'screen') 
				{ 
					position.x = e.screenX; 
					position.y = e.screenY; 
				}
				else 
				{ 
					position.x = e.pageX; 
					position.y = e.pageY; 
				}
			} 
			
			return position; 
		}; 
		
		this.onMouseWheel = function(fn, obj, cancelDefault, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var self = this; 
			
			/* we want to return the mousewheel data 
			to this private callback function before 
			returning to the call back function*/ 
			var mouseWeelResults = function(e) 
			{
				// cross-browser wheel delta
				var e = window.event || e; // old IE support
				var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail))); 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof fn == 'function') 
				{ 
					fn(delta); 
				} 
				
				/* we want to check to cancel default */ 
				if(typeof cancelDefault !== 'undefined' && cancelDefault == true) 
				{ 
					self.preventDefault(e); 
				} 
			}; 
			
			/* we need to check to add firefox support */ 
			if (obj.addEventListener) 
			{  
				self.events.add('DOMMouseScroll', obj, mouseWeelResults, capture, true, fn); 
			} 
			 
			self.events.add('mousewheel', obj, mouseWeelResults, capture, true, fn); 
			
			return this; 
		}; 
		
		/* this will prevent the default action 
		of an event 
		@param (object) e = the event object 
		@return (object) a reference to the base object */ 
		this.preventDefault = function(e) 
		{ 
			// cross-browser key result
			e = e || window.event; 
			
			if(e) 
			{ 
				if(typeof e.preventDefault !== 'undefined') 
				{ 
					e.preventDefault(); 
				} 
				else 
				{ 
					e.returnValue = false; 
				} 
			}
			
			return this; 
		}; 
		
		/* this will cancel the propagation of an event. 
		@param (object) e = the event object 
		@return (object) a reference to the base object */
		this.stopPropagation = function(e) 
		{ 
			// cross-browser key result
			e = e || window.event; 
		
			if(e) 
			{ 
				if(typeof e.stopPropagation !== 'undefined') 
				{ 
					e.stopPropagation();
				}
				else 
				{
					e.cancelBubble = true;
				} 
			} 
			
			return this; 
		}; 
		
		/* this will add onKeyUp event listener and return 
		standardized return of keycode then event. 
		@param (function) fn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode */  
		this.onKeyUp = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			/* we want to standardize the return */ 
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof fn == 'function') 
				{ 
					fn(e.keyCode, e); 
				} 
			};
			
			self.events.add('keyup', obj, keyCodeResults, capture, true, fn); 
			
			return this; 
		}; 
		
		/* this will add onKeyDown event listener and return 
		standardized return of keycode then event. 
		@param (function) fn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode */
		this.onKeyDown = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof fn == 'function') 
				{ 
					fn(e.keyCode, e); 
				} 
			};
			
			self.events.add('keydown', obj, keyCodeResults, capture, true, fn); 
			
			return this; 
		}; 
		
		/* this will add onKeyPress event listener and return 
		standardized return of keycode then event. 
		@param (function) fn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode */
		this.onKeyPress = function(fn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof fn == 'function') 
				{ 
					fn(e.keyCode, e); 
				} 
			};
			
			self.events.add('keypress', obj, keyCodeResults, capture, true, fn); 
			
			return this; 
		}; 
		
		/* this is an alias for getProperty. this will check to return 
		the property value from an object or return a default value or 
		return empty string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this */ 
		this.getValue = function(obj, property, defaultText) 
		{ 
			return self.getProperty(obj, property, defaultText);  
		}; 
		
		/* this will check to return the property value from an 
		object or return a default value or return empty 
		string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this */ 
		this.getProperty = function(obj, property, defaultText) 
		{ 
			/* we need to check if the object is available */ 
			if(obj && typeof obj == 'object') 
			{ 
				/* check if the object property has a value */ 
				if(obj[property]) 
				{ 
					/* we want to return the value */ 
					return obj[property]; 
				} 
			} 
			
			/* if no value was available 
			we want to return an empty string */ 
			if(typeof defaultText !== 'undefined') 
			{ 
				return defaultText; 
			} 
			else 
			{ 
				return ''; 
			} 
		}; 
		
		/* this will get the offset position of an object 
		in the document. 
		@params (object) obj = the object that is requesting the offset 
		@return (object) an object with the x and y position */
		this.getPosition = function(obj) 
		{ 
			var position = {x: 0, y: 0}; 
			
			if(obj && typeof obj == 'object') 
			{ 
				while(obj) 
				{ 
					position.x += (obj.offsetLeft + obj.clientLeft);
					position.y += (obj.offsetTop + obj.clientTop);
					obj = obj.offsetParent;
				} 
			} 
			return position; 
			
		}; 
		
		/* this will get the offset position of an object in a parent. 
		@params (object) obj = the object that is requesting the offset 
		@return (object) an object with the x and y position */
		this.position = function(obj) 
		{ 
			var position = {x: 0, y: 0}; 
			
			if(obj && typeof obj == 'object') 
			{ 
				position.x += (obj.offsetLeft - obj.scrollLeft + obj.clientLeft);
				position.y += (obj.offsetTop - obj.scrollTop + obj.clientTop); 
			} 
			return position; 
			
		}; 
		
		/* this will add a class to an object. 
		@params (object) obj = the object to add the class 
		@param (string) tmpClassName = the class name 
		@return (object) a reference to the base object */
		this.addClass = function(obj, tmpClassName) 
		{ 
			if(obj && typeof obj === 'object' && (typeof tmpClassName !== 'undefined' && tmpClassName != '')) 
			{ 
				try{
					addClass(obj, tmpClassName); 
				} 
				catch(e) 
				{ 
					/* we want to save the error */ 
					self.addError(e);  
				} 
			} 
			
			return this; 
		}; 
		
		/* this will add classes to an object. 
		@params (object) obj = the object to add the class 
		@param (string) classNameString = the class name 
		string spearated by spaces
		@return (object) a reference to the base object */
		this.addClasses = function(obj, classNameString) 
		{ 
			if(obj && typeof obj === 'object' && classNameString != '') 
			{ 
				if(typeof classNameString == 'string') 
				{ 
					/* we want to divide the string by spaces and 
					add any class listed */ 
					var adding = classNameString.split(' ');   
					for(var i = 0, maxLength = adding.length; i < maxLength; i++) 
					{ 
						self.addClass(obj, adding[i]);  
					} 
				} 
			} 
			
			return this; 
		};
		
		/* we only want to do one check if the system supports 
		modern class list checks and save them to a private 
		functions */ 
		var addClass, 
		removeClass, 
		hasClass; 
		
		if(typeof document.documentElement.classList !== 'undefined') 
		{ 
			// modern browsers 
			addClass = function(obj, tmpClassName) 
			{ 
				obj.classList.add(tmpClassName); 
			}; 
			
			removeClass = function(obj, tmpClassName) 
			{ 
				obj.classList.remove(tmpClassName); 
			}; 
			
			hasClass = function(obj, tmpClassName) 
			{ 
				return obj.classList.contains(tmpClassName); 
			};
		} 
		else 
		{ 
			// old browsers 
			addClass = function(obj, tmpClassName) 
			{ 
				obj.className = obj.className + ' ' + tmpClassName;   
			}; 
			
			removeClass = function(obj, tmpClassName) 
			{ 
				/* we want to get the object classes in an array */ 
				var classNames = obj.className.split(' ');  
				
				for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
				{ 
					/* if the class matches the tmpClassName we want to remove it */ 
					if(classNames[i] == tmpClassName) 
					{ 
						classNames.splice(i,1);  
					}
				}
			
				obj.className = classNames.join(' '); 
			}; 
			
			hasClass = function(obj, tmpClassName) 
			{ 
				/* we want to get the object classes in an array */ 
				var check = false, 
				classNames = obj.className.split(' ');  
				
				for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
				{ 
					/* if the class matches the tmpClassName we want to remove it */ 
					if(classNames[i] == tmpClassName) 
					{ 
						check = true;
						break;    
					}
				} 
				
				return check; 
			};
		}
		
		/* this will remove a class from an object. 
		@params (object) obj = the object to remove the class 
		@param (string) tmpClassName = the class name 
		@return (object) a reference to the base object */
		this.removeClass = function(obj, tmpClassName) 
		{ 
			if(typeof obj === 'object' && tmpClassName != '') 
			{ 
				/* if no className was specified we will remove all classes from object */ 
				if(typeof tmpClassName === 'undefined') 
				{ 
					obj.className = ''; 
				} 
				else 
				{ 
					try{
						removeClass(obj, tmpClassName); 
					} 
					catch(e) 
					{ 
						/* we want to save the error */ 
						self.addError(e);  
					} 
				}
			} 
			
			return this; 
		}; 
		
		/* this will remove a class from an object. 
		@params (object) obj = the object to remove the class 
		@param (string) classNameString = the class name 
		string spearated by spaces 
		@return (object) a reference to the base object */
		this.removeClasses = function(obj, classNameString) 
		{ 
			if(typeof obj === 'object' && classNameString != '') 
			{ 
				if(typeof classNameString == 'string') 
				{ 
					/* we want to divide the stringby spaces and 
					remove any class listed */ 
					var removing = classNameString.split(' ');   
					for(var i = 0, maxLength = removing.length; i < maxLength; i++) 
					{ 
						self.removeClass(obj, removing[i]);  
					} 
				} 
			} 
			
			return this; 
		}; 
		
		/* this will check if an object has a class. 
		@params (object) obj = the object
		@param (string) tmpClassName = the class name 
		@return (bool) true or false if the class is found */
		this.hasClass = function(obj, tmpClassName) 
		{ 
			var check = false; 
			if(obj && typeof obj === 'object' && tmpClassName != '') 
			{ 
				try{
					check = hasClass(obj, tmpClassName); 
				} 
				catch(e) 
				{ 
					/* we want to save the error */ 
					self.addError(e); 
				}
			} 
			
			return check;
		}; 
		
		/* this will toggle a class from an object. 
		@params (object) obj = the object to remove the class 
		@param (string) tmpClassName = the class name 
		@return (object) a reference to the base object */
		this.toggleClass = function(obj, tmpClassName) 
		{ 
			if(obj && typeof obj === 'object' && (typeof tmpClassName !== 'undefined' && tmpClassName != '')) 
			{ 
				var hasClass = self.hasClass(obj, tmpClassName);  
				if(hasClass) 
				{ 
					self.removeClass(obj, tmpClassName); 
				} 
				else 
				{ 
					self.addClass(obj, tmpClassName);
				}
			} 
			
			return this; 
		}; 
		
		/* this will get the type of var. 
		@param (mixed) data = the data to check 
		@return (string) the type */ 
		this.getType = function(data) 
		{ 
			var type = typeof data; 
			if(type == 'object') 
			{ 
				var isArray = self.isArray(data); 
				if(isArray == true) 
				{ 
					type = 'array'; 
				} 
			} 
			return type; 
		}; 
		
		/* we only want to do one check if the system supports 
		modern array checks and save it to a private function */ 
		var isArray; 
		
		if(typeof Array.isArray === 'function') 
		{ 
			// modern browsers 
			isArray = function(array) 
			{ 
				return Array.isArray(array); 
			}; 
		} 
		else 
		{ 
			// old browsers 
			isArray = function(array) 
			{ 
				if(array instanceof Array) 
				{ 
					return true; 
				} 
				return false;  
			}; 
		}
		
		/* this will check if an object is an array. 
		@param (mixed) array = the array to check  
		@return (bool) true or false if array is an array */ 
		this.isArray = function(array) 
		{ 
			isArray(array);  
		}; 
		
		/* this will search an array and return the index number of an array 
		or a -1 if the element is not found. 
		@param (array) array = the array to search 
		@param (mixed) element = the element to search in the array 
		@param [(int)] fromIndex = the index number to start searching from 
		@return (int) the index position or -1 if not found */ 
		this.inArray = function(array, element, fromIndex) 
		{ 
			if(array && typeof array === 'object') 
			{ 
				var index = inArray(array, element, fromIndex); 
				return index; 
			} 
			
			return -1; 
		}; 
		
		/* we only want to do one check if the system supports 
		modern array checks and save it to a private function */ 
		var inArray; 
		
		if(typeof Array.prototype.indexOf === 'function') 
		{ 
			// modern browsers 
			inArray = function(array, element, fromIndex) 
			{ 
				return array.indexOf(element, fromIndex); 
			}; 
		} 
		else 
		{ 
			// old browsers
			inArray = function(array, element, fromIndex) 
			{ 
				var length = (array.length);  
				var start = (!isNaN(fromIndex))? fromIndex : 0; 
				
				for(var i = start; i < length; i++) 
				{ 
					if(element === array[i]) 
					{ 
						return i; 
					} 
				}  
				return -1; 
			}; 
		}
		
		/* this will extend an object and return the extended 
		object or false.  
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		this.extendObject = function(sourceObj, targetObj) 
		{ 
			if(typeof sourceObj === 'object' && typeof targetObj === 'object') 
			{ 
				for(var property in sourceObj) 
				{ 
					if(sourceObj.hasOwnProperty(property) && typeof targetObj[property] === 'undefined') 
					{ 
						targetObj[property] = sourceObj[property]; 
					} 
				} 
				
				return targetObj; 
			} 
			return false; 
		}; 
		
		/* this will compare two values or objects 
		and return true or false if they match. 
		@param (mixed) option1 = the first option to compare 
		@param (mixed) option2 = the second option to compare 
		@return (bool) true or false if equal */ 
		this.equals = function(option1, option2) 
		{ 
			/* this will count object properties and compare values */ 
			var propertyCountAndCompare = function(obj1, obj2) 
			{ 
				var same = true; 
				
				/* this will count the properties of an object 
				and any child object properties */ 
				var countProperty = function(obj) 
				{ 
					var count = 0; 
					/* we want to count each property of the object */ 
					for(var property in obj) 
					{ 
						if(obj.hasOwnProperty(property)) 
						{ 
							count++;   
							if(typeof obj[property] === 'object') 
							{ 
								/* we want to do a recursive count to get 
								any child properties */
								count += countProperty(obj[property]); 
							}								
						} 
					} 
					return count; 
				}; 
				
				/* this will preform arecursive check to match the object properties. 
				@param (object) obj1 = the first object 
				@param (object) obj2 = the second object 
				@return (bool) true or falseif they match */ 
				var matchProperties = function(obj1, obj2) 
				{ 
					var matched = true; 
					
					if(typeof obj1 === 'object' && typeof obj2 === 'object') 
					{ 
						/* we want to check each object1 property to the 
						object 2 property */ 
						for(var property in obj1) 
						{ 
							/* we want to check if the property is owned by the 
							object and that they have matching types */ 
							if(obj1.hasOwnProperty(property) && obj2.hasOwnProperty(property) && typeof obj1[property] === typeof obj2[property]) 
							{ 
								/* we want to check if the type is an object */ 
								if(typeof obj1[property] == 'object') 
								{ 
									/* this will do a recursive check to the 
									child properties */ 
									matched = matchProperties(obj1[property], obj2[property]); 
									
									/* if a property did not match we can stop 
									the camparison */ 
									if(matched == false) 
									{ 
										break; 
									}
								} 
								else 
								{ 
									if(obj1[property] !== obj2[property]) 
									{ 
										matched = false; 
										break;
									}
								}
							} 
							else 
							{ 
								matched = false; 
								break; 
							}
						} 
					} 
					else 
					{ 
						matched = false; 
					} 
					
					return matched; 
				};  
				
				/* we want to check if they have the same number of 
				properties */ 
				var option1Count = countProperty(obj1), 
				option2Count = countProperty(obj2); 
				
				if(option1Count == option2Count) 
				{ 	
					/* we want to check if the properties match */ 
					var result = matchProperties(obj1, obj2); 
					if(result == false) 
					{ 
						same = false; 
					}
				} 
				else 
				{ 
					same = false; 
				} 
				
				return same; 
				
			}; 
			
			var same = true; 
			
			/* we want to check if there types match */ 
			if(typeof option1 === typeof option2) 
			{ 
				/* we need to check if the options are objects 
				because we will want to match all the 
				properties */ 
				if(typeof option1 === 'object' && typeof option2 === 'object') 
				{ 
					var matchResult = propertyCountAndCompare(option1, option2); 
					if(matchResult == false) 
					{ 
						same = false; 
					}
				}
				else 
				{ 
					if(option1 !== option2) 
					{ 
						same = false; 
					} 
				}
			} 
			else 
			{ 
				same = false; 
			} 
			
			return same; 
				
		}; 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (mixed) sourceClass = the original (class function 
		constructor or class prototype) unextended 
		@param (mixed) addingClass = the (class function constructor
		or class prototype) to add to the original */ 
		this.extendClass = function(sourceClass, targetClass) 
		{ 
			/* if we are using a class constructor function 
			we want to get the class prototype object */  
			var source = (typeof sourceClass === 'function')? sourceClass.prototype : sourceClass, 
			target = (typeof targetClass === 'function')? targetClass.prototype : targetClass;			
			
			if(typeof source === 'object' && typeof target === 'object') 
			{ 
				/* we want to create a new object from the 
				classObj */ 
				var obj = self.createObject(source); 
				
				/* we need to add any settings from the source that 
				are not on the prototype */ 
				this.extendObject(source, obj);
				
				/* we want to add any additional properties from the 
				target class to the new object */
				for(var prop in target) 
				{ 
					obj[prop] = target[prop]; 
				} 
				
				return obj; 
			} 
			return false; 
		}; 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		this.extendPrototype = function(source, target) 
		{ 
			target.prototype = new source(); 
			target.prototype.parent = source; 
			target.prototype.constructor = target;  
			
			return target; 
		}; 
		
		/* this will return a new object and extend it if an object it supplied. 
		@param [(object)] object = the extending object 
		@return (object) this will return a new object with the 
		inherited object */ 
		this.createObject = function(object) 
		{ 
			return createObject(object);  
		}; 	
		
		/* we only want to do one check if the system supports 
		modern create object and save them to a private 
		functions */ 
		var createObject; 
		
		if(typeof Object.create !== 'function') 
		{ 
			// modern browsers 
			createObject = function(object) 
			{ 
				return Object.create(object); 
			}; 
		} 
		else 
		{ 
			// old browsers 
			createObject = function(object) 
			{ 
				var obj = function(){}; 
				obj.prototype = object;
				return new obj();   
			}; 
		} 
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind 
		@return a bound method or false on error */ 
		this.createCallBack = function(obj, method, argArray) 
		{ 
			if(typeof method === 'function') 
			{ 
				return function() 
				{ 
					return method.apply(obj, argArray); 
				}; 
			} 
			else 
			{ 
				return false; 
			}
		}; 
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind */ 
		this.bind = function(obj, method) 
		{ 
			return bind(obj, method); 
		}; 
		
		/* we only want to do one check if the system supports 
		modern create object and save them to a private 
		functions */ 
		var bind; 
		
		if(typeof Function.prototype.bind === 'function') 
		{ 
			// modern browsers 
			bind = function(obj, method) 
			{ 
				return method.bind(obj); 
			}; 
		} 
		else 
		{ 
			// old browsers 
			bind = function(obj, method) 
			{ 
				return function() 
				{ 
					return method.apply(obj, arguments); 
				};   
			}; 
		}
		
		/* this will decode a json string. 
		@param (string) data = a json encoded string */ 
		this.jsonDecode = function(data) 
		{ 
			if(typeof data !== "undefined" && data.length > 0) 
			{ 
				try{ 
				
					return JSON.parse(data); 
				} 
				catch(e) 
				{ 
					return data; 
				} 
			} 
			
			return false; 
		}; 
		
		/* this will encode an object or array of objects. 
		@param (string) data = an object or array of objects */
		this.jsonEncode = function(data) 
		{ 
			if(typeof data !== "undefined") 
			{ 
				try{
					return JSON.stringify(data); 
				} 
				catch(e) 
				{ 
					return false; 
				}
			} 
			
			return false; 
		}; 
		
		/* this will parse an xml string. 
		@param (string) data = an xml string */
		this.xmlParse = function(data) 
		{ 
			if(typeof data !== "undefined") 
			{ 
				return xmlParse(data);  
			} 
			else 
			{ 
				return false; 
			} 
		}; 
		
		/* we only want to do one check if the system supports 
		modern xml parse and save it to a private function */ 
		var xmlParse; 
		
		if(typeof window.DOMParser !== 'undefined') 
		{ 
			// modern browsers 
			xmlParse = function(data) 
			{ 
				var parser = new DOMParser(); 
				return parser.parseFromString(data, "text/xml"); 
			}; 
		} 
		else 
		{ 
			// old browsers
			xmlParse = function(data) 
			{ 
				var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
				xmlDoc.async = false;
				return xmlDoc.loadXML(data); 
			}; 
		}  
		
		/* we need to return the instance of the object 
		so the prototype will be added to the base object */ 
		return this; 

		/* we needto call the fn with the bas object bound to the 
		IIFE to allow strict mode */ 
	}).call(base);  
	
	/* this will create an auto initializing function to return 
	the base framework prototype to allow new modules to be 
	added */ 
	base.prototype.extend = (function()
	{
		return this.prototype
	}).call(base);
	  
	/* we want to check if the framework has not already been setup */ 
	if(!(global.base)) 
	{ 
		/* we need to create a new instance of the base framework, 
		save it to the global object, and return it to the 
		autointializing function */ 
		var bse = new base(); 
		/* shorthand and long name */  
		global._b = global.base = bse; 
		return global.base; 
	} 
	else 
	{ 
		/* return the previous setup without create a new 
		instance */ 
		return global.base; 
	}  
	
})(this);  

/* base framework module */ 
/* 
	this adds ajax support to the base framwork  
*/ 
(function(global) 
{
	"use strict"; 
	
	/* this will add (ajax) xhr requests to the base framework */ 
	
	/* default settings */ 
	var defaultSettings = 
	{ 
		/* this is the xhr url to connect to */ 
		url: '',       
		
		/* this is the datatype of the server 
		response (string) */ 
		dataType:  'json', 
		
		/* this is the server action type (string) */ 
		type: 'POST', 
		
		/* headers (object) */ 
		headers: 
		{ 
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' 
		}, 
		
		/* this will set the ajax request to async (bool) */ 
		async: true, 
		
		/* cross domain (bool) */ 
		crossDomain: false, 
		
		/* cors with credentials (bool) */ 
		withCredentials: false,
		
		/* events (function) */ 
		completed: null, 
		failed: null, 
		aborted: null, 
		progress: null 
	}; 
	
	/* this will set the deafult ajax params to the 
	base object so they can be modified */ 
	base.extend.xhrSettings =  defaultSettings; 
	
	/* this will allow the ajax settings to be updated */ 
	base.extend.ajaxSettings = function(settingsObj) 
	{ 
		if(typeof settingsObj == 'object') 
		{ 
			base.xhrSettings = base.extendClass(base.xhrSettings, settingsObj); 
		}
	}; 
	
	/* this will reset the ajax settings */ 
	base.extend.resetAjaxSettings = function() 
	{ 
		base.xhrSettings = defaultSettings; 
	}; 
	
	/* this will send an ajax request and return 
	the xhr object */ 
	/* 
		the params can either be individual params or a settings object 
		
		individual param: 
		@param (string) url = the url to connect to  
		@param (string) params = the xhr params  
		@param (function) fn = the ajax callback function 
		@param [(dataType)] dataType = the data type of xhr response 
		@param [(type)] dataType = the send type to the server
		(json/xml/text) 
		@param [(bool)] async = this will enable or disable async
		
		settings object: 
		-url (string): the ajax file url 
		-params (string): the ajax param string 
		-type (string): the server request type 
		-dataType (string): the type of data to return (text, html, json) 
		if the dataType is json or xml the return text will be parsed 
		before it is return to the callback function 
		-async (bool): default is set to async 
		-headers (object): the headers to use 
		-crossDomain (bool): set true if performings cors 
		-withCredentials (bool): with credentials for cors
		-completed (function): the function to perform 
		when completed 
		-failed (function): the function to perform 
		if failed 
		-progress (function): the function to perform 
		during progress 
		-aborted (function): the function to perform 
		if aborted
		
	*/ 
	base.extend.ajax = function()
	{ 
		var self = this; 
		
		/* we want to save the args so we can check 
		which way we are adding the ajax settings */ 
		var args = arguments; 
		
		/* this will create an xhr request and perform all 
		the steps to setup and return the response */ 
		var request = function() 
		{ 
			/* this will be the xhr object */ 
			this.xhr = null; 
			
			/* this will be the ajax request settings */ 
			this.settings = null; 
			
			/* this is the ajax args */ 
			this.args = args; 
			
			var ajax = this; 
			
			/* this will setup a new xhr request and send it. if it 
			can setup it will return true else false */ 
			this.setup = function() 
			{ 
				/* we want to setup the ajax settings */ 
				ajax.getXhrSettings();  
				
				/* create a new xhr object */ 
				ajax.xhr = ajax.createXHR(); 
				if(ajax.xhr !== false) 
				{ 
					/* setup request */ 
					ajax.xhr.open(ajax.settings.type, ajax.settings.url, ajax.settings.async); 
					/* we want to add the xhr headers */ 
					ajax.setupHeaders(); 
					/* we want to add the events */ 
					ajax.addXhrEvents(); 
		 
					ajax.xhr.send(ajax.settings.params); 
					
					return true; 
				} 
				else 
				{ 
					return false; 
				}
			};  
			
			/* this will setup the request settings from the default 
			xhr settings and any settings being updated from the 
			ajax args */ 
			this.getXhrSettings = function() 
			{ 
				var args = ajax.args; 
				
				/* we want to create a clone of the default 
				settings */ 
				var settings = base.createObject(base.xhrSettings); 
				
				/* we want to set the default xhr settings before adding 
				the new settings */
				ajax.settings = settings; 
				
				/* we want to check if we are adding the ajax settings by 
				individual args or by a settings object */ 
				if(args.length >= 2 && typeof args[0] !== 'object') 
				{ 
					/* we want to add each arg as one of the ajax 
					settings */ 
					for(var i = 0, maxLength = args.length; i < maxLength; i++) 
					{ 
						var arg = args[i]; 
						
						switch(i) 
						{ 
							case 0: 
								ajax.settings.url = arg; 
								break; 
							case 1: 
								ajax.settings.params = arg; 
								break; 
							case 2: 
								ajax.settings.completed = arg; 
								ajax.settings.failed = arg;
								break; 
							case 3: 
								ajax.settings.dataType = arg || 'json'; 
								break; 
							case 4: 
								ajax.settings.type = (arg)? arg.toUpperCase() : 'POST'; 
								break; 
							case 5: 
								ajax.settings.async = (typeof arg !== 'undefined')? arg : true; 
								break; 
						} 
					} 
				}
				else 
				{ 
					/* override the default settings with the args 
					settings object */ 
					ajax.settings = base.extendClass(ajax.settings, args[0]); 
					
					/* we want to check to add the completed callback 
					as the error and aborted if not set */ 
					if(typeof ajax.settings.completed == 'function') 
					{ 
						if(typeof ajax.settings.failed != 'function') 
						{ 
							ajax.settings.failed = ajax.settings.completed; 
						} 
						
						if(typeof ajax.settings.aborted != 'function') 
						{ 
							ajax.settings.aborted = ajax.settings.failed; 
						} 
					} 
				} 
			}; 
			
			/* this will create and return an xhr object or return 
			false if not able */ 
			this.createXHR = function() 
			{ 
				var xhr; 
						
				/* this will return a standard xhr object */ 
				var createXHRObj = function() 
				{ 
					var xhr; 
					
					/* we want to check to add standard xhr request 
					else check to add older ie activex object */ 
					if(typeof XMLHttpRequest !== "undefined") 
					{ 
						xhr = new XMLHttpRequest(); 
					} 
					else 
					{ 
						try{ 
							xhr = new ActiveXObject("Msxml2.XMLHTTP"); 
						} 
						catch(e) 
						{ 
							try{ 
								xhr = new ActiveXObject("Microsoft.XMLHTTP"); 
							} 
							catch(e) 
							{ 
								base.addError(e); 
								xhr = null; 
							} 
						} 
					} 
					
					return xhr; 
				}; 
				
				/* this will create and return a cors xhr object */ 
				var createCorsXHRObj = function() 
				{ 
					var xhr = false; 
					
					/* we want to check if xmlHttpReqeust is level 2 */
					if(typeof XMLHttpRequest !== "undefined" && typeof XDomainRequest == "undefined") 
					{ 
						xhr = new XMLHttpRequest();  
					} 
					else if(typeof XDomainRequest != "undefined") 
					{ 
						xhr = new XDomainRequest(); 
					} 
					
					if(xhr && ajax.settings.withCredentials == true) 
					{ 
						try{ 
							xhr.withCredentials = true; 
						} 
						catch(e) 
						{ 
							base.addError(e); 
						}
					}
					
					return xhr; 
				}; 
				
				/* we want to check to setup the xhr by 
				the crossDomain settings */ 
				if(ajax.settings && ajax.settings.crossDomain == true) 
				{ 
					xhr = createCorsXHRObj(); 
				} 
				else 
				{ 
					xhr = createXHRObj(); 
				} 
				
				/* we want to return the new xhr object or 
				false if not created */ 
				if(xhr) 
				{ 
					return xhr; 
				} 
				else 
				{ 
					return false; 
				} 
			}; 
			
			/* this will setup the xhr headers */ 
			this.setupHeaders = function() 
			{ 
				if(ajax.settings && typeof ajax.settings.headers == 'object') 
				{ 
					/* we want to add a header for each 
					property in the object */ 
					for(var header in ajax.settings.headers) 
					{ 
						ajax.xhr.setRequestHeader(header, ajax.settings.headers[header]); 
					} 
				} 
			}; 
			
			/* this will get the server response and check the 
			ready state and status to return response to 
			request call back function */ 
			this.update = function(e, overrideType) 
			{ 
				e = e || window.event; 
				
				/* this will help clean up the data before 
				returning */ 
				var getResponseData = function() 
				{ 
					var response = ajax.xhr.responseText; 
						
					/* we want to check to decode the xhr response 
					if we have a response */ 
					if(typeof response == 'string') 
					{ 
						/* we want to check to decode the response by the type */ 
						switch(ajax.settings.dataType.toLowerCase()) 
						{ 
							case 'json': 
								var encoded = base.jsonDecode(response); 
								if(encoded !== false) 
								{ 
									response = encoded; 
								} 
								else 
								{ 
									response = response; 
									ajax.error = 'yes'; 
								}
								break; 
							case 'xml': 
								var encoded = base.xmlParse(response); 
								if(encoded !== false) 
								{ 
									response = encoded; 
								} 
								else 
								{ 
									response = response; 
									ajax.error = 'yes'; 
								} 
								break; 
							case 'text': 
								break;
								  
						} 
					} 
					
					return response; 
				}; 
				
				var type = (overrideType)? overrideType : e.type; 
				if(type == 'load') 
				{ 
					if(ajax.settings && typeof ajax.settings.completed == 'function') 
					{ 
						var response = getResponseData();  
						ajax.settings.completed(response, ajax.xhr); 
					} 
				} 
				else if(type == 'error') 
				{ 
					if(ajax.settings && typeof ajax.settings.failed == 'function') 
					{ 
						ajax.settings.failed(false, ajax.xhr); 
					} 
				} 
				else if(type == 'progress') 
				{ 
					if(ajax.settings && typeof ajax.settings.progress == 'function') 
					{  
						ajax.settings.progress(e); 
					} 
				} 
				else if(type == 'abort') 
				{ 
					if(ajax.settings && typeof ajax.settings.aborted == 'function') 
					{  
						ajax.settings.aborted(false, ajax.xhr); 
					} 
				}  
			}; 
			
			this.checkReadyState = function(e) 
			{ 
				e = e || window.event; 
				
				/* check the response state */
				if(ajax.xhr.readyState != 4)
				{ 
					/* the response is not ready */ 
					return; 
				} 
				
				/* check the response status */ 
				if(ajax.xhr.status == 200) 
				{ 
					 /* the ajax was successful 
					 but we want to change the event type to load */ 
					 var type = 'load';  
					 ajax.update(e, type); 
				} 
				else 
				{ 
					/* there was an error */ 
					var type = 'error'; 
					ajax.update(e, type); 					 
				} 
			}; 
			
			this.addXhrEvents = function() 
			{ 
				var settings = ajax.settings; 
				
				if(settings) 
				{ 
					/* we need to check if we can add new event listeners or 
					if we have to use the old ready state */ 
					if(typeof ajax.xhr.onload !== 'undefined') 
					{ 
						base.addListener('load', ajax.xhr, base.bind(ajax, ajax.update)); 
						base.addListener('error', ajax.xhr, base.bind(ajax, ajax.update)); 
						base.addListener('progress', ajax.xhr.upload, base.bind(ajax, ajax.update)); 
						base.addListener('abort', ajax.xhr, base.bind(ajax, ajax.update)); 
					} 
					else 
					{ 
						ajax.xhr.onreadystatechange = function(e){ ajax.checkReadyState(e); }; 
					}
				} 
			};  
		}; 
 
		/* we want to create a new ajax request */ 
		var ajaxRequest = new request();   
		ajaxRequest.setup();  
		
		/* we want to return the xhr object */ 
		return ajaxRequest.xhr; 
	}; 
})(this); 

/* base framework module */ 
/* 
	this will create dynamic html to be 
	added and modified  
*/ 
(function() 
{
	"use strict"; 
	
	/* this will add a new html builder object that 
	can be extended to the object that you want to 
	build with */  
	var htmlBuilder = function()
	{ 
	
	}; 
	
	/* we want to save the methods to the prototype 
	to allow inheritance */ 
	htmlBuilder.prototype = 
	{ 
		/* this will create an html element by nodeType, add to 
		the specified parent container and return the new 
		element. 
		@param (string) nodeType = the element node type name
		@param (object) attrObject = the node attributes to add 
		to the element. 
		@param (mixed) container = the parent container element 
		or id 
		@param (bool) prepend = this will add the element 
		to the begining of theparent */
		create: function(nodeName, attrObject, container, prepend)
		{ 
			var filterProperty = function(prop) 
			{ 
				switch(prop) 
				{ 
					case 'class': 
						prop = 'className'; 
						break; 
					case 'for': 
						prop = 'htmlFor'; 
						break; 
					case 'readonly': 
						prop = 'readOnly'; 
						break; 
					case 'maxlength': 
						prop = 'maxLength'; 
						break; 
					case 'cellspacing': 
						prop = 'cellSpacing'; 
						break; 
					case 'rowspan': 
						prop = 'rowSpan'; 
						break; 
					case 'colspan': 
						prop = 'colSpan'; 
						break; 
					case 'tabindex': 
						prop = 'tabIndex'; 
						break; 
					case 'cellpadding': 
						prop = 'cellPadding'; 
						break; 
					case 'usemap': 
						prop = 'useMap'; 
						break; 
					case 'frameborder': 
						prop = 'frameBorder'; 
						break; 
					case 'contenteditable': 
						prop = 'contentEditable'; 
						break;
				} 
				
				return prop; 
			}; 
			
			//object  
			var obj = document.createElement(nodeName);
			
			/* we want to check if we have attrributes to add */ 
			if(typeof attrObject === 'object') 
			{ 
				/* we want to add each attr to the obj */ 
				for(var prop in attrObject) 
				{   
					var propName = filterProperty(prop); 
					
					/* we want to check to add the attr settings
					 by property name */  
					if(prop == 'innerHTML') 
					{ 
						/* we need to check if we are adding inner 
						html content */
						obj.innerHTML = attrObject[prop]; 
					} 
					else if(prop.substring(0, 5) == 'data-') 
					{ 
						base.data(obj, prop, attrObject[prop]); 
					}
					else 
					{ 
						/* we want to add the new attr as a named array 
						because this allows dynamic event attr and 
						normal attr */ 
						if(typeof attrObject[prop] !== 'undefined' && attrObject[prop] != '') 
						{ 
							obj[propName] = attrObject[prop];  
						}
					}
				}
			}
			
			try
			{ 
				/* we want to check if the new element should be 
				added to the begining or end */ 
				if(prepend == true) 
				{ 
					this.prepend(container, obj); 
				} 
				else 
				{ 
					this.append(container, obj); 
				} 
			} 
			catch(e) 
			{ 
				this.error(e, obj); 
			} 
			
			return obj;  
		
		}, 
		
		/* this will create a document fragment to allow elements 
		to be added to a container element without rendering until the 
		fragment gets appended to an element. 
		@return (object) the document fragment */ 
		createDocFragment: function() 
		{ 
			var obj = document.createDocumentFragment(); 
			return obj; 
		}, 
		
		/* this will create an html element and return the new object 
		@param (string) nodeName = the new element node Name or tag name 
		@param (string) id = the node id 
		@param (string) className = the element className 
		@param (string) html = the element innerHTML content
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */
		addElement: function(nodeName, id, className, html, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			var obj = this.create(nodeName, attr, container, prepend); 
			
			return obj;   
		}, 
		
		/* this will create an html element and add an onclick to the 
		callback function and return the new object 
		@param (string) nodeName = the new element node Name or tag name 
		@param (string) id = the node id 
		@param (string) className = the element className 
		@param (string) html = the element innerHTML content 
		@param (function) callBackFn = the callback function
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addButton: function(nodeName, id, className, html, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			
			if(typeof callBackFn === 'function') 
			{ 
				attr.onclick = callBackFn; 
			}
			
			var obj = this.create(nodeName, attr, container, prepend); 
			
			return obj; 
		}, 
		
		/* this will create a checkbox return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (function) callBackFn = the callback function 
		@param (bool) checked = when true the element will be checked
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */
		addCheckbox: function(id, className, callBackFn, checked, container, stopPropagation)
		{ 
			var attr = { id: id, 'className': className, type: 'checkbox' };  
			
			if(typeof stopPropagation !== 'undefined' && stopPropagation == true) 
			{ 
				attr.onclick = base.stopPropagation; 
			} 
			
			if(typeof callBackFn == 'function') 
			{ 
				attr.onchange = callBackFn; 
			}
			
			if(checked == true) 
			{ 
				attr.checked = true; 
			} 
			
			var obj = this.create('input', attr, container); 
			
			return obj;  
		
		},  
		
		/* this will create a radio return the new object  
		@param (string) id = the node id 
		@param (string) name = the name
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (bool) checked = when true the element will be checked
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addRadio: function(id, name, className, value, fn, checked, container, stopPropagation)
		{ 
			var attr = { id: id, name: name, 'className': className, value: value, type: 'radio' };  
			
			if(typeof stopPropagation !== 'undefined' && stopPropagation == true) 
			{ 
				attr.onclick = base.stopPropagation; 
			} 
			
			if(typeof fn == 'function') 
			{ 
				attr.onchange = fn; 
			}
			
			if(checked == true) 
			{ 
				attr.checked = true; 
			}
			
			var obj = this.create('input', attr, container); 
			
			return obj;  
		
		}, 
		
		/* this will create an input and return the new object  
		@param (string) inputType = the input type
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (string) placeholder = the input placeholder
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addInput: function(inputType, id, className, value, callBackFn, placeholder, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value, type: inputType };  
			
			attr.onfocus = this.select;
			
			if(typeof callBackFn == 'function') 
			{ 
				attr.onkeyup = function(){ callBackFn(this.value); }; 
			} 
			
			if(placeholder) 
			{ 
				attr.placeholder = placeholder; 
			}
			
			var obj = this.create('input', attr, container, prepend); 
			
			return obj;
		
		}, 
		
		/* this will create a textarea and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addTextarea: function(id, className, value, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value };  
			
			attr.onfocus = this.select;
			
			if(typeof callBackFn == 'function') 
			{ 
				attr.onblur = callBackFn; 
				attr.onkeyup = callBackFn; 
			} 
			
			var obj = this.create('textarea', attr, container, prepend); 
			
			return obj; 
		
		}, 
		
		/* this will create a select and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addSelect: function(id, className, value, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value };  
			
			if(typeof callBackFn == 'function') 
			{ 
				attr.onchange = function(){ callBackFn(this.value); };  
			} 
			
			var obj = this.create('select', attr, container, prepend); 
			
			return obj; 
		
		}, 
		
		/* this will add options to a select   
		@param (mixed) selectElem = the select element or id  
		@param (array) optionArray = and array with objects 
		to use as options 
		@param [(string)] defaultValue = the select default 
		value */ 
		setupSelectOptions: function(selectElem, optionArray, defaultValue) 
		{ 
			if(selectElem !== null) 
			{ 
				/* if the select id was sent we need to get 
				the element */ 
				if(typeof selectElem !== 'object') 
				{ 
					selectElem = document.getElementById(selectElem);   
				}
						
				/* we need to check if we have any options to add */ 
				if(optionArray && optionArray.length) 
				{ 			
					/* create each option then add it to the select */   
					for(var n = 0, maxLength = optionArray.length; n < maxLength; n++) 
					{ 
						selectElem.options[n] = new Option(optionArray[n].label, optionArray[n].value); 
						
						/* we can select an option if a default value 
						has been sumbitted */ 
						if(typeof defaultValue !== 'undefined') 
						{ 
							if(selectElem.options[n].value == defaultValue) 
							{ 
								selectElem.options[n].selected = true;   
							} 
						} 
					} 
				}
			} 
		}, 
		
		/* this will create an image and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) src = the image src 
		@param (string) alt = the image alt 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addImage: function(id, className, src, alt, container, prepend)
		{ 
			var attr = { id: id, 'className': className };  
			
			if(typeof alt !== 'undefined') 
			{ 
				attr.alt = alt; 
			} 
			
			if(typeof src !== 'undefined') 
			{ 
				attr.src = src; 
			} 
			
			var obj = this.create('img', attr, container, prepend); 
			
			return obj;   
		
		}, 
		
		addForm: function(id, action, method, autocomplete, novalidate, enctype, target, container, prepend)
		{ 
			var attr = { id: id };  
			
			if(typeof method !== 'undefined') 
			{ 
				attr.method = method; 
			}
			
			if(typeof autocomplete !== 'undefined') 
			{ 
				attr.autocomplete = autocomplete; 
			} 
			
			if(typeof novalidate !== 'undefined') 
			{ 
				attr.novalidate = novalidate; 
			} 
			
			if(typeof enctype !== 'undefined') 
			{ 
				attr.enctype = enctype; 
			} 
			
			if(typeof target !== 'undefined') 
			{ 
				attr.target = target; 
			}
			
			var obj = this.create('form', attr, container, prepend); 
			
			return obj;   
		
		}, 
		
		/* this will create an image and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) src = the src url  
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addIframe: function(id, className, src, container, prepend)
		{ 
			var attr = { id: id, 'className': className };  
			
			if(typeof src !== 'undefined') 
			{ 
				attr.src = src; 
			} 
			
			attr.width = '100%'; 
			attr.height = '100%';   
			attr.frameBorder = "0"; 
			
			var obj = this.create('iframe', attr, container, prepend); 
			
			return obj;  
		
		}, 
		
		/* this will create an a link and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) html = the element inner html
		@param (string) url = the link url  
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addLink: function(id, className, html, url, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			
			if(url !== null) 
			{ 
				attr.href = url; 
			}
			
			var obj = this.create('a', attr, container, prepend); 
			
			return obj; 
		}, 
		
		/* this will remove an element from a parent  
		@param (mixed) child = the child element or id */
		removeElement: function(obj) 
		{ 
			var container; 
			
			if(typeof obj == 'string') 
			{ 
				obj = document.getElementById(child); 
				container = obj.parentNode; 
			} 
			else 
			{ 
				container = obj.parentNode; 
			} 
			
			if(container) 
			{ 
				/* we want to remove all events aded to the 
				element */ 
				base.events.removeElementEvents(obj); 
				
				container.removeChild(obj); 
			} 
		}, 
		
		/* this is an alias for removeElement. This will remove a 
		child element.   
		@param (mixed) child = the child element or id */
		removeChild: function(child) 
		{ 
			this.removeElement(child);   
		}, 
		
		/* this will remove all child elements.    
		@param (mixed) container = the container element or id */
		removeAll: function(container) 
		{ 
			if(typeof container == 'string') 
			{ 
				container = document.getElementById(container); 
			}  
			
			if(typeof container === 'object') 
			{ 
				while(container.firstChild) 
				{ 
					this.removeElement(container.firstChild); 
				} 
			}
		},  
		
		changeParent: function(child, newParent) 
		{ 
			var container; 
			
			if(typeof child == 'string') 
			{ 
				child = document.getElementById(child);  
			}  
			
			if(typeof newParent == 'string') 
			{  
				container = document.getElementById(newParent); 
			} 
			else 
			{ 
				container = newParent; 
			}
			
			container.appendChild(child); 
		}, 
		
		append: function(parent, child) 
		{ 
			if(typeof parent === "undefined") 
			{ 
				parent = document.body; 
			} 
			else if(typeof parent == 'string') 
			{    
				parent = document.getElementById(parent); 
			} 
			 
			if(parent && typeof parent === 'object') 
			{ 
				parent.appendChild(child);  
			}
		},  
		
		prepend: function(parent, child) 
		{ 
			if(typeof parent === "undefined") 
			{ 
				parent = document.body; 
			} 
			else if(typeof parent == 'string') 
			{ 
				parent = document.getElementById(parent);  
			} 
		 
		 	if(parent && typeof parent === 'object') 
			{
				parent.insertBefore(child, parent.firstChild); 
			}		 
		},  
		
		/* this will clone a node and return the 
		copy or false */ 
		clone: function(node, deepCopy) 
		{ 
			if(typeof node === 'object') 
			{ 
				deepCopy = deepCopy || false; 
			
				return node.cloneNode(deepCopy); 
			} 
			else 
			{ 
				return false; 
			} 
		}, 
		
		error: function(error, object) 
		{ 
			console.log(error.message, object);   
		} 
	}; 
	
	/* we want to add a new shorthand and instance of the html 
	builder to the base framework */ 
	base.extend.dom = base.extend.htmlBuilder = new htmlBuilder(); 
})();

/* base framework module */ 
/* 
	this adds touch support to the base framework  
*/ 
(function() 
{
	"use strict";  
	
	/* this will add an event listener for touch to an object */ 
	/* 
		@param function fn = the function to be performed 
		on the event. 
		@param object obj = object to receive the event 
	*/ 
	base.extend.touch = function(fn, obj)
	{ 
		/* this will be the object that receievedthe touch listeners */ 
		this.element = (typeof obj !== 'undefined')? obj : document; 
		
		this.callBackFunction = fn; 
		
		/* we want to track all the touch settings */ 
		this.fingerCount = 0;
		this.startPosX = 0;
		this.startPosY = 0;
		this.posX = 0;
		this.posY = 0; 
		this.minLength = 72; 
		this.swipeLength = 0;
		this.swipeAngle = null;
		this.swipeDirection = null; 
		
		var self = this; 
		
		this.add = function() 
		{ 
			/* check if the browser supports touch */ 
			if('ontouchstart' in document.documentElement) 
			{ 
				base.addListener("touchstart", self.element, self.touchStart);
				base.addListener("touchmove", self.element, self.touchMove);
				base.addListener("touchend", self.element, self.touchEnd);
				base.addListener("touchcancel", self.element, self.touchCancel); 
				
				return true; 
			} 
			else 
			{ 
				return false; 
			} 
		}; 
		
		this.remove = function() 
		{ 
			base.removeListener("touchstart", self.element, self.touchStart);
			base.removeListener("touchmove", self.element, self.touchMove);
			base.removeListener("touchend", self.element, self.touchEnd);
			base.removeListener("touchcancel", self.element, self.touchCancel);
		}; 
		
		this.touchStart = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e);
			// get the total number of fingers touching the screen
			self.fingerCount = e.touches.length;
			
			/* only track if one finger is being used*/ 
			if ( self.fingerCount == 1 ) 
			{
				// get the coordinates of the touch
				self.startPosX = e.touches[0].pageX;
				self.startPosY = e.touches[0].pageY;
			} 
			else 
			{
				// more than one finger touched so cancel
				self.touchCancel(e);
			}
		}; 
		
		this.touchMove = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e); 
			
			if ( e.touches.length == 1 ) 
			{
				self.posX = e.touches[0].pageX;
				self.posY = e.touches[0].pageY;
			} 
			else 
			{
				self.touchCancel(e);
			} 
		}; 
		
		this.touchEnd = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e); 
			
			/* we want to check if there was only one finger used and that we have a last position */ 
			if ( self.fingerCount == 1 && self.posX != 0 ) 
			{ 
				// use the Distance Formula to determine the length of the swipe
				self.swipeLength = Math.round(Math.sqrt(Math.pow(self.posX - self.startPosX, 2) + Math.pow(self.posY - self.startPosY, 2))); 
				
				// if the user swiped more than the minimum length, perform the appropriate action
				if(self.swipeLength >= self.minLength) 
				{ 
					calculateAngle(); 
					getSwipeDirection(); 
					
					/* call back function */ 
					if(self.callBackFunction) 
					{ 
						self.callBackFunction(self.swipeDirection); 
					} 

					self.touchCancel(e); // reset the variables
				} 
				else 
				{
					self.touchCancel(e);
				}	
			} 
			else 
			{
				self.touchCancel(e);
			} 
		}; 
		
		this.touchCancel = function(e) 
		{ 
			self.fingerCount = 0;
			self.startPosX = 0;
			self.startPosY = 0;
			self.posX = 0;
			self.posY = 0; 
			self.swipeLength = 0;
			self.swipeAngle = null;
			self.swipeDirection = null; 
		}; 
		
		var getSwipeDirection = function() 
		{ 
			if((self.swipeAngle <= 45) && (self.swipeAngle >= 0)) 
			{
				self.swipeDirection = 'left';
			} 
			else if((self.swipeAngle <= 360) && (self.swipeAngle >= 315)) 
			{
				self.swipeDirection = 'left';
			} 
			else if((self.swipeAngle >= 135) && (self.swipeAngle <= 225)) 
			{
				self.swipeDirection = 'right';
			} 
			else if((self.swipeAngle > 45) && (self.swipeAngle < 135)) 
			{
				self.swipeDirection = 'down';
			} 
			else 
			{
				self.swipeDirection = 'up';
			} 
		}; 
		
		var calculateAngle = function() 
		{ 
			var positionX = self.startPosX - self.posX;
			var positionY = self.posY - self.startPosY; 
			
			/* we need to get the distance */ 
			var z = Math.round(Math.sqrt(Math.pow(positionX,2) + Math.pow(positionY,2))); 
			
			//angle in radians 
			var r = Math.atan2(positionY,positionX); 

			//angle in degrees 
			self.swipeAngle = Math.round(r * 180 / Math.PI); 
			
			if (self.swipeAngle < 0) 
			{ 
				self.swipeAngle =  360 - Math.abs(self.swipeAngle); 
			}; 
		}; 
		
	}; 
})();

/* base framework module */ 
/* 
	css animation add and remove with full object 
	animation tracking 
*/ 
(function() 
{
	"use strict"; 
	
	/* this is a helper fuction to remove a class and hide 
	an element. 
	@param (object) obj = the element to hide 
	@param (string) animationClass = the css class name */ 
	var removeClassAndHide = function(obj, animationClass)
	{  
		obj.style.display = 'none'; 
		removeAnimationClass(obj, animationClass); 
	}; 
	
	/* this is a helper fuction to remove an animation 
	class after it has been animated.  
	@param (object) obj = the element object 
	@param (string) animationClass = the css class name */
	var removeAnimationClass = function(obj, animationClass)
	{ 
		base.removeClass(obj, animationClass); 
		base.animate.animating.remove(obj);   
	};
	
	/* this will add and remove css animations */ 
	base.extend.cssAnimate = { 
		
		/* this class tracks all objects being animated and can 
		add and remove them when completed */  
		animating: 
		{ 
			objects: [], 
			 
			add: function(object, className, timer) 
			{ 
				this.stopPreviousAnimations(object); 
				
				this.addObject(object, className, timer);  
			}, 
			
			addObject: function(object, className, timer) 
			{ 
				if(object) 
				{ 
					var animation = { 
						object: object, 
						className: className, 
						timer: timer 
					}; 
					
					this.objects.push(animation); 
				} 
			},  
			
			remove: function(object) 
			{ 
				/* we need to get the object index to 
				know which timer to remove */
				var objectIndex = this.removeObject(object);  
			}, 
			
			removeObject: function(object, removeClass) 
			{ 
				if(object) 
				{ 
					var animating = this.checkAnimating(object); 
				
					if(animating !== false) 
					{ 
						var animations = animating; 
						
						for(var i = 0, maxLength = animations.length; i < maxLength; i++) 
						{ 
							var animation = animations[i]; 
							
							/* we want to stop the timer */ 
							this.stopTimer(animation); 
							
							if(removeClass) 
							{ 
								/* we want to remove the className */ 
								base.removeClass(animation.object, animation.className); 
							}
							
							/* we want to remove the animation fron the object array */ 
							//var indexNumber = this.objects.indexOf(animation); 
							var indexNumber = base.inArray(this.objects, animation);
							if(indexNumber >= 0) 
							{ 
								this.objects.splice(indexNumber, 1); 
							}
						}
					}  
				} 
			}, 
			
			stopTimer: function(animation) 
			{ 
				if(animation) 
				{ 
					var timer = animation.timer; 
					window.clearTimeout(timer); 
				}
			}, 
			
			checkAnimating: function(obj) 
			{ 
				var animationArray = []; 
				
				/* we want to get any timers set for our object */ 
				for(var i = 0, maxLength = this.objects.length; i < maxLength; i++) 
				{ 
					 var animation = this.objects[i]; 
					 if(animation.object == obj) 
					 { 
						animationArray.push(animation); 
					 } 
				} 
				
				if(animationArray.length >= 1) 
				{ 
					return animationArray; 
				} 
				else 
				{ 
					return false; 
				} 
			}, 
			
			stopPreviousAnimations: function(obj) 
			{ 
				/* we want to remove the timers and class names 
				from the object */ 
				this.removeObject(obj, 1);   
			},
			
			reset: function() 
			{ 
				this.objects = [];   
			}
		}, 
		
		/* this will perform an animation on the object and 
		then turn the object to display none after the 
		duration */  
		hide: function(object, animationClass, duration)
		{ 
			if(typeof object == 'string') 
			{ 
				var obj = document.getElementById(object); 
			} 
			else 
			{ 
				obj = object; 
			}
			
			base.addClass(obj, animationClass);    
			
			var callBack = base.createCallBack(null, removeClassAndHide, [obj, animationClass]); 
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
			
		}, 
		
		/* this will dsiplay the object then perform an animation 
		on the object and remove the class after the duration */ 
		show: function(object, animationClass, duration)
		{ 
			if(typeof object == 'string') 
			{ 
				var obj = document.getElementById(object); 
			} 
			else 
			{ 
				obj = object; 
			} 
			
			base.addClass(obj, animationClass); 
			obj.style.display = 'block'; 
			
			var callBack = base.createCallBack(null, removeAnimationClass, [obj, animationClass]);
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
			
		},  
		
		/* this will add an animation class on the object then 
		it will remove the class when the duration is done */ 
		add: function(object, animationClass, duration)
		{ 
			if(typeof object == 'string') 
			{ 
				var obj = document.getElementById(object); 
			} 
			else 
			{ 
				obj = object; 
			} 
			
			base.addClass(obj, animationClass); 
			
			var callBack = base.createCallBack(null, removeAnimationClass, [obj, animationClass]);
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
			
		} 
	}; 
})(); 

/* base framework module */ 
/* 
	date and time 
*/ 
(function() 
{
	"use strict"; 
	
	/* this will enable date and time functions */ 
	base.extend.date = {  
		
		/* this will store all the month names*/ 
		monthNames: ["January","February","March","April","May","June","July","August","September","October","November","December"], 
		
		/* this will store all the day names */ 
		dayNames: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], 
		
		/* this will return the name of a day or false 
		not found. 
		@param [(int)] day = the day to use if nothing 
		is set it will use the current day 
		@param [(bool)] shortenName = set to true to return only 
		first 3 chars of name */ 
		getDayName: function(day, shortenName) 
		{ 
			day = (typeof month !== 'undefined')? day : new Date().getDate();
			
			var dayName = false; 
			/* we want to check if the day number is 
			less than the array length */ 
			if(day < this.dayNames.length) 
			{ 
				/* we want to check to shorten name */ 
				var dayName = (shortenName)? this.dayNames[day].substring(0, 3) : this.dayNames[day]; 
			}
			
			return dayName; 
		},
		
		/* this will check if a year is a leap year 
		and return true or false. 
		@param (int) year = the year to check */ 
		leapYear: function(year) 
		{ 
			var leapYear = false; 
			
			if((year % 400 == 0) || (year % 100 != 0 && year % 4 == 0))
			{ 
				leapYear = true;
			} 
			
			return leapYear; 
		}, 
		
		/* this will return the name of a month or false 
		if not found. 
		@param [(int)] month = the month to use if nothing 
		is set it will use the current month 
		@param [(bool)] shortenName = set to true to return only 
		first 3 chars of name */ 
		getMonthName: function(month, shortenName) 
		{ 
			month = (typeof month !== 'undefined')? month : new Date().getMonth(); 
			
			var monthName = false; 
			/* we want to check if the month number is 
			less than the array length */ 
			if(month < this.monthNames.length) 
			{ 
				/* we want to check to shorten name */ 
				monthName = (shortenName)? this.monthNames[month].substring(0, 3) : this.monthNames[month]; 
			} 
			
			return monthName; 
		}, 
		
		/* this will return the length of a month. 
		@param [(int)] month = the month to use if nothing 
		is set it will use the current month 
		@param [(int)] year = the year to use if nothing 
		is set it will use the current year */ 
		getMonthLength: function(month, year) 
		{ 
			/* we want to check to use params or use 
			default */ 
			month = (typeof month !== 'undefined')? month : new Date().getMonth();
			year = (typeof year !== 'undefined')? year : new Date().getFullYear(); 
			
			/* we need to get the month lengths for 
			the year */ 
			var yearMonthLengths = this.getMonthsLength(year); 
			
			/* we can select the month length from 
			the yearMonthLengths array */ 
			var monthLength = yearMonthLengths[month]; 
			
			return monthLength; 
			
		}, 
		
		/* this will return an array with all the month 
		lengths for a year. 
		@params [(int)] year = the year to use if nothing
		is set it will use the current year */ 
		getMonthsLength: function(year) 
		{ 
			year = (typeof year !== 'undefined')? year : new Date().getFullYear();
			
			/* we needto check if the year is a leap year */ 
			var isLeapYear = this.leapYear(year); 
			if(isLeapYear == true)
			{ 
				var days = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
			}
			else
			{ 
				var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; 
			} 
			
			return days; 
		}, 
		
		toYears: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(milliseconds/(1000*60*60*24*365.26)); 
			} 
			return false; 
		}, 
		
		toDays: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(milliseconds/(60*60*1000*24)*1); 
			} 
			return false; 
		}, 
		
		toHours: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor((milliseconds%(60*60*1000*24))/(60*60*1000)*1); 
			} 
			return false; 
		}, 
		
		toMinutes: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(((milliseconds%(60*60*1000*24))%(60*60*1000))/(60*1000)*1); 
			} 
			return false; 
		}, 
		
		toSeconds: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor((((milliseconds%(60*60*1000*24))%(60*60*1000))%(60*1000))/1000*1); 
			} 
			return false; 
		},
		
		/* this will get the difference between two dates 
		and return a time object with the difference in 
		years, days, hours, minutes, seconds, milliseconds. 
		@param (date) startDate = the starting date 
		@param (date) endDate = the end date */ 
		getDifference: function(startDate, endDate) 
		{ 
			/* we want to convert the dates to objects */ 
			var start = new Date(startDate);  
			var end = new Date(endDate); 
			
			/* we want to subtract the start time from the end */ 
			var difference = (end.getTime() - start.getTime()); 
			
			var time = { 
				years:  this.toYears(difference),  
				days:  this.toDays(difference), 
				hours:  this.toHours(difference), 
				minutes:  this.toMinutes(difference), 
				seconds:  this.toSeconds(difference) 
			}; 
			
			return time; 
		}
	}; 
})();

/* base framework module */ 
/* 
	html5 history state 
*/ 
(function() 
{
	"use strict"; 
	
	/* this will update the page title */ 
	var updateTitle =  function(title) 
	{ 
		document.title = title; 
	}; 	
	
	/* this will check if the user is sending the title 
	by the state object because most browsers dont use 
	the current title param. 
	@param (string) title = the new title 
	@param (object) stateObj = the new state object */ 
	var getStateTitle = function(title, stateObj) 
	{ 
		title = (title == null && stateObj.title)? stateObj.title : title; 
		return title; 
	}; 
	
	/* this will add and remove states from window history */ 
	base.extend.history = {  
		
		/* this will check if history api is supported and if so 
		return true else return false */ 
		isSupported: function() 
		{ 
			if('history' in window && 'pushState' in window.history) 
			{ 
				return true; 
			} 
			else 
			{ 
				return false; 
			} 
		}, 
		
		/* this will add and event listener for window popstate. 
		@param (function) fn = the function to use as callback 
		@param [(bool)] capture = event capture */ 
		addEvent: function(fn, capture) 
		{ 
			/* this will check if the current state has a  
			title property to update thepage title */ 
			var popEvent = function(e) 
			{ 
				if(e.state && e.state.title) 
				{ 
					updateTitle(e.state.title); 
				} 
				
				fn(e); 
			}; 
			
			base.events.add('popstate', window, popEvent, capture, true, fn) 
		}, 
		
		/* this will remove and event listener for window popstate. 
		@param (function) fn = the function to use as callback 
		@param [(bool)] capture = event capture */ 
		removeEvent: function(fn, capture) 
		{ 
			base.removeListener('popstate', window, fn, capture); 
		},
		
		/* this will add a state to the window history 
		@param (object) object = the state object 
		@param (string) title = the state page title 
		@param (string) url = the state url */  
		pushState: function(object, title, url)
		{  
			var lastState = window.history.state; 
			title = getStateTitle(title, object); 

			/* we want to check if the object is not already
			the last saved state */ 
			if(!lastState || !base.equals(lastState, object)) 
			{  
				/* we want to add the new state to the window history*/ 
				window.history.pushState(object, title, url);   
			} 
			
			updateTitle(title);
		}, 
		
		/* this will add a state to the window history 
		@param (object) object = the state object 
		@param (string) title = the state page title 
		@param (string) url = the state url */  
		replaceState: function(object, title, url)
		{  
			title = getStateTitle(title, object); 
			/* we want to add the new state to the window history*/ 
			window.history.replaceState(object, title, url);  
			
			updateTitle(title); 
		},
		
		/* this will go to the next state in the window history */ 
		nextState: function()
		{ 
			window.history.forward();  
		},  
		
		/* this will go to the previous state in the window history */ 
		prevState: function()
		{ 
			window.history.back();  
		}, 
		
		/* this will take you to a specified number in the history 
		index. 
		@param (int) indexNumber= the number to go to */ 
		goTo: function(indexNumber) 
		{ 
			window.history.go(indexNumber); 
		} 
	}; 
})();