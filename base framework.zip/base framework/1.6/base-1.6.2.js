/* 

	base framework 
	
	This is a mini javascript framework to allow complex  
	functions to work in many browsers and versions. 
	
	The framework can also be extended to add additional 
	functionality. 
	
*/ 

(function(global) 
{ 
	"use strict"; 
	
	/* 
		base framework constructor
		
		This will set all settings of the base framework and 
		allow all modules to be extended from the base 
		prototype. 
	*/ 
	var base = function() 
	{ 
		/* the version number */ 
		this.version = '1.6.2';  
	};  
	 
	/* we want to add the intial methods to the base prototype 
	so they can be inherited */ 
	base.prototype = { 
	
		/* reset the constructor */ 
		constructor: base, 
		
		/* this will store all the errors */ 
		errors: [],  
		
		/* this will get the last error 
		@return (mixed) the last error object or false if no errors */ 
		getLastError: function() 
		{ 
			return (this.errors.length)? this.errors.pop() : false; 
		},  
		
		/* this will add an error object to the base 
		error array 
		@param (object) err = the error object */ 
		addError: function(err) 
		{ 
			this.errors.push(err); 
		},
	
		/* this will return an object with the params 
		from the url or false if none found */ 
		parseQueryString: function() 
		{ 
			var str = window.location.search, 
			objURL = {}, 
			regExp = /([^?=&]+)(=([^&]*))?/g; 
		
			str.replace(regExp, function(a, b, c, d)
			{ 
				/* we want to save the key and the 
				value to the objURL */ 
				objURL[b] = d;
			}); 
			
			/* we want to check if the url has any params */ 
			return (this.isEmpty(objURL) === false)? objURL : false;  
		}, 
		
		/* this is an alias for parse query string and will
		 return an object with the params from the url */ 
		getParams: function() 
		{  
			return this.parseQueryString();   
		},  
		
		/* this will check if an object is empty. 
		@param (object) obj = the object to check 
		@return (bool) true or false if empty */ 
		isEmpty: function(obj) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 
				/* we want to loop through each property and 
				check if it belongs to the object directly */ 
				for(var key in obj) 
				{
					if(obj.hasOwnProperty(key)) 
					{ 
						return false;
					} 
				} 
			}
			return true;
		}, 
		
		/* this will select an html element by id. 
		@param (string) id = the id of the element 
		@return (mixed) the element or false on error */ 
		getById: function(id) 
		{ 
			if(typeof id === 'string') 
			{ 
				var obj = document.getElementById(id);  
				return (obj)? obj : false; 
			} 
			return false; 
		}, 
		
		/* this will select html elements by name and return 
		a list. 
		@param (string) name = the name of the elements 
		@return (mixed) the elements array or false on error */ 
		getByName: function(name) 
		{ 
			if(typeof name === 'string') 
			{ 
				var obj = document.getElementsByName(name);  
				return (obj)? this.listToArray(obj) : false;
			} 
			return false; 
		}, 
		
		/* this will select html elements by css selector. 
		@param (string) name = the name of the elements
		@param [(int)] single = setup to only select the 
		first element 
		@return (mixed) the element or false on error */ 
		getBySelector: function(selector, single) 
		{ 
			if(typeof selector === 'string') 
			{ 
				/* we want to check if we are only selecting 
				the first element or all elements */ 
				single = single || false; 
				if(single === true) 
				{ 
					var obj = document.querySelector(selector); 
					return (obj)? obj : false;
				} 
				else 
				{ 
					var elements = document.querySelectorAll(selector);  
					if(elements) 
					{ 
						/* if there is only one result just return the 
						first element in the node list */ 
						return (elements.length === 1)? elements[0] : this.listToArray(elements);  
					} 
				} 
			} 
			return false; 
		}, 
		
		/* this will convert a nodelist into an array. 
		@param (nodeList) list = the list to convert 
		@return (array) */ 
		listToArray: function(list) 
		{ 
			return Array.prototype.slice.call(list); 
		}, 
		
		/* this will either set the innerHTML of an object or 
		return the innerHTML of an element.
		@param object obj = the object to use  
		@param [(string)] html = the html to insert
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		html is being accessed the html will be returned */
		html: function(obj, html) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 
				/* we want to check if we are getting the 
				html or adding the html */ 
				if(typeof html !== 'undefined') 
				{ 
					try{ 
						/* we want to check to set the value */ 
						obj.innerHTML = html; 
					} 
					catch(e) 
					{ 
						this.addError(e); 
					} 
					return this; 
				} 
				else 
				{ 
					return obj.innerHTML; 
				} 
			}  
		}, 
		
		/* this will either set the css style value 
		to an object or return the value of the style property.
		@param object obj = the object to use 
		@param (string) property = the css property name 
		@param [0ptional](string) value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		css: function(obj, property, value) 
		{ 
			if(typeof obj === 'object' && typeof property !== 'undefined') 
			{ 
				/* we want to check if we are getting the 
				value or setting the value */ 
				if(typeof value !== 'undefined') 
				{ 
					property = this.uncamelCase(property); 
					obj.style[property] = value;  
					
					return this; 
				} 
				else 
				{ 
					property = this.uncamelCase(property);
					var css = obj.style[property]; 
					if(css === '') 
					{ 
						/* we want to check if we have an inherited 
						value */ 
						css = obj.currentStyle ? obj.currentStyle[property] : window.getComputedStyle(obj, null)[property]; 
					} 
					return css; 
				} 
			}  
		}, 
		
		/* this will remove the attribute of an object
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@return (object) a reference to the base object 
		to allow chaining */
		removeAttr: function(obj, property) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var removeAttr;  
			if(typeof document.documentElement.removeAttribute === 'function') 
			{ 
				removeAttr = function(obj, property) 
				{ 
					obj.removeAttribute(property); 
				}; 
			} 
			else 
			{ 
				removeAttr = function(obj, property) 
				{ 
					/* we cannot remove the attr through the remove 
					attr method so we want to null the value. 
					we want to camel caps the propety */ 
					property = base.prototype.camelCase(property); 
					obj.property = null; 
				}; 
			} 
			
			var self = this; 
			this.removeAttr = function(obj, property) 
			{ 
				if(typeof obj === 'object') 
				{ 	
					try{ 
						/* we want to check to set the value */ 
						removeAttr(obj, property); 
					} 
					catch(e) 
					{ 
						self.addError(e); 
					}
				} 
				return self; 
			}; 
			
			/* we need to manually initialize the first time */ 
			return this.removeAttr(obj, property);   
		}, 
		
		/* this will either set the attribute and value 
		to an object or return the value of an attribute.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [0ptional](string) value = the value to 
		add to the attribute
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned */
		attr: function(obj, property, value) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var addAttr;  
			if(typeof document.documentElement.setAttribute === 'function') 
			{ 
				// modern browsers 
				addAttr = function(obj, property, value) 
				{ 
					obj.setAttribute(property, value); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				addAttr = function(obj, property, value) 
				{ 
					obj[property] = value;   
				}; 
			} 
			
			/* create a local function to perform the check 
			once then override the function */ 
            var getAttr;  
			if(typeof document.documentElement.getAttribute === 'function') 
			{ 
				// modern browsers 
				getAttr = function(obj, property) 
				{ 
					return obj.getAttribute(property); 
				};
			} 
			else 
			{ 
				// old browsers 
				getAttr = function(obj, property) 
				{ 
					return obj[property]; 
				};
			}
			
			var self = this; 
			this.attr = function(obj, property, value) 
			{ 
				if(typeof obj === 'object') 
				{ 
					/* we want to check if we are getting the 
					value or setting the value */ 
					if(typeof value !== 'undefined') 
					{ 
						try{ 
							/* we want to check to set the value */ 
							addAttr(obj, property, value); 
						} 
						catch(e) 
						{ 
							self.addError(e); 
						} 
						
						return self; 
					} 
					else 
					{ 
						return getAttr(obj, property); 
					} 
				} 
				return false; 
			}; 
			
			/* we need to manually initialize the first time */ 
			return this.attr(obj, property, value); 
		}, 
		
		/* this will either set the data attribute and value 
		to an object or return the data value.
		@param object obj = the object to use 
		@param (string) property = the attribut property name 
		@param [0ptional](string) value = the value to 
		add to the attribute 
		@return (mixed) if the value is being set a 
		reference to the base object will be return, if the 
		value is being accessed the value will be returned
		*/
		data: function(obj, property, value) 
		{ 
			/* this will check if the property is not 
			prefixed with data for older browsers */ 
			var checkPrefix = function(prop) 
			{ 
				if(typeof prop !== 'undefined') 
				{ 
					/* we want to de camelcase if set */ 
					prop = base.prototype.uncamelCase(prop); 
					if(prop.substring(0, 5) !== 'data-') 
					{ 
						prop = 'data-' + prop;   
					}  
				} 
				return prop; 
			};
			/* create a local function to perform the check 
			once then override the function */ 
            var addData;  
			if(typeof document.documentElement.dataset !== 'undefined') 
			{ 
				// modern browsers 
				addData = function(obj, property, value) 
				{ 
					/* this will return the property without the data prefix */ 
					var removePrefix = function(prop) 
					{ 
						if(typeof prop !== 'undefined') 
						{ 
							if(prop.substring(0, 5) === 'data-') 
							{ 
								prop = prop.substring(5);   
							}  
						} 
						return prop; 
					}; 
					
					property = removePrefix(property); 
					property = base.prototype.camelCase(property); 
	
					obj.dataset[property] = value; 
				}; 
			} 
			else 
			{ 
				// old browsers 
				addData = function(obj, property, value) 
				{ 
					/* we need to check the prop prefix */ 
					property = checkPrefix(property); 
					base.prototype.attr(obj, property, value);   
				}; 
			}
			
			/* we want to override parent method with new method to 
            cache the local function */ 
			var self = this; 
			this.data = function(obj, property, value) 
			{ 
				if(typeof obj === 'object') 
				{ 
					if(typeof value !== 'undefined') 
					{ 
						addData(obj, property, value);  
						return self; 
					} 
					else 
					{ 
						/* we need to check the prop prefix */ 
						property = checkPrefix(property);
						return self.attr(obj, property); 
					} 
				} 
				return false; 
			}; 
			
			/* we need to manually initialize the first time */ 
			return this.data(obj, property, value); 
		}, 
		
		/* this will find child elements in an element.
		@param object obj = the object to use 
		@param string queryString = the query string 
		@return (mixed) a nodeList or false on error */
		find: function(obj, queryString) 
		{ 
			var result = false; 
			
			if(obj && typeof obj === 'object' && typeof queryString === 'string') 
			{ 
				try{ 
					result = obj.querySelectorAll(queryString); 
				} 
				catch(e) 
				{ 
					this.addError(e); 
				} 
			} 
			return result; 
		}, 
		
		/* this will display an element.
		@param object obj = the object to use 
		@return (object) a referenceto the base object 
		to allow method chaining */
		show: function(obj) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 
				/* we want to get the previous display style 
				from the data-style-display attr */
				var previous = this.data(obj, 'style-display'), 
				value = (typeof previous === 'string')? previous : ''; 
				
				this.css(obj, 'display', value);  
			}
			
			return this; 
		}, 
		
		/* this will hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object  
		to allow chaining */
		hide: function(obj) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 
				/* we want to set the previous display style 
				on the element as a data attr */ 
				var previous = this.css(obj, 'display'); 
				if(previous !== 'none' && previous != '') 
				{ 
					this.data(obj, 'style-display', previous); 
				}
				
				this.css(obj, 'display', 'none'); 
			} 
			
			return this; 
		}, 
		
		/* this will display or hide an element.
		@param object obj = the object to use 
		@return (object) a reference to the base object 
		to allow chaining */
		toggle: function(obj) 
		{ 
			if(obj && typeof obj === 'object') 
			{ 
				var mode = this.css(obj, 'display'); 
				if(mode !== 'none') 
				{ 
					this.hide(obj); 
				} 
				else 
				{ 
					this.show(obj); 
				} 
			} 
			
			return this; 
		}, 
		
		/* this will camelcase a string that is separated 
		with a space, hyphen, or underscore and retun. 
		@param (string) str = the string to camelcase */ 
		camelCase: function(str) 
		{ 
			if(typeof str === 'string') 
			{ 
				var regExp = /(-|\s|\_)+\w{1}/g; 
				return str.replace(regExp, function(match) 
				{ 
					return match[1].toUpperCase(); 
				}); 
			} 
			return false; 
		}, 
		
		/* this will uncamelcase a string and separate with a delimter 
		and retun. 
		@param (string) str = the string to camelcase
		@param [(string)] delimiter = the string delimiter */ 
		uncamelCase: function(str, delimiter) 
		{ 
			if(typeof str === 'string') 
			{ 
				delimiter = delimiter || '-'; 
				
				var regExp = /([A-Z]{1,})/g; 
				return str.replace(regExp, function(match) 
				{ 
					return delimiter + match.toLowerCase(); 
				}).toLowerCase(); 
			} 
			return false; 
		},
		
		/* this will return an object with the width and height 
		of an object.
		@param object obj = the object to get the 
		width and height 
		@return (mixed) an object with the width and size or 
		false on error */ 
		getSize: function(obj) 
		{ 
			var size = { 
				width: 0, 
				height: 0 
			}; 
			
			/* we want to check if the object is not supplied */ 
			if(obj && typeof obj === 'object') 
			{ 
				size.width = this.getWidth(obj); 
				size.height = this.getHeight(obj); 
				
				return size; 
			} 
			else 
			{ 
				return false;  
			} 
		},
		
		/* this will return the width of an object.
		@param object obj = the object to get the 
		width 
		@return (mixed) the width int or false on error */ 
		getWidth: function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			if(obj && typeof obj === 'object') 
			{ 
				return obj.offsetWidth; 
			} 
			else 
			{ 
				return false;  
			} 
		}, 
		
		/* this will return the height of an object.
		@param object obj = the object to get the 
		height
		@return (mixed) the height int or false on error */ 
		getHeight: function(obj) 
		{ 
			/* we want to check if the object is not supplied */ 
			if(obj && typeof obj === 'object') 
			{ 
				return obj.offsetHeight; 
			} 
			else 
			{ 
				return false;  
			} 
		},
		
		/* this will get the scroll position of an object and 
		return an object with top and left scroll position or 
		false on error. 
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) an object with the left and top position 
		 or false on error */ 
		getScrollPosition: function(obj) 
		{ 
			var position = { 
				left: 0, 
				top: 0 
			}; 
			
			/* we wantto check if the object is not supplied */ 
			if(typeof obj === 'undefined') 
			{ 
				/* we want to use the document body */ 
				var doc = document.documentElement;
				position.left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
				position.top = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0); 
				
				return position; 
			} 
			else 
			{ 
				/* we want to use the object */ 
				if(obj && typeof obj === 'object') 
				{ 
					position.left = (obj.scrollLeft) - (obj.clientLeft || 0);
					position.top = (obj.scrollTop)  - (obj.clientTop || 0); 
					
					return position;
				} 
				else 
				{ 
					return false; 
				} 
			} 
		}, 
		
		/* this will return the scroll top position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		@return (mixed) the top position int or false on error */ 
		getScrollTop: function(obj) 
		{ 
			var position = this.getScrollPosition(obj); 
			return (position !== false)? position.top : false;  
		}, 
		
		/* this will return the left scroll position 
		of an object or false if not found.
		@param (optional) object obj = the object to get the 
		scroll position, if blank it will return the document 
		scroll position
		*/ 
		getScrollLeft: function(obj) 
		{ 
			var position = this.getScrollPosition(obj); 
			return (position !== false)? position.left : false; 
		},  
		
		/* this will get the window size and return 
		an object with the height and width */ 
		getWindowSize: function() 
		{ 
			var w = window,
			d = document,
			e = d.documentElement,
			g = d.getElementsByTagName('body')[0],
			x = w.innerWidth || e.clientWidth || g.clientWidth,
			y = w.innerHeight|| e.clientHeight|| g.clientHeight; 
			
			return { 
				width: x, 
				height: y 
			}; 
		}, 
		
		/* this will return the window height */ 
		getWindowHeight: function() 
		{ 
			var size = this.getWindowSize();  
			return size.height;  
		}, 
		
		/* this will return the window width */ 
		getWindowWidth: function() 
		{ 
			var size = this.getWindowSize(); 
			return size.width;  
		}, 
		
		/* this will return the document size */ 
		getDocumentSize: function() 
		{ 
			var size = { 
				width: 0, 
				height: 0 
			}; 
			
			var body = document.body,
			html = document.documentElement;
		
			size.height = Math.max( body.scrollHeight, body.offsetHeight, 
			html.clientHeight, html.scrollHeight, html.offsetHeight ); 
			
			size.width = Math.max( body.scrollWidth, body.offsetWidth, 
			html.clientWidth, html.scrollWidth, html.offsetWidth );
			
			return size; 
		},
		
		/* this will return the document height */ 
		getDocumentHeight: function() 
		{ 
			var size = this.getDocumentSize();  
			return size.height; 
		},  		
		
		/* this class will add, remove and track active active 
		event listeners */ 
		events: { 
			
			/* this will store all active events */ 
			activeEvents: [], 
			
			/* this will  create an object to use through the event 
			tracker. 
			@param string event = the name of the event to listen 
			@param object obj = obj to add the listener 
			@param function fn = function to perform on event 
			@param bool capture = event capture
			@param bool swapped = tells if the even return was 
			swapped with a standardized function. 
			@param function originalFn = the original function  
			return function was swapped.  
			*/ 
			createEventObj: function(event, obj, fn, capture, swapped, originalFn) 
			{ 
				/* we want to check if the swapped param was set */ 
				swapped = (typeof swapped !== 'undefined')? swapped : false; 
				
				var activeEvent = { 
					event: event, 
					obj: obj, 
					fn: fn, 
					capture: capture, 
					swapped: swapped, 
					originalFn: originalFn 
				}; 
				return activeEvent; 
			}, 
			
			/* this will and an event listener and add 
			to the event tracker. 
			@param string event = the name of the event to listen 
			@param object obj = obj to add the listener 
			@param function fn = function to perform on event 
			@param bool capture = event capture
			@param bool swapped = tells if the even return was 
			swapped with a standardized function. 
			@param function originalFn = the original function */ 
			add: function(event, obj, fn, capture, swapped, data) 
			{ 
				/* create a local function to perform the check 
				once then override the function */ 
				var addEvent;  
				if(typeof global.addEventListener === 'function') 
				{ 
					// modern browsers
					addEvent = function(obj, event, fn, capture) 
					{ 
						obj.addEventListener(event, fn, capture);
					}; 
				} 
				else if(typeof document.attachEvent === 'function') 
				{ 
					// old ie 
					addEvent = function(obj, event, fn, capture) 
					{ 
						obj.attachEvent("on" + event, fn);
					}; 
				} 
				else 
				{ 
					addEvent = function(obj, event, fn, capture) 
					{ 
						obj["on" + event] = fn;
					}; 
				}  
				
				/* we want to override parent method with new method to 
            	cache the local function */
				var self = this; 
				this.add = function(event, obj, fn, capture, swapped, data) 
				{ 
					capture = (typeof capture !== 'undefined')? capture : false; 

					if(obj && typeof obj === 'object') 
					{ 
						/* we want to create an event object and add it the 
						the active events to track */ 
						var activeEvent = self.createEventObj(event, obj, fn, capture, swapped, data);  
						self.activeEvents.push(activeEvent); 
						
						try{ 
							addEvent(obj, event, fn, capture);  
						} 
						catch(e) 
						{ 
							base.prototype.addError(e); 
						}  
					} 
				
					return self; 
				}; 
				
				/* we need to manually initialize the first time */ 
				return this.add(event, obj, fn, capture, swapped, data); 
			}, 
			
			/* this remove the event and remove from the tracker. 
			@param string event = the name of the event to listen 
			@param object obj = obj to add the listener 
			@param function fn = function to perform on event 
			@param bool capture = event capture */ 
			remove: function(event, obj, fn, capture) 
			{ 
				capture = (typeof capture !== 'undefined')? capture : false; 
				
				/* we want to select the event from the active events array */ 
				var searchEvent = this.getActiveEvent(event, obj, fn, capture); 
				if(searchEvent !== false) 
				{ 
					var listener = searchEvent; 
					if(typeof listener === 'object') 
					{ 
						/* we want to use the remove event method and just 
						pass the listener object */ 
						this.removeEvent(listener);  
					} 
				} 
				return this; 
			},  
			
			/* this will remove an event object and the listener 
			from the active events array.   
			@param (object) listener = the listener object from 
			the active events array */ 
			removeEvent: function(listener) 
			{ 
				/* create a local function to perform the check 
				once then override the function */ 
				var removeEvent;  
				if(typeof global.removeEventListener === 'function') 
				{ 
					// modern browsers
					removeEvent = function(obj, event, fn, capture) 
					{ 
						obj.removeEventListener(event, fn, capture);
					};
				} 
				else if(typeof document.detachEvent === 'function') 
				{ 
					// old ie 
					removeEvent = function(obj, event, fn, capture) 
					{ 
						obj.detachEvent("on" + event, fn);
					};
				} 
				else 
				{ 
					removeEvent = function(obj, event, fn, capture) 
					{ 
						obj["on" + event] = null; 
					};
				} 
				
				/* we want to override parent method with new method to 
            	cache the local function */ 
				var self = this;
				this.removeEvent = function(listener) 
				{ 
					if(typeof listener === 'object') 
					{ 
						var object = listener.obj; 
						try{ 
							removeEvent(object, listener.event, listener.fn, listener.capture);  
						} 
						catch(e) 
						{ 
							base.prototype.addError(e); 
						} 
					} 
					
					/* we want to remove the event from the active events array */  
					var index = base.prototype.inArray(self.activeEvents, listener);
					if(index >= 0) 
					{ 
						self.activeEvents.splice(index, 1); 
					} 
					return self;
				}; 
				
				return this.removeEvent(listener);  
			}, 
			
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param string event = the name of the event to listen 
			@param object obj = obj to add the listener 
			@param function fn = function to perform on event 
			@param bool capture = event capture
			@return (mixed) the event object or false if not found */ 
			getActiveEvent: function(event, obj, fn, capture) 
			{ 
				/* we want to create an object to search by */ 
				var listener = this.createEventObj(event, obj, fn, capture); 
				var searchEvent = this.searchEvent(listener); 
				
				/* if the search returns anything but false we 
				found our active event */ 
				return (searchEvent !== false)? searchEvent : false;  
			}, 
				
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param object eventObj = the listener object to search  
			*/
			searchEvent: function(eventObj) 
			{ 
				if(typeof eventObj === 'object') 
				{ 
					/* we want to get the event listener from 
					the active event array */ 
					var searchEvent = this.searchAllEvents(eventObj); 
					
					/* if the search returns anything but false we 
					found our active event */ 
					if(searchEvent !== false) 
					{ 
						return searchEvent; 
					} 
					else 
					{ 
						/* we want to check if the event was swapped for 
						a standardized return function */ 
						var searchSwappedEvent = this.searchAllEvents(eventObj, true); 

						/* if the search returns anything but false we 
						found our active event */ 
						if(searchSwappedEvent !== false) 
						{ 
							return searchSwappedEvent; 
						}
					}
				} 
				
				return false; 
			}, 
			
			/* this will search for an return an active event or return 
			false if nothing found. 
			@param object eventObj = the listener object to search  
			@param bool swappedSearch = will enable checking of swapped events */
			searchAllEvents: function(eventObj, swappedSearch) 
			{ 
				var events = this.activeEvents; 
				
				if(typeof eventObj === 'object') 
				{ 
					/* check if the swapped search was setup */ 
					swappedSearch = (typeof swappedSearch !== 'undefined')? swappedSearch : false;  
				
					/* we want to check if the search is a swapped search to 
					verfiy the event type is swappable */ 
					if(swappedSearch == true) 
					{ 
						var swappable = this.isSwappedEventType(eventObj.event);  
						if(swappable == false) 
						{ 
							/* if the event type is not swappable we need to return 
							without checking */
							return false; 
						} 
					}					
					
					for(var i = 0, maxLength = events.length; i < maxLength; i++) 
					{ 
						var listener = events[i]; 
						
						/* we want to check if we are search by swapped 
						events or normal events */ 
						if(swappedSearch == false) 
						{ 
							/* we want to check the listener event with the
							 event object */ 
							if(listener.event === eventObj.event && listener.obj === eventObj.obj && listener.fn === eventObj.fn) 
							{ 
								return listener;  
							} 
						} 
						else 
						{ 
							if(listener.swapped == true) 
							{ 
								/* we want to check the listener event using 
								its swapped settings with the event object */
								if(listener.event === eventObj.event && listener.obj === eventObj.obj && listener.originalFn === eventObj.fn) 
								{ 
									return listener;  
								} 
							}
						}
					} 
				} 
				
				return false; 
			}, 	
			
			/* this will remove all events added to an element through 
			the base framework.  
			@param (object) obj = the element object */
			removeElementEvents: function(obj) 
			{ 
				if(obj && typeof obj === 'object') 
				{ 
					var events = this.activeEvents, 
					removeEvents = []; 
					for(var i = 0, maxLength = events.length; i < maxLength; i++) 
					{ 
						var listener = events[i]; 
						if(listener && listener.obj === obj) 
						{ 
							removeEvents.push(listener); 
						}
					} 
					
					for(var i = 0, maxLength = removeEvents.length; i < maxLength; i++) 
					{ 
						var listener = removeEvents[i]; 
						if(listener) 
						{ 
							this.removeEvent(listener); 
						} 
					} 
				} 
				return this; 
			}, 
			
			swappedEvents: [ 
				'keydown', 
				'keyup', 
				'keypress', 
				'DOMMouseScroll', 
				'mousewheel', 
				'mousemove', 
				'popstate' 
			], 
			
			/* this will check if an event type could be swapped. 
			@param string event = the type of event
			 */ 
			isSwappedEventType: function(event) 
			{ 
				/* these event types can have standarized return 
				functions*/ 
				var swappedEvents = this.swappedEvents;  
				
				/* we want to check if the event type is in the 
				swapped event array */ 
				var index = base.prototype.inArray(swappedEvents, event); 
				if(index >= 0) 
				{
					/* we have found an event that may have been swapped 
					by our standardized return functions */
					return true;  
				} 
				
				return false; 
			}
		}, 
		
		/* this will add an event listener. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		addListener: function(event, obj, fn, capture) 
		{  
			/* we want to add this to the active events */ 
			this.events.add(event, obj, fn, capture);  
			
			return this; 
		}, 
		
		/* this will remove an event listener. 
		@param string event = the name of the event to listen 
		@param object obj = obj to add the listener 
		@param function fn = function to perform on event 
		@param bool capture = event capture
		@return (object) a reference to the base object */
		removeListener: function(event, obj, fn, capture) 
		{ 
			/* we want to remove this from the active events */ 
			this.events.remove(event, obj, fn, capture);  
			
			return this; 
		},  
		
		onLoad: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			 
			this.events.add('load', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		onClick: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('click', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		onDoubleClick: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('dblclick', obj, callBackFn, capture); 
			
			return this; 
		},
		
		onMouseOver: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('mouseover', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		onMouseOut: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('mouseout', obj, callBackFn, capture); 
			
			return this; 
		},
		
		onMouseDown: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('mousedown', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		onMouseUp: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('mouseup', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		onMouseMove: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			this.events.add('mousemove', obj, callBackFn, capture); 
			
			return this; 
		}, 
		
		/* this will enable the mouse tracking to be enabled 
		and disabled and the position can be set to page, 
		client, or screen */ 
		mouse: 
		{ 
			/* this will store the mouse position */ 
			position: { x: null, y: null }, 
			
			/* the mouse can be tracked by different modes 
			and this will control the tracking position mode */ 
			mode: 'page', 
			
			/* this will update the mouse position mode. 
			@param (string) mode = the position mode */ 
			updatePositionMode: function(mode) 
			{ 
				switch(mode) 
				{ 
					case 'client': 
						this.mode = mode;  
						break; 
					case 'screen': 
						this.mode = mode; 
						break; 
					default: 
						this.mode = 'page'; 
				}
			}, 
			
			/* this will add onmousemove event listener and return 
			standardized return of position then event. 
			@param [(function)] callBackFn = the callback function 
			@param [(object)] obj = the object to bind the listener 
			@param [(bool)] capture = event capture mode */
			enableTracking: function(callBackFn, obj, capture) 
			{ 
				if(typeof obj === "undefined") 
				{ 
					 obj = window; 
				}
				/* we want to update mouse position and 
				standardize the return */ 
				var mouseResults = function(e) 
				{
					// cross-browser result
					e = e || window.event; 
					
					var position = this.position = base.prototype.getMousePosition(e, base.prototype.mouse.mode); 

					/* we can now send the mouse wheel results to 
					the call back function */ 
					if(typeof callBackFn === 'function') 
					{ 
						callBackFn.call(position, e); 
					} 
				}; 
				
				base.prototype.events.add('mousemove', obj, mouseResults, capture, true, callBackFn);  
			}, 
			
			/* this will remove onmousemove event listener. 
			@param [(function)] callBackFn = the callback function 
			@param [(object)] obj = the object to bind the listener 
			@param [(bool)] capture = event capture mode */
			removeTracking: function(callBackFn, obj, capture) 
			{ 
				if(typeof obj === "undefined") 
				{ 
					 obj = window; 
				} 
				
				base.prototype.removeListener('mousemove', obj, callBackFn, capture); 
			}
		}, 
		
		/* this will get the current position of the 
		mouse position. You must first be tracking the 
		mouse to get the position. 
		@param (event) e = the event response 
		@param [(string)] = the request mode can be set
		to client */ 
		getMousePosition: function(e, requestMode) 
		{ 
			var position = { x: 0, y: 0 }; 
			
			// cross-browser event result
			e = e || window.event;
			
			if(e) 
			{ 
				/* we need to check if the mode is set to 
				client or return page position */ 
				if(requestMode === 'client') 
				{ 
					position.x = e.clientX || e.pageX; 
					position.y = e.clientY || e.pageY; 
				} 
				else if(requestMode === 'screen') 
				{ 
					position.x = e.screenX; 
					position.y = e.screenY; 
				}
				else 
				{ 
					position.x = e.pageX; 
					position.y = e.pageY; 
				}
			} 
			
			return position; 
		},
		
		onMouseWheel: function(callBackFn, obj, cancelDefault, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var self = this; 
			
			/* we want to return the mousewheel data 
			to this private callback function before 
			returning to the call back function*/ 
			var mouseWeelResults = function(e) 
			{
				// cross-browser wheel delta
				e = window.event || e; // old IE support
				var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail))); 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof callBackFn === 'function') 
				{ 
					callBackFn(delta, e); 
				} 
				
				/* we want to check to cancel default */ 
				if(typeof cancelDefault !== 'undefined' && cancelDefault == true) 
				{ 
					self.preventDefault(e); 
				} 
			}; 
			
			/* we need to check to add firefox support */ 
			if(obj.addEventListener) 
			{  
				this.events.add('DOMMouseScroll', obj, mouseWeelResults, capture, true, callBackFn); 
			} 
			 
			this.events.add('mousewheel', obj, mouseWeelResults, capture, true, callBackFn); 
			
			return this; 
		}, 
		
		/* this will prevent the default action 
		of an event 
		@param (object) e = the event object 
		@return (object) a reference to the base object */ 
		preventDefault: function(e) 
		{ 
			// cross-browser key result
			e = e || window.event; 
			
			if(typeof e.preventDefault !== 'undefined') 
			{ 
				e.preventDefault(); 
			} 
			else 
			{ 
				e.returnValue = false; 
			} 
			
			return this; 
		}, 
		
		/* this will cancel the propagation of an event.
		@param (object) e = the event object 
		@return (object) a reference to the base object */
		stopPropagation: function(e) 
		{ 
			// cross-browser key result
			e = e || window.event; 
		
			if(typeof e.stopPropagation !== 'undefined') 
			{ 
				e.stopPropagation();
			}
			else 
			{
				e.cancelBubble = true;
			} 
			
			return this; 
		}, 
		
		/* this will add onKeyUp event listener and return 
		standardized return of keycode then event. 
		@param (function) callBackFn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode 
		@return (object) a reference to the base object */  
		onKeyUp: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			/* we want to standardize the return */ 
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof callBackFn === 'function') 
				{ 
					callBackFn(e.keyCode, e); 
				} 
			};
			
			this.events.add('keyup', obj, keyCodeResults, capture, true, callBackFn); 
			
			return this; 
		}, 
		
		/* this will add onKeyDown event listener and return 
		standardized return of keycode then event. 
		@param (function) callBackFn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode 
		@return (object) a reference to the base object */
		onKeyDown: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof callBackFn === 'function') 
				{ 
					callBackFn(e.keyCode, e); 
				} 
			};
			
			this.events.add('keydown', obj, keyCodeResults, capture, true, callBackFn); 
			
			return this; 
		}, 
		
		/* this will add onKeyPress event listener and return 
		standardized return of keycode then event. 
		@param (function) callBackFn = the callback function 
		@param [(object)] obj = the object to bind the listener 
		@param [(bool)] capture = event capture mode */
		onKeyPress: function(callBackFn, obj, capture) 
		{ 
			if(typeof obj === "undefined") 
			{ 
				 obj = window; 
			} 
			
			var keyCodeResults = function(e) 
			{
				// cross-browser key result
				e = e || window.event; 
				
				/* we can now send the mouse wheel results to 
				the call back function */ 
				if(typeof callBackFn === 'function') 
				{ 
					callBackFn(e.keyCode, e); 
				} 
			};
			
			this.events.add('keypress', obj, keyCodeResults, capture, true, callBackFn); 
			
			return this; 
		},  
		
		/* this is an alias for getProperty. this will check to return 
		the property value from an object or return a default value or 
		return empty string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this 
		@return (string) the object property value */ 
		getValue: function(obj, property, defaultText) 
		{ 
			return this.getProperty(obj, property, defaultText);  
		},
		
		/* this will check to return the property value from an 
		object or return a default value or return empty 
		string. 
		@param (object) obj = the object to check for the value 
		@param (string) property = the property name to check return 
		@param [(string)] defaultText = if no property value is found 
		it will return this 
		@return (string) the object property value */ 
		getProperty: function(obj, property, defaultText) 
		{ 
			/* we need to check if the object is available */ 
			if(obj && typeof obj === 'object') 
			{ 
				/* check if the object property has a value */ 
				if(obj[property]) 
				{ 
					/* we want to return the value */ 
					return obj[property]; 
				} 
			} 
			
			/* if no value was available 
			we want to return an empty string */ 
			if(typeof defaultText !== 'undefined') 
			{ 
				return defaultText; 
			} 
			else 
			{ 
				return ''; 
			} 
		}, 
		
		/* this will get the offset position of an object. 
		@params object obj = the object that is requesting the offset 
		@return (object) a position object */
		getPosition: function(obj) 
		{ 
			var position = {x: 0, y: 0}; 
			
			if(obj && typeof obj === 'object') 
			{ 
				while(obj) 
				{ 
					position.x += (obj.offsetLeft + obj.clientLeft);
					position.y += (obj.offsetTop + obj.clientTop);
					obj = obj.offsetParent;
				} 
			} 
			return position; 
		}, 
		
		/* this will get the offset position of an objectin a parent. 
		@params object obj = the object that is requesting the offset 
		@return (object) a position object */
		position: function(obj) 
		{ 
			var position = {x: 0, y: 0}; 
			
			if(obj && typeof obj === 'object') 
			{ 
				position.x += (obj.offsetLeft - obj.scrollLeft + obj.clientLeft);
				position.y += (obj.offsetTop - obj.scrollTop + obj.clientTop); 
			} 
			return position; 
		},
		
		addClass: function(obj, tmpClassName) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
			var addClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				addClass = function(obj, tmpClassName) 
				{ 
					obj.classList.add(tmpClassName); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				addClass = function(obj, tmpClassName) 
				{ 
					obj.className = obj.className + ' ' + tmpClassName;   
				}; 
			} 
			
			/* we want to override parent method with new method to 
            cache the local function */ 
			var self = this; 
			this.addClass = function(obj, tmpClassName) 
			{ 
				if(obj && typeof obj === 'object' && tmpClassName != '') 
				{ 
					if(typeof tmpClassName === 'string') 
					{ 
						/* we want to divide the string by spaces and 
						add any class listed */ 
						var adding = tmpClassName.split(' ');   
						for(var i = 0, maxLength = adding.length; i < maxLength; i++) 
						{ 
							self.addClass(obj, adding[i]);  
						} 
					} 
				} 
				return self; 
			}; 
			
			/* we need to manually initialize the first time */ 
			return this.addClass(obj, tmpClassName); 
		}, 
		
		removeClass: function(obj, tmpClassName) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var removeClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				removeClass = function(obj, tmpClassName) 
				{ 
					obj.classList.remove(tmpClassName); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				removeClass = function(obj, tmpClassName) 
				{ 
					/* we want to get the object classes in an array */ 
					var classNames = obj.className.split(' ');  
					
					for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
					{ 
						/* if the class matches the tmpClassName we want to remove it */ 
						if(classNames[i] === tmpClassName) 
						{ 
							classNames.splice(i, 1);  
						}
					}
				
					obj.className = classNames.join(' '); 
				}; 
			} 
			
			var self = this; 
			this.removeClass = function(obj, tmpClassName) 
			{ 
				if(obj && typeof obj === 'object' && tmpClassName != '') 
				{ 
					/* if no className was specified we will remove all classes from object */ 
					if(typeof tmpClassName === 'undefined') 
					{ 
						obj.className = ''; 
					} 
					else 
					{ 
						try{
							removeClass(obj, tmpClassName); 
						} 
						catch(e) 
						{ 
							/* we want to save the error */ 
							self.addError(e);  
						} 
					}
				} 
				return self; 
			}; 
			
			return this.removeClass(obj, tmpClassName); 
		}, 
		
		removeClasses: function(obj, classNameString) 
		{ 
			if(obj && typeof obj === 'object' && typeof classNameString != '') 
			{ 
				if(classNameString) 
				{ 
					var removing = classNameString.split(' ');   
					
					for(var i = 0, maxLength = removing.length; i < maxLength; i++) 
					{ 
						this.removeClass(obj, removing[i]);  
					} 
				} 
			} 
			return this; 
		}, 
		
		hasClass: function(obj, tmpClassName) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var hasClass;  
			if(typeof document.documentElement.classList !== 'undefined') 
			{ 
				// modern browsers 
				hasClass = function(obj, tmpClassName) 
				{ 
					return obj.classList.contains(tmpClassName); 
				};
			} 
			else 
			{ 
				// old browsers 
				hasClass = function(obj, tmpClassName) 
				{ 
					/* we want to get the object classes in an array */ 
					var check = false, 
					classNames = obj.className.split(' ');  
					
					for(var i = 0, maxLength = classNames.length; i < maxLength; i++) 
					{ 
						/* if the class matches the tmpClassName we want to remove it */ 
						if(classNames[i] === tmpClassName) 
						{ 
							check = true;
							break;    
						}
					} 
					return check; 
				};
			}  
			 
			var self = this; 
			this.hasClass = function(obj, tmpClassName) 
			{ 
				var check = false; 
				if(obj && typeof obj === 'object' && tmpClassName != '') 
				{ 
					try{
						check = hasClass(obj, tmpClassName); 
					} 
					catch(e) 
					{ 
						/* we want to save the error */ 
						self.addError(e); 
					}
				} 
				return check; 
			}; 
			
			return this.hasClass(obj, tmpClassName); 
		}, 
		
		/* this will toggle a class on an element. if the element 
		has the class it will be removed if not added. 
		@param (object) obj = the element object 
		@param (string) tmpClassName = the class name 
		@return (object) the base object to allow chaining */ 
		toggleClass: function(obj, tmpClassName) 
		{ 
			if(typeof obj === 'object') 
			{ 
				var hasClass = this.hasClass(obj, tmpClassName); 
				if(hasClass === true) 
				{ 
					this.removeClass(obj, tmpClassName); 
				} 
				else 
				{ 
					this.addClass(obj, tmpClassName); 
				}
			} 
			
			return this; 
		}, 
		
		/* this will get the type of var. 
		@param (mixed) data = the data to check 
		@return (string) the type */ 
		getType: function(data) 
		{ 
			var type = typeof data; 
			if(type === 'object') 
			{ 
				var isArray = this.isArray(data); 
				if(isArray === true) 
				{ 
					type = 'array'; 
				} 
			} 
			return type; 
		}, 
		
		/* this will check if an object is an array. 
		@param (mixed) array = the array to check  
		@return (bool) true or false if array is an array */ 
		isArray: function(array) 
		{ 
            /* create a local function to perform the check once */ 
            var isArray;  
            if(typeof Array.isArray === 'function') 
            { 
                // modern browsers 
                isArray = function(array) 
                { 
                    return Array.isArray(array); 
                }; 
            } 
            else 
            { 
                // old browsers 
                isArray = function(array) 
                { 
                    if(array instanceof Array) 
                    { 
                        return true; 
                    } 
                    return false;  
                }; 
            }  
            
            /* we want to override parent method with new method to 
            save the local function */ 
            this.isArray = function(array) 
            { 
            	return isArray(array); 
            }; 
            
            /* we need to manually initialize the first time */ 
            return this.isArray(array); 
		}, 
		
		/* this will search an array and return the index number of an array 
		or a -1 if the element is not found. 
		@param (array) array = the array to search 
		@param (mixed) element = the element to search in the array 
		@param [(int)] fromIndex = the index number to start searching from 
		@return (int) the index position or -1 if not found */ 
		inArray: function(array, element, fromIndex) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var inArray;  
			if(typeof Array.prototype.indexOf === 'function') 
			{ 
				// modern browsers 
				inArray = function(array, element, fromIndex) 
				{ 
					return array.indexOf(element, fromIndex); 
				}; 
			} 
			else 
			{ 
				// old browsers
				inArray = function(array, element, fromIndex) 
				{ 
					var length = (array.length);  
					var start = (!isNaN(fromIndex))? fromIndex : 0; 
					
					for(var i = start; i < length; i++) 
					{ 
						if(element === array[i]) 
						{ 
							return i; 
						} 
					}  
					return -1; 
				}; 
			} 
			
			/* we want to override parent method with new method to 
            save the local function */
			this.inArray = function(array, element, fromIndex) 
			{ 
				if(array && typeof array === 'object') 
				{ 
					var index = inArray(array, element, fromIndex); 
					return index; 
				} 
				
				return -1; 
			}; 
			
			/* we want to return the result for the first call */ 
            return this.inArray(array, element, fromIndex);
		}, 
		
		/* this will extend an object and return the extedned 
		object or false.  
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		extendObject: function(sourceObj, targetObj) 
		{ 
			if(typeof sourceObj === 'object' && typeof targetObj === 'object') 
			{ 
				for(var property in sourceObj) 
				{ 
					if(sourceObj.hasOwnProperty(property) && typeof targetObj[property] === 'undefined') 
					{ 
						targetObj[property] = sourceObj[property]; 
					} 
				} 
				
				return targetObj; 
			} 
			return false; 
		}, 
		
		/* this will compare two values or objects 
		and return true or false if they match. 
		@param (mixed) option1 = the first option to compare 
		@param (mixed) option2 = the second option to compare 
		@return (bool) true or false if equal */ 
		equals: function(option1, option2) 
		{ 
			/* this will count object properties and compare values */ 
			var propertyCountAndCompare = function(obj1, obj2) 
			{ 
				var same = true; 
				
				/* this will count the properties of an object 
				and any child object properties */ 
				var countProperty = function(obj) 
				{ 
					var count = 0; 
					/* we want to count each property of the object */ 
					for(var property in obj) 
					{ 
						if(obj.hasOwnProperty(property)) 
						{ 
							count++;  
							/* we want to do a recursive count to get 
							any child properties */ 
							if(typeof obj[property] === 'object') 
							{ 
								count += countProperty(obj[property]); 
							}								
						} 
					} 
					return count; 
				}; 
				
				var matchProperties = function(obj1, obj2) 
				{ 
					var matched = true; 
					
					if(typeof obj1 === 'object' && typeof obj2 === 'object') 
					{ 
						/* we want to check each object1 property to the 
						object 2 property */ 
						for(var property in obj1) 
						{ 
							/* we want to check if the property is owned by the 
							object andthat they have matching types */ 
							if(obj1.hasOwnProperty(property) && obj2.hasOwnProperty(property) && typeof obj1[property] === typeof obj2[property]) 
							{ 
								/* we want to check if the type is an object */ 
								if(typeof obj1[property] === 'object') 
								{ 
									/* this will do a recursive check to the 
									child properties */ 
									matched = matchProperties(obj1[property], obj2[property]); 
									
									/* if a property did not match we can stop 
									the camparison */ 
									if(matched === false) 
									{ 
										break; 
									}
								} 
								else 
								{ 
									if(obj1[property] !== obj2[property]) 
									{ 
										matched = false; 
										break;
									}
								}
							} 
							else 
							{ 
								matched = false; 
								break; 
							}
						} 
					} 
					else 
					{ 
						matched = false; 
					} 
					
					return matched; 
				};  
				
				/* we want to check if they have the same number of 
				properties */ 
				var option1Count = countProperty(obj1), 
				option2Count = countProperty(obj2); 
				
				if(option1Count === option2Count) 
				{ 	
					/* we want to check if the properties match */ 
					var result = matchProperties(obj1, obj2); 
					if(result === false) 
					{ 
						same = false; 
					}
				} 
				else 
				{ 
					same = false; 
				} 
				
				return same; 
			}; 
			
			var same = true; 
			
			/* we want to check if there types match */ 
			if(typeof option1 === typeof option2) 
			{ 
				/* we need to check if the options are objects 
				because we will want to match all the 
				properties */ 
				if(typeof option1 === 'object' && typeof option2 === 'object') 
				{ 
					var matchResult = propertyCountAndCompare(option1, option2); 
					if(matchResult === false) 
					{ 
						same = false; 
					}
				}
				else 
				{ 
					if(option1 !== option2) 
					{ 
						same = false; 
					} 
				}
			} 
			else 
			{ 
				same = false; 
			} 
			
			return same; 
		}, 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (mixed) sourceClass = the original (class function 
		constructor or class prototype) unextended 
		@param (mixed) addingClass = the (class function constructor
		or class prototype) to add to the original */ 
		extendClass: function(sourceClass, targetClass) 
		{ 
			/* if we are using a class constructor function 
			we want to get the class prototype object */  
			var source = (typeof sourceClass === 'function')? sourceClass.prototype : sourceClass, 
			target = (typeof targetClass === 'function')? targetClass.prototype : targetClass;			
			
			if(typeof source === 'object' && typeof target === 'object') 
			{ 
				/* we want to create a new object and add the source 
				prototype to the new object */ 
				var obj = this.createObject(source); 
				
				/* we need to add any settings from the source that 
				are not on the prototype */ 
				this.extendObject(source, obj); 
				
				/* we want to add any additional properties from the 
				target class to the new object */ 
				for(var prop in target) 
				{ 
					obj[prop] = target[prop]; 
				} 
				
				return obj; 
			} 
			return false; 
		}, 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		extendObj: function(source, target) 
		{ 
			if(source && typeof source === 'object' && target && typeof target === 'object') 
			{ 
				target.parent = source; 
				for(var prop in source) 
				{ 
					if(typeof target[prop] === 'undefined') 
					{ 
						target[prop] = source[prop]; 
					}
				} 
				return target; 
			} 
			return false; 
		}, 
		
		/* this will extend an object by creating a clone object and 
		returning the new object with the added object or false. 
		@param (object) sourceObj = the original object 
		@param (object) targetObj = the target object */ 
		extendPrototype: function(source, target) 
		{ 
			target.prototype = new source(); 
			target.prototype.parent = source; 
			target.prototype.constructor = target;  
			
			return target; 
		},
		
		/* this will return a new object and extend it if an object it supplied. 
		@param [(object)] object = the extending object 
		@return (object) this will return a new object with the 
		inherited object */ 
		createObject: function(object) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var createObject;  
			if(typeof Object.create !== 'function') 
			{ 
				// modern browsers 
				createObject = function(object) 
				{ 
					return Object.create(object); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				createObject = function(object) 
				{ 
					var obj = function(){}; 
					obj.prototype = object;
					return new obj();   
				}; 
			} 
			
			this.createObject = function(object) 
			{ 
				return createObject(object); 
			}; 
			
			return this.createObject(object); 
		}, 
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind 
		@return a bound method or false on error */ 
		createCallBack: function(obj, method, argArray) 
		{ 
			if(typeof method === 'function') 
			{ 
				return function() 
				{ 
					return method.apply(obj, argArray); 
				}; 
			} 
			else 
			{ 
				return false; 
			}
		}, 
		
		/* this will bind the method to an object to return 
		the bound method. 
		@param (object) obj = the object to bind the method 
		@param (function) method = the method to bind */ 
		bind: function(obj, method) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var bind;  
			if(typeof Function.prototype.bind === 'function') 
			{ 
				// modern browsers 
				bind = function(obj, method) 
				{ 
					return method.bind(obj); 
				}; 
			} 
			else 
			{ 
				// old browsers 
				bind = function(obj, method) 
				{ 
					return function() 
					{ 
						return method.apply(obj, arguments); 
					};   
				}; 
			} 
			
			/* we want to override parent method with new method to 
            cache the local function */
			this.bind = function() 
			{ 
				return bind(obj, method); 
			}; 
			
			/* we want to return the result for the first call */ 
            return this.bind(obj, method);
		}, 
		
		/* this will prepare a json object to be used in an 
		xhr request to sanitize the uri compontents and json 
		encode the object.  
		@param (object) obj = the object json encode 
		@return (mixed) a json string or false */
		prepareJsonUrl: function(obj) 
		{ 
			var escapeChars = function(str) 
			{ 
				if(typeof str !== 'string') 
				{ 
					str = String(str); 
				} 
				
				var newLine = /\n/g, 
				returnCarriage = /\r/g, 
				tab = /\t/g; 
				
				return str.replace(newLine, "\\n").replace(returnCarriage, "\\r").replace(tab, "\\t");   
			}; 
			
			var sanitize = function(text) 
			{ 
				/* we needto escape chars and encode the uri 
				components */ 
				text = escapeChars(text); 
				text = encodeURIComponent(text); 
				
				/* we want to re-encode the double quotes so they 
				will be escaped by the json encoder */ 
				var pattern = /\%22/g; 
				return text.replace(pattern, '"');  
			}; 
			
			var prepareUrl = function(data) 
			{ 
				var type = typeof data; 
				if(type !== "undefined") 
				{
					if(type === 'object') 
					{ 
						for(var prop in data) 
						{ 
							if(data.hasOwnProperty(prop) && data[prop] !== null) 
							{ 
								var childType = typeof data[prop]; 
								if(childType) 
								{ 
									data[prop] = prepareUrl(data[prop]); 
								} 
								else 
								{ 
									data[prop] = sanitize(data[prop]); 
								} 
							}
						} 
					} 
					else 
					{ 
						data = sanitize(data); 
					} 
				} 
				return data; 
			}; 
			
			obj = prepareUrl(obj); 
			
			return this.jsonEncode(obj); 
		}, 
		
		/* this will decode a json string. 
		@param (string) data = a json encoded string */ 
		jsonDecode: function(data) 
		{ 
			if(typeof data !== "undefined" && data.length > 0) 
			{ 
				try{ 
				
					return JSON.parse(data); 
				} 
				catch(e) 
				{ 
					return data; 
				} 
			} 
			return false; 
		}, 
		
		/* this will encode an object or array of objects. 
		@param (string) data = an object or array of objects */
		jsonEncode: function(data) 
		{ 
			if(typeof data !== "undefined") 
			{ 
				try{
					return JSON.stringify(data); 
				} 
				catch(e) 
				{ 
					return false; 
				}
			} 
			return false; 
		}, 
		
		/* this will parse an xml string. 
		@param (string) data = an xml string */
		xmlParse: function(data) 
		{ 
			/* create a local function to perform the check 
			once then override the function */ 
            var xmlParse;  
			if(typeof window.DOMParser !== 'undefined') 
			{ 
				// modern browsers 
				xmlParse = function(data) 
				{ 
					var parser = new DOMParser(); 
					return parser.parseFromString(data, "text/xml"); 
				}; 
			} 
			else 
			{ 
				// old browsers
				xmlParse = function(data) 
				{ 
					var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
					xmlDoc.async = false;
					return xmlDoc.loadXML(data); 
				}; 
			} 
			
			/* we want to override parent method with new method to 
            cache the local function */ 
			this.xmlParse = function(data) 
			{ 
				if(typeof data !== "undefined") 
				{ 
					return xmlParse(data);  
				} 
				else 
				{ 
					return false; 
				} 
			}; 
			
			/* we want to return the result for the first call */ 
            return this.xmlParse(data);
		} 

	};  
	
	/* this will create an auto initializing function to return 
	the base framework prototype to allow new modules to be 
	added */ 
	base.prototype.extend = (function()
	{
		return base.prototype; 
	})();
	
	  
	/* we want to check if the framework 
	has not already been setup */ 
	if(!(global.base)) 
	{ 
		/* we need to create a new instance of the base framework, 
		save it to the global object, and return it to the 
		autointializing function */ 
		var bse = new base(); 
		/* shorthand and long name */  
		global._b = global.base = bse; 
		return global.base; 
	} 
	else 
	{ 
		/* return the previous setup without create a new 
		instance */ 
		return global.base; 
	}  
	
})(this);  

/* base framework module */ 
/* 
	this adds ajax support to the base framwork  
*/ 
(function() 
{
	"use strict"; 
	
	/* this will add (ajax) xhr requests to the base framework */ 
	
	/* default settings */ 
	var defaultSettings = 
	{ 
		/* this is the xhr url to connect to */ 
		url: '',       
		
		/* this is the datatype of the server 
		response (string) */ 
		dataType:  'json', 
		
		/* this is the server action type (string) */ 
		type: 'POST', 
		
		/* headers (object) */ 
		headers: 
		{ 
			'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' 
		}, 
		
		/* this will set the ajax request to async (bool) */ 
		async: true, 
		
		/* cross domain (bool) */ 
		crossDomain: false, 
		
		/* cors with credentials (bool) */ 
		withCredentials: false,
		
		/* events (function) */ 
		completed: null, 
		failed: null, 
		aborted: null, 
		progress: null 
	}; 
	
	/* this will set the deafult ajax params to the 
	base object so they can be modified */ 
	base.extend.xhrSettings =  defaultSettings; 
	
	/* this will allow the ajax settings to be updated */ 
	base.extend.ajaxSettings = function(settingsObj) 
	{ 
		if(typeof settingsObj === 'object') 
		{ 
			base.xhrSettings = base.extendClass(base.xhrSettings, settingsObj); 
		}
	}; 
	
	/* this will reset the ajax settings */ 
	base.extend.resetAjaxSettings = function() 
	{ 
		base.xhrSettings = defaultSettings; 
	}; 
	
	/* this will send an ajax request and return 
	the xhr object */ 
	/* 
		the params can either be individual params or a settings object 
		
		individual param: 
		@param (string) url = the url to connect to  
		@param (string) params = the xhr params  
		@param (function) callBackFn = the ajax callback function 
		@param [(dataType)] dataType = the data type of xhr response 
		@param [(type)] dataType = the send type to the server
		(json/xml/text) 
		@param [(bool)] async = this will enable or disable async
		
		settings object: 
		-url (string): the ajax file url 
		-params (string): the ajax param string 
		-type (string): the server request type 
		-dataType (string): the type of data to return (text, html, json) 
		if the dataType is json or xml the return text will be parsed 
		before it is return to the callback function 
		-async (bool): default is set to async 
		-headers (object): the headers to use 
		-crossDomain (bool): set true if performings cors 
		-withCredentials (bool): with credentials for cors
		-completed (function): the function to perform 
		when completed 
		-failed (function): the function to perform 
		if failed 
		-progress (function): the function to perform 
		during progress 
		-aborted (function): the function to perform 
		if aborted
		
	*/ 
	base.extend.ajax = function()
	{ 
		/* we want to save the args so we can check 
		which way we are adding the ajax settings */ 
		var args = base.listToArray(arguments); 
		
		/* we want to create a new ajax request */ 
		var ajax = new ajaxRquest(args);   
		ajax.setup();  
		
		/* we want to return the xhr object */ 
		return ajax.xhr;
		
	}; 
	
	/* this will create an xhr request and perform all 
	the steps to setup and return the response */ 
	var ajaxRquest = function(args) 
	{ 
		/* this will be the xhr object */ 
		this.xhr = null; 
		
		/* this will be the ajax request settings */ 
		this.settings = null; 
		
		/* this is the ajax args */ 
		this.args = args;  
	}; 
		
	ajaxRquest.prototype = 
	{ 
		constructor: ajaxRquest, 
		
		/* this will setup a new xhr request and send it. if it 
		can setup it will return true else false */ 
		setup: function() 
		{ 
			/* we want to setup the ajax settings */ 
			this.getXhrSettings();  
			
			/* create a new xhr object */ 
			this.xhr = this.createXHR(); 
			if(this.xhr !== false) 
			{ 
				/* setup request */ 
				this.xhr.open(this.settings.type, this.settings.url, this.settings.async); 
				/* we want to add the xhr headers */ 
				this.setupHeaders(); 
				/* we want to add the events */ 
				this.addXhrEvents(); 
	 
				this.xhr.send(this.settings.params); 
				
				return true; 
			} 
			else 
			{ 
				return false; 
			}
		},  
		
		/* this will setup the request settings from the default 
		xhr settings and any settings being updated from the 
		ajax args */ 
		getXhrSettings: function() 
		{ 
			var args = this.args; 
			
			/* we want to create a clone of the default 
			settings before adding the new settings */ 
			this.settings = base.createObject(base.xhrSettings);  
			
			/* we want to check if we are adding the ajax settings by 
			individual args or by a settings object */ 
			if(args.length >= 2 && typeof args[0] !== 'object') 
			{ 
				/* we want to add each arg as one of the ajax 
				settings */ 
				for(var i = 0, maxLength = args.length; i < maxLength; i++) 
				{ 
					var arg = args[i]; 
					
					switch(i) 
					{ 
						case 0: 
							this.settings.url = arg; 
							break; 
						case 1: 
							this.settings.params = arg; 
							break; 
						case 2: 
							this.settings.completed = arg; 
							this.settings.failed = arg;
							break; 
						case 3: 
							this.settings.dataType = arg || 'json'; 
							break; 
						case 4: 
							this.settings.type = (arg)? arg.toUpperCase() : 'POST'; 
							break; 
						case 5: 
							this.settings.async = (typeof arg !== 'undefined')? arg : true; 
							break; 
					} 
				} 
			}
			else 
			{ 
				/* override the default settings with the args 
				settings object */ 
				var settings = this.settings = base.extendClass(this.settings, args[0]); 
				
				/* we want to check to add the completed callback 
				as the error and aborted if not set */ 
				if(typeof settings.completed === 'function') 
				{ 
					if(typeof settings.failed !== 'function') 
					{ 
						settings.failed = settings.completed; 
					} 
					
					if(typeof settings.aborted !== 'function') 
					{ 
						settings.aborted = settings.failed; 
					} 
				} 
			} 
		}, 
		
		/* this will create and return an xhr object or return 
		false if not able. 
		@return (mixed) the xhr object or false */ 
		createXHR: function() 
		{ 
			/* this will return a standard xhr object */ 
			var createXHRObj = function() 
			{ 
				var xhr = false; 
				
				/* we want to check to add standard xhr request 
				else check to add older ie activex object */ 
				if(typeof XMLHttpRequest !== "undefined") 
				{ 
					xhr = new XMLHttpRequest(); 
				} 
				else 
				{ 
					try{ 
						xhr = new ActiveXObject("Msxml2.XMLHTTP"); 
					} 
					catch(e) 
					{ 
						try{ 
							xhr = new ActiveXObject("Microsoft.XMLHTTP"); 
						} 
						catch(err) 
						{ 
							 
						} 
					} 
				} 
				
				return xhr; 
			}; 
			
			/* this will create and return a cors xhr object */ 
			var createCorsXHRObj = function() 
			{ 
				var xhr = false; 
				
				/* we want to check if xmlHttpReqeust is level 2 */
				if(typeof XMLHttpRequest !== "undefined" && typeof XDomainRequest === "undefined") 
				{ 
					xhr = new XMLHttpRequest();  
				} 
				else if(typeof XDomainRequest !== "undefined") 
				{ 
					xhr = new XDomainRequest(); 
				} 
				
				if(xhr && this.settings.withCredentials == true) 
				{ 
					try{ 
						xhr.withCredentials = true; 
					} 
					catch(e) 
					{ 
						
					}
				}
				
				return xhr; 
			}; 
			
			/* we want to check to setup the xhr by 
			the crossDomain settings */ 
			var xhr = (this.settings && this.settings.crossDomain == true)? createCorsXHRObj(): createXHRObj();  
			
			/* we want to return the new xhr object or 
			false if not created */ 
			return (xhr)? xhr : false;  
		}, 
		
		/* this will setup the xhr headers */ 
		setupHeaders: function() 
		{ 
			if(this.settings && typeof this.settings.headers === 'object') 
			{ 
				/* we want to add a header for each 
				property in the object */ 
				for(var header in this.settings.headers) 
				{ 
					this.xhr.setRequestHeader(header, this.settings.headers[header]); 
				} 
			} 
		}, 
		
		/* this will get the server response and check the 
		ready state and status to return response to 
		request call back function 
		@param (object) e = the event object 
		@param [(string)] overrideType = the type of event that 
		is overriding the default event type. this is used with the older 
		style callback for older browsers */ 
		update: function(e, overrideType) 
		{ 
			e = e || window.event; 
			
			var type = (overrideType)? overrideType : e.type, 
			settings = this.settings; 
			if(settings) 
			{ 
				switch(type) 
				{ 
					case 'load':  
						if(typeof settings.completed === 'function') 
						{ 
							var response = this.getResponseData();  
							settings.completed(response, this.xhr); 
						} 
						break; 
					case 'error':  
						if(typeof settings.failed === 'function') 
						{ 
							settings.failed(false, this.xhr); 
						} 
						break; 
					case 'progress':  
						if(typeof settings.progress === 'function') 
						{  
							settings.progress(e); 
						} 
						break; 
					case 'abort':  
						if(typeof settings.aborted === 'function') 
						{  
							settings.aborted(false, this.xhr); 
						} 
						break; 
				} 
			} 
		}, 
		
		/* this will get the response data and check to decode the data type 
		if required. 
		@return (mixed) the response data */ 
		getResponseData: function() 
		{ 
			var response = this.xhr.responseText; 
				
			/* we want to check to decode the xhr response 
			if we have a response */ 
			if(typeof response === 'string') 
			{ 
				var encoded = false; 
				/* we want to check to decode the response by the type */ 
				switch(this.settings.dataType.toLowerCase()) 
				{ 
					case 'json': 
						
						encoded = base.jsonDecode(response); 
						if(encoded !== false) 
						{ 
							response = encoded; 
						} 
						else 
						{ 
							response = response; 
							this.error = 'yes'; 
						}
						break; 
					case 'xml': 
						encoded = base.xmlParse(response); 
						if(encoded !== false) 
						{ 
							response = encoded; 
						} 
						else 
						{ 
							response = response; 
							this.error = 'yes'; 
						} 
						break; 
					case 'text': 
						break;
						  
				} 
			} 
			
			return response; 
		}, 
		
		checkReadyState: function(e) 
		{ 
			e = e || window.event; 
			
			/* check the response state */
			if(this.xhr.readyState != 4)
			{ 
				/* the response is not ready */ 
				return; 
			} 
			
			/* check the response status */ 
			if(this.xhr.status == 200) 
			{ 
				 /* the ajax was successful 
				 but we want to change the event type to load */ 
				 var type = 'load';  
				 this.update(e, type); 
			} 
			else 
			{ 
				/* there was an error */ 
				var type = 'error'; 
				this.update(e, type); 					 
			} 
		}, 
		
		/* this will add the event listeners to the xhr object. */ 
		addXhrEvents: function() 
		{ 
			var settings = this.settings; 
			if(settings) 
			{ 
				/* we need to check if we can add new event listeners or 
				if we have to use the old ready state */ 
				if(typeof this.xhr.onload !== 'undefined') 
				{ 
					base.addListener('load', this.xhr, base.bind(this, this.update)); 
					base.addListener('error', this.xhr, base.bind(this, this.update)); 
					base.addListener('progress', this.xhr.upload, base.bind(this, this.update)); 
					base.addListener('abort', this.xhr, base.bind(this, this.update)); 
				} 
				else 
				{ 
					var self = this;
					this.xhr.onreadystatechange = function(e){ self.checkReadyState(e); }; 
				}
			} 
		}  
	}; 
})(); 

/* base framework module */ 
/* 
	this will create dynamic html to be 
	added and modified  
*/ 
(function() 
{
	"use strict"; 
	
	/* this will add a new html builder object that 
	can be extended to the object that you want to 
	build with */  
	base.extend.htmlBuilder = function()
	{ 
	
	}; 
	
	/* we want to save the methods to the prototype 
	to allow inheritance */ 
	base.htmlBuilder.prototype = 
	{ 
		/* this will create an html element by nodeType, add to 
		the specified parent container and return the new 
		element. 
		@param (string) nodeType = the element node type name
		@param (object) attrObject = the node attributes to add 
		to the element. 
		@param (mixed) container = the parent container element 
		or id 
		@param (bool) prepend = this will add the element 
		to the begining of theparent */
		create: function(nodeName, attrObject, container, prepend)
		{ 
			var filterProperty = function(prop) 
			{ 
				switch(prop) 
				{ 
					case 'class': 
						prop = 'className'; 
						break; 
					case 'for': 
						prop = 'htmlFor'; 
						break; 
					case 'readonly': 
						prop = 'readOnly'; 
						break; 
					case 'maxlength': 
						prop = 'maxLength'; 
						break; 
					case 'cellspacing': 
						prop = 'cellSpacing'; 
						break; 
					case 'rowspan': 
						prop = 'rowSpan'; 
						break; 
					case 'colspan': 
						prop = 'colSpan'; 
						break; 
					case 'tabindex': 
						prop = 'tabIndex'; 
						break; 
					case 'cellpadding': 
						prop = 'cellPadding'; 
						break; 
					case 'usemap': 
						prop = 'useMap'; 
						break; 
					case 'frameborder': 
						prop = 'frameBorder'; 
						break; 
					case 'contenteditable': 
						prop = 'contentEditable'; 
						break;
				} 
				
				return prop; 
			}; 
			
			/* this will return the property without the on prefix */ 
			var removePrefix = function(prop) 
			{ 
				if(typeof prop !== 'undefined') 
				{ 
					if(prop.substring(0, 2) === 'on') 
					{ 
						prop = prop.substring(2);   
					}  
				} 
				return prop; 
			};
			
			//object  
			var obj = document.createElement(nodeName);
			
			/* we want to check if we have attrributes to add */ 
			if(attrObject && typeof attrObject === 'object') 
			{ 
				/* we need to add the type if set to stop ie 
				from removing the value if set after the value is 
				added */ 
				if(typeof attrObject.type !== 'undefined') 
				{ 
					obj.type = attrObject.type; 
				} 
				
				/* we want to add each attr to the obj */ 
				for(var prop in attrObject) 
				{   
					var propName = filterProperty(prop); 
					
					/* we have already added the type so we need to 
					skip if the prop is type */ 
					if(prop === 'type') 
					{ 
						continue; 
					}
					
					/* we want to check to add the attr settings
					 by property name */  
					if(prop === 'innerHTML') 
					{ 
						/* we need to check if we are adding inner 
						html content */
						obj.innerHTML = attrObject[prop]; 
					} 
					else if(prop.substring(0, 5) === 'data-') 
					{ 
						base.data(obj, prop, attrObject[prop]); 
					}
					else 
					{ 
						/* we want to add the new attr as a named array 
						because this allows dynamic event attr and 
						normal attr */ 
						if(typeof attrObject[prop] !== 'undefined' && attrObject[prop] != '') 
						{ 
							/* we want to check to add a value or amn event listener */ 
							if(typeof attrObject[prop] === 'function') 
							{ 
								propName = removePrefix(propName); 
								base.addListener(propName, obj, attrObject[prop]); 
							} 
							else 
							{ 
								obj[propName] = attrObject[prop];
							}
						}
					}
				}
			}
			
			try
			{ 
				/* we want to check if the new element should be 
				added to the begining or end */ 
				if(prepend == true) 
				{ 
					this.prepend(container, obj); 
				} 
				else 
				{ 
					this.append(container, obj); 
				} 
			} 
			catch(e) 
			{ 
				this.error(e, obj); 
			} 
			
			return obj;  
		
		}, 
		
		/* this will create a document fragment to allow elements 
		to be added to a container element without rendering until the 
		fragment gets appended to an element. 
		@return (object) the document fragment */ 
		createDocFragment: function() 
		{ 
			return document.createDocumentFragment();  
		}, 
		
		/* this will create an html element and return the new object 
		@param (string) nodeName = the new element node Name or tag name 
		@param (string) id = the node id 
		@param (string) className = the element className 
		@param (string) html = the element innerHTML content
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */
		addElement: function(nodeName, id, className, html, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			return this.create(nodeName, attr, container, prepend);    
		}, 
		
		/* this will create an html element and add an onclick to the 
		callback function and return the new object 
		@param (string) nodeName = the new element node Name or tag name 
		@param (string) id = the node id 
		@param (string) className = the element className 
		@param (string) html = the element innerHTML content 
		@param (function) callBackFn = the callback function
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addButton: function(nodeName, id, className, html, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			
			if(nodeName === 'button') 
			{ 
				/* this will stop the form from being submitted by default 
				when the button is clicked */ 
				attr.type = 'button'; 
			}
			
			if(typeof callBackFn === 'function') 
			{ 
				attr.onclick = callBackFn; 
			}
			
			return this.create(nodeName, attr, container, prepend);  
		}, 
		
		/* this will create a checkbox return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (function) callBackFn = the callback function 
		@param (bool) checked = when true the element will be checked
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */
		addCheckbox: function(id, className, callBackFn, checked, container, stopPropagation)
		{ 
			var attr = { id: id, 'className': className, type: 'checkbox' };  
			
			if(typeof stopPropagation !== 'undefined' && stopPropagation == true) 
			{ 
				attr.onclick = base.stopPropagation; 
			} 
			
			if(typeof callBackFn === 'function') 
			{ 
				attr.onchange = callBackFn; 
			}
			
			if(checked == true) 
			{ 
				attr.checked = true; 
			} 
			
			return this.create('input', attr, container);   
		},  
		
		/* this will create a radio return the new object  
		@param (string) id = the node id 
		@param (string) name = the name
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (bool) checked = when true the element will be checked
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addRadio: function(id, name, className, value, callBackFn, checked, container, stopPropagation)
		{ 
			var attr = { id: id, name: name, 'className': className, value: value, type: 'radio' };  
			
			if(typeof stopPropagation !== 'undefined' && stopPropagation == true) 
			{ 
				attr.onclick = base.stopPropagation; 
			} 
			
			if(typeof callBackFn === 'function') 
			{ 
				attr.onchange = callBackFn; 
			}
			
			if(checked == true) 
			{ 
				attr.checked = true; 
			}
			
			return this.create('input', attr, container);   
		}, 
		
		/* this will create an input and return the new object  
		@param (string) inputType = the input type
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (string) placeholder = the input placeholder
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addInput: function(inputType, id, className, value, callBackFn, placeholder, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value, type: inputType };  
			
			attr.onfocus = focusElement;
			
			if(typeof callBackFn === 'function') 
			{ 
				var callBack = base.createCallBack(null, callBackFn, [this.value]);
				attr.onkeyup = callBack; 
			} 
			
			if(placeholder) 
			{ 
				attr.placeholder = placeholder; 
			}
			
			return this.create('input', attr, container, prepend); 
		}, 
		
		/* this will create a textarea and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addTextarea: function(id, className, value, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value };  
			
			attr.onfocus = focusElement;
			
			if(typeof callBackFn === 'function') 
			{ 
				attr.onblur = callBackFn; 
				attr.onkeyup = callBackFn; 
			} 
			
			return this.create('textarea', attr, container, prepend);  
		}, 
		
		/* this will create a select and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) value = the element value
		@param (function) callBackFn = the callback function 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addSelect: function(id, className, value, callBackFn, container, prepend)
		{ 
			var attr = { id: id, 'className': className, value: value };  
			
			if(typeof callBackFn === 'function') 
			{ 
				var callBack = function(){ callBackFn.call(null, this.value); attr = null; container = null; }; 
				attr.onchange = callBack;  
			} 
			
			return this.create('select', attr, container, prepend);  
		}, 
		
		/* this will add options to a select   
		@param (mixed) selectElem = the select element or id  
		@param (array) optionArray = and array with objects 
		to use as options 
		@param [(string)] defaultValue = the select default 
		value */ 
		setupSelectOptions: function(selectElem, optionArray, defaultValue) 
		{ 
			if(selectElem !== null) 
			{ 
				/* if the select id was sent we need to get 
				the element */ 
				if(typeof selectElem !== 'object') 
				{ 
					selectElem = document.getElementById(selectElem);   
				}
						
				/* we need to check if we have any options to add */ 
				if(optionArray && optionArray.length) 
				{ 			
					/* create each option then add it to the select */   
					for(var n = 0, maxLength = optionArray.length; n < maxLength; n++) 
					{ 
						var option = selectElem.options[n] = new Option(optionArray[n].label, optionArray[n].value); 
						
						/* we can select an option if a default value 
						has been sumbitted */ 
						if(defaultValue !== null) 
						{ 
							if(option.value == defaultValue) 
							{ 
								option.selected = true;   
							} 
						} 
					} 
				}
			} 
		}, 
		
		/* this will create an image and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) src = the image src 
		@param (string) alt = the image alt 
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addImage: function(id, className, src, alt, container, prepend)
		{ 
			var attr = { id: id, 'className': className };  
			
			if(typeof alt !== 'undefined') 
			{ 
				attr.alt = alt; 
			} 
			
			if(typeof src !== 'undefined') 
			{ 
				attr.src = src; 
			} 
			
			return this.create('img', attr, container, prepend);    
		}, 
		 
		addForm: function(id, action, method, autocomplete, novalidate, enctype, target, container, prepend)
		{ 
			var attr = { id: id };  
			
			if(typeof method !== 'undefined') 
			{ 
				attr.method = method; 
			}
			
			if(typeof autocomplete !== 'undefined') 
			{ 
				attr.autocomplete = autocomplete; 
			} 
			
			if(typeof novalidate !== 'undefined') 
			{ 
				attr.novalidate = novalidate; 
			} 
			
			if(typeof enctype !== 'undefined') 
			{ 
				attr.enctype = enctype; 
			} 
			
			if(typeof target !== 'undefined') 
			{ 
				attr.target = target; 
			}
			
			return this.create('form', attr, container, prepend);    
		},
		
		/* this will create an image and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) src = the src url  
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addIframe: function(id, className, src, container, prepend)
		{ 
			var attr = { id: id, 'className': className };  
			
			if(typeof src !== 'undefined') 
			{ 
				attr.src = src; 
			} 
			
			attr.width = '100%'; 
			attr.height = '100%';   
			attr.frameBorder = "0"; 
			
			return this.create('iframe', attr, container, prepend);   
		}, 
		
		/* this will create an a link and return the new object  
		@param (string) id = the node id 
		@param (string) className = the element className  
		@param (string) html = the element inner html
		@param (string) url = the link url  
		@param (mixed) container = the element parent id or parent object 
		@param (bool) prepend = when true the element will be added 
		to the begining */ 
		addLink: function(id, className, html, url, container, prepend)
		{ 
			var attr = { id: id, 'className': className, innerHTML: html };  
			
			if(url !== null) 
			{ 
				attr.href = url; 
			}
			
			return this.create('a', attr, container, prepend);  
		}, 
		
		/* this will remove an element from a parent and 
		remove all attr and events added to the element and its child 
		elements. 
		@param (mixed) child = the child element or id */
		removeElement: function(obj) 
		{ 
			if(obj) 
			{ 
				var container = null; 
				if(typeof obj === 'string') 
				{ 
					obj = document.getElementById(obj); 
					container = obj.parentNode; 
				} 
				else 
				{ 
					container = obj.parentNode; 
				} 
				
				if(container) 
				{ 
					/* we want to do a recursive remove child 
					removal */ 
					var children = obj.childNodes; 
					if(children) 
					{ 
						var length = children.length; 
						for(var i = 0; i < length; i++) 
						{ 
							var child = children[i]; 
							this.removeElement(child); 
						} 
					} 
					
					/* we want to remove out any attr events */ 
					var attributes = obj.attributes; 
					if(attributes) 
					{ 
						var maxLength = attributes.length; 
						for(var j = 0; j < maxLength; j++) 
						{ 
							var attr = attributes[j]; 
							if(typeof obj[attr] === 'function') 
							{ 
								obj[attr] = null; 
							} 
						} 
					}
					/* we want to remove all events aded to the 
					element */ 
					base.events.removeElementEvents(obj); 
					container.removeChild(obj); 
				} 
			}
		}, 
		
		/* this is an alias for removeElement. This will remove a 
		child element.   
		@param (mixed) child = the child element or id */
		removeChild: function(child) 
		{ 
			this.removeElement(child);   
		}, 
		
		/* this will remove all child elements.    
		@param (mixed) container = the container element or id */
		removeAll: function(container) 
		{ 
			if(typeof container === 'string') 
			{ 
				container = document.getElementById(container); 
			}  
			
			if(typeof container === 'object') 
			{ 
				while(container.firstChild) 
				{ 
					this.removeElement(container.firstChild); 
				} 
			}
		},  
		
		changeParent: function(child, newParent) 
		{ 
			var container; 
			
			if(typeof child === 'string') 
			{ 
				child = document.getElementById(child);  
			}  
			
			if(typeof newParent === 'string') 
			{  
				container = document.getElementById(newParent); 
			} 
			else 
			{ 
				container = newParent; 
			}
			
			container.appendChild(child); 
		}, 
		
		append: function(parent, child) 
		{ 
			if(typeof parent === "undefined") 
			{ 
				parent = document.body; 
			} 
			else if(typeof parent === 'string') 
			{    
				parent = document.getElementById(parent); 
			} 
			 
			parent.appendChild(child);  
		},  
		
		prepend: function(parent, child) 
		{ 
			if(typeof parent === "undefined") 
			{ 
				parent = document.body; 
			} 
			else if(typeof parent === 'string') 
			{ 
				parent = document.getElementById(parent);  
			} 
		 
			parent.insertBefore(child, parent.firstChild); 
		},  
		
		/* this will clone a node and return the 
		copy or false */ 
		clone: function(node, deepCopy) 
		{ 
			if(node && typeof node === 'object') 
			{ 
				deepCopy = deepCopy || false; 
				return node.cloneNode(deepCopy); 
			} 
			else 
			{ 
				return false; 
			} 
		}, 
		
		error: function(error, object) 
		{ 
			console.log(error.message, object);   
		} 
	}; 
	
	/* we want to use a few private functions to add input selection 
	to an element and reduce any closures */ 
	var focusElement = function()
	{ 
		this.select();  
	}; 
	
})();

/* base framework module */ 
/* 
	this adds touch support to the base framework  
*/ 
(function() 
{
	"use strict";  
	
	/* this will add an event listener for touch to an object */ 
	/* 
		@param function callBackFn = the function to be performed 
		on the event. 
		@param object obj = object to receive the event 
	*/ 
	base.extend.touch = function(callBackFn, obj)
	{ 
		/* this will be the object that receievedthe touch listeners */ 
		this.element = (typeof obj !== 'undefined')? obj : document; 
		
		this.callBackFunction = callBackFn; 
		
		/* we want to track all the touch settings */ 
		this.fingerCount = 0;
		this.startPosX = 0;
		this.startPosY = 0;
		this.posX = 0;
		this.posY = 0; 
		this.minLength = 72; 
		this.swipeLength = 0;
		this.swipeAngle = null;
		this.swipeDirection = null; 
		
		var self = this; 
		
		this.add = function() 
		{ 
			/* check if the browser supports touch */ 
			if('ontouchstart' in document.documentElement) 
			{ 
				base.addListener("touchstart", self.element, self.touchStart);
				base.addListener("touchmove", self.element, self.touchMove);
				base.addListener("touchend", self.element, self.touchEnd);
				base.addListener("touchcancel", self.element, self.touchCancel); 
				
				return true; 
			} 
			else 
			{ 
				return false; 
			} 
		}; 
		
		this.remove = function() 
		{ 
			base.removeListener("touchstart", self.element, self.touchStart);
			base.removeListener("touchmove", self.element, self.touchMove);
			base.removeListener("touchend", self.element, self.touchEnd);
			base.removeListener("touchcancel", self.element, self.touchCancel);
		}; 
		
		this.touchStart = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e);
			// get the total number of fingers touching the screen
			self.fingerCount = e.touches.length;
			
			/* only track if one finger is being used*/ 
			if ( self.fingerCount == 1 ) 
			{
				// get the coordinates of the touch
				self.startPosX = e.touches[0].pageX;
				self.startPosY = e.touches[0].pageY;
			} 
			else 
			{
				// more than one finger touched so cancel
				self.touchCancel(e);
			}
		}; 
		
		this.touchMove = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e); 
			
			if ( e.touches.length == 1 ) 
			{
				self.posX = e.touches[0].pageX;
				self.posY = e.touches[0].pageY;
			} 
			else 
			{
				self.touchCancel(e);
			} 
		}; 
		
		this.touchEnd = function(e) 
		{ 
			// cancel default 
			base.preventDefault(e); 
			
			/* we want to check if there was only one finger used and that we have a last position */ 
			if ( self.fingerCount == 1 && self.posX != 0 ) 
			{ 
				// use the Distance Formula to determine the length of the swipe
				self.swipeLength = Math.round(Math.sqrt(Math.pow(self.posX - self.startPosX,2) + Math.pow(self.posY - self.startPosY,2))); 
				
				//alert('start ' + self.posX + ' end ' + self.posX + ' ' + self.swipeLength + ' ' + self.minLength)
				// if the user swiped more than the minimum length, perform the appropriate action
				if ( self.swipeLength >= self.minLength ) 
				{ 
					calculateAngle(); 
					getSwipeDirection(); 
					
					/* call back function */ 
					if(self.callBackFunction) 
					{ 
						self.callBackFunction(self.swipeDirection); 
					} 

					self.touchCancel(e); // reset the variables
				} 
				else 
				{
					self.touchCancel(e);
				}	
			} 
			else 
			{
				self.touchCancel(e);
			} 
		}; 
		
		this.touchCancel = function(e) 
		{ 
			self.fingerCount = 0;
			self.startPosX = 0;
			self.startPosY = 0;
			self.posX = 0;
			self.posY = 0; 
			self.swipeLength = 0;
			self.swipeAngle = null;
			self.swipeDirection = null; 
		}; 
		
		var getSwipeDirection = function() 
		{ 
			if ( (self.swipeAngle <= 45) && (self.swipeAngle >= 0) ) 
			{
				self.swipeDirection = 'left';
			} 
			else if ( (self.swipeAngle <= 360) && (self.swipeAngle >= 315) ) 
			{
				self.swipeDirection = 'left';
			} 
			else if ( (self.swipeAngle >= 135) && (self.swipeAngle <= 225) ) 
			{
				self.swipeDirection = 'right';
			} 
			else if ( (self.swipeAngle > 45) && (self.swipeAngle < 135) ) 
			{
				self.swipeDirection = 'down';
			} 
			else 
			{
				self.swipeDirection = 'up';
			} 
		}; 
		
		var calculateAngle = function() 
		{ 
			var positionX = self.startPosX - self.posX, 
			positionY = self.posY - self.startPosY; 
			
			/* we need to get the distance */ 
			var z = Math.round(Math.sqrt(Math.pow(positionX,2) + Math.pow(positionY,2))); 
			
			//angle in radians 
			var r = Math.atan2(positionY,positionX); 

			//angle in degrees 
			self.swipeAngle = Math.round(r * 180 / Math.PI); 
			if (self.swipeAngle < 0) 
			{ 
				self.swipeAngle =  360 - Math.abs(self.swipeAngle); 
			}; 
		}; 
		
	}; 
})();

/* base framework module */ 
/* 
	css animation add and remove with full object 
	animation tracking 
*/ 
(function() 
{
	"use strict"; 
	
	/* this is a helper fuction to remove a class and hide 
	an element. 
	@param (object) obj = the element to hide 
	@param (string) animationClass = the css class name */ 
	var removeClassAndHide = function(obj, animationClass)
	{  
		obj.style.display = 'none'; 
		removeAnimationClass(obj, animationClass); 
	}; 
	
	/* this is a helper fuction to remove an animation 
	class after it has been animated.  
	@param (object) obj = the element object 
	@param (string) animationClass = the css class name */
	var removeAnimationClass = function(obj, animationClass)
	{ 
		base.removeClass(obj, animationClass); 
		base.animate.animating.remove(obj);   
	};
	
	/* this will add and remove css animations */ 
	base.extend.animate = { 
		
		/* this class tracks all objects being animated and can 
		add and remove them when completed */  
		animating: 
		{ 
			objects: [],  
			add: function(object, className, timer) 
			{ 
				this.stopPreviousAnimations(object); 
				this.addObject(object, className, timer);  
			}, 
			
			addObject: function(object, className, timer) 
			{ 
				if(object) 
				{ 
					var animation = { 
						object: object, 
						className: className, 
						timer: timer 
					}; 
					
					this.objects.push(animation); 
				} 
			}, 
			
			remove: function(object) 
			{ 
				/* we need to get the object index to 
				know which timer to remove */
				var objectIndex = this.removeObject(object);  
			}, 
			
			removeObject: function(object, removeClass) 
			{ 
				if(object) 
				{ 
					var animating = this.checkAnimating(object); 
					if(animating !== false) 
					{ 
						var animations = animating; 
						for(var i = 0, maxLength = animations.length; i < maxLength; i++) 
						{ 
							var animation = animations[i]; 
							/* we want to stop the timer */ 
							this.stopTimer(animation); 
							
							if(removeClass) 
							{ 
								/* we want to remove the className */ 
								base.removeClass(animation.object, animation.className); 
							}
							
							/* we want to remove the animation fron the object array */ 
							//var indexNumber = this.objects.indexOf(animation); 
							var indexNumber = base.inArray(this.objects, animation);
							if(indexNumber >= 0) 
							{ 
								this.objects.splice(indexNumber, 1); 
							}
						}
					}  
				} 
			}, 
			
			stopTimer: function(animation) 
			{ 
				if(animation) 
				{ 
					var timer = animation.timer; 
					window.clearTimeout(timer); 
				}
			}, 
			
			checkAnimating: function(obj) 
			{ 
				var animationArray = []; 
				
				/* we want to get any timers set for our object */ 
				for(var i = 0, maxLength = this.objects.length; i < maxLength; i++) 
				{ 
					 var animation = this.objects[i]; 
					 if(animation.object === obj) 
					 { 
						animationArray.push(animation); 
					 } 
				} 
				
				return (animationArray.length >= 1)? animationArray : false;  
			}, 
			
			stopPreviousAnimations: function(obj) 
			{ 
				/* we want to remove the timers and class names 
				from the object */ 
				this.removeObject(obj, 1);   
			}, 
			
			reset: function() 
			{ 
				this.objects = [];   
			}
		}, 
		
		/* this will perform an animation on the object and 
		then turn the object to display none after the 
		duration */  
		out: function(object, animationClass, duration)
		{ 
			var obj = (typeof object === 'string')? document.getElementById(object) : object; 
			 
			base.addClass(obj, animationClass);    
			
			var callBack = base.createCallBack(null, removeClassAndHide, [obj, animationClass]); 
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
		}, 
		
		/* this will dsiplay the object then perform an animation 
		on the object and remove the class after the duration */ 
		_in: function(object, animationClass, duration)
		{ 
			var obj = (typeof object === 'string')? document.getElementById(object) : object; 
			
			base.addClass(obj, animationClass); 
			obj.style.display = 'block'; 
			
			var callBack = base.createCallBack(null, removeAnimationClass, [obj, animationClass]);
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
		},  
		
		/* this will add an animation class on the object then 
		it will remove the class when the duration is done */ 
		set: function(object, animationClass, duration)
		{ 
			var obj = (typeof object === 'string')? document.getElementById(object) : object; 
			
			base.addClass(obj, animationClass);  
			
			var callBack = base.createCallBack(null, removeAnimationClass, [obj, animationClass]);
			
			var timer = window.setTimeout(callBack, duration); 
			this.animating.add(obj, animationClass, timer); 
		} 
	}; 
})();  

/* base framework module */ 
/* 
	date and time 
*/ 
(function() 
{
	"use strict"; 
	
	/* this will enable date and time functions */ 
	base.extend.date = {  
		
		/* this will store all the month names*/ 
		monthNames: ["January","February","March","April","May","June","July","August","September","October","November","December"], 
		
		/* this will store all the day names */ 
		dayNames: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"], 
		
		/* this will return the name of a day or false 
		not found. 
		@param [(int)] day = the day to use if nothing 
		is set it will use the current day 
		@param [(bool)] shortenName = set to true to return only 
		first 3 chars of name */ 
		getDayName: function(day, shortenName) 
		{ 
			day = (typeof month !== 'undefined')? day : new Date().getDate();
			
			var dayName = false; 
			/* we want to check if the day number is 
			less than the array length */ 
			if(day < this.dayNames.length) 
			{ 
				/* we want to check to shorten name */ 
				dayName = (shortenName)? this.dayNames[day].substring(0, 3) : this.dayNames[day]; 
			}
			
			return dayName; 
		},
		
		/* this will check if a year is a leap year 
		and return true or false. 
		@param (int) year = the year to check */ 
		leapYear: function(year) 
		{ 
			var leapYear = false; 
			
			if((year % 400 === 0) || (year % 100 !== 0 && year % 4 === 0))
			{ 
				leapYear = true;
			} 
			
			return leapYear; 
		}, 
		
		/* this will return the name of a month or false 
		if not found. 
		@param [(int)] month = the month to use if nothing 
		is set it will use the current month 
		@param [(bool)] shortenName = set to true to return only 
		first 3 chars of name */ 
		getMonthName: function(month, shortenName) 
		{ 
			month = (typeof month !== 'undefined')? month : new Date().getMonth(); 
			
			var monthName = false; 
			/* we want to check if the month number is 
			less than the array length */ 
			if(month < this.monthNames.length) 
			{ 
				/* we want to check to shorten name */ 
				monthName = (shortenName)? this.monthNames[month].substring(0, 3) : this.monthNames[month]; 
			} 
			
			return monthName; 
		}, 
		
		/* this will return the length of a month. 
		@param [(int)] month = the month to use if nothing 
		is set it will use the current month 
		@param [(int)] year = the year to use if nothing 
		is set it will use the current year */ 
		getMonthLength: function(month, year) 
		{ 
			/* we want to check to use params or use 
			default */ 
			month = (typeof month !== 'undefined')? month : new Date().getMonth();
			year = (typeof year !== 'undefined')? year : new Date().getFullYear(); 
			
			/* we need to get the month lengths for 
			the year */ 
			var yearMonthLengths = this.getMonthsLength(year); 
			
			/* we can select the month length from 
			the yearMonthLengths array */ 
			var monthLength = yearMonthLengths[month]; 
			
			return monthLength; 
			
		}, 
		
		/* this will return an array with all the month 
		lengths for a year. 
		@params [(int)] year = the year to use if nothing
		is set it will use the current year */ 
		getMonthsLength: function(year) 
		{ 
			year = (typeof year !== 'undefined')? year : new Date().getFullYear();
			
			/* we needto check if the year is a leap year */ 
			var isLeapYear = this.leapYear(year); 
			var days = (isLeapYear === true)? 
				[31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
			:
				[31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];  
			
			return days; 
		}, 
		
		toYears: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(milliseconds / (1000 * 60 * 60 * 24 * 365.26)); 
			} 
			return false; 
		}, 
		
		toDays: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(milliseconds / (60 * 60 * 1000 * 24) * 1); 
			} 
			return false; 
		}, 
		
		toHours: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor((milliseconds % (60 * 60 * 1000 * 24)) / (60 * 60 * 1000) * 1); 
			} 
			return false; 
		}, 
		
		toMinutes: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor(((milliseconds % (60 * 60 * 1000 * 24)) % (60 * 60 * 1000)) / (60 * 1000) * 1); 
			} 
			return false; 
		}, 
		
		toSeconds: function(milliseconds) 
		{ 
			if(typeof milliseconds === 'number') 
			{ 
				return Math.floor((((milliseconds % (60 * 60 * 1000 * 24)) % (60 * 60 * 1000)) % (60 * 1000)) / 1000 * 1); 
			} 
			return false; 
		},
		
		/* this will get the difference between two dates 
		and return a time object with the difference in 
		years, days, hours, minutes, seconds, milliseconds. 
		@param (date) startDate = the starting date 
		@param (date) endDate = the end date */ 
		getDifference: function(startDate, endDate) 
		{ 
			/* we want to convert the dates to objects */ 
			var start = new Date(startDate), 
			end = new Date(endDate); 
			
			/* we want to subtract the start time from the end */ 
			var difference = (end.getTime() - start.getTime()); 
			
			return { 
				years:  this.toYears(difference),  
				days:  this.toDays(difference), 
				hours:  this.toHours(difference), 
				minutes:  this.toMinutes(difference), 
				seconds:  this.toSeconds(difference) 
			};  
		}
	}; 
})();

/* base framework module */ 
/* 
	html5 history state 
*/ 
(function() 
{
	"use strict"; 
	
	/* this will update the page title */ 
	var updateTitle =  function(title) 
	{ 
		if(typeof title === 'string') 
		{ 
			document.title = title; 
		}
	}; 	
	
	/* this will check if the user is sending the title 
	by the state object because most browsers dont use 
	the current title param. 
	@param (string) title = the new title 
	@param (object) stateObj = the new state object */ 
	var getStateTitle = function(title, stateObj) 
	{ 
		title = (title === null && (stateObj && stateObj.title))? stateObj.title : title; 
		
		return title; 
	}; 
	
	/* this will add and remove states from window history */ 
	base.extend.history = {  
		
		/* this will check if history api is supported and if so 
		return true else return false */ 
		isSupported: function() 
		{ 
			if('history' in window && 'pushState' in window.history) 
			{ 
				return true; 
			} 
			else 
			{ 
				return false; 
			} 
		}, 
		
		/* this will add and event listener for window popstate. 
		@param (function) fn = the function to use as callback 
		@param [(bool)] capture = event capture */ 
		addEvent: function(fn, capture) 
		{ 
			/* this will check if the current state has a 
			title property to update thepage title */ 
			var popEvent = function(e) 
			{ 
				if(e.state && e.state.title) 
				{ 
					updateTitle(e.state.title); 
				} 
				
				fn(e); 
			}; 
			
			base.events.add('popstate', window, popEvent, capture, true, fn);  
		}, 
		
		/* this will remove and event listener for window popstate. 
		@param (function) fn = the function to use as callback 
		@param [(bool)] capture = event capture */ 
		removeEvent: function(fn, capture) 
		{ 
			base.removeListener('popstate', window, fn, capture); 
		},
		
		/* this will add a state to the window history 
		@param (object) object = the state object 
		@param (string) title = the state page title 
		@param (string) url = the state url */  
		pushState: function(object, title, url)
		{  
			var lastState = window.history.state; 
			
			title = getStateTitle(title, object); 

			/* we want to check if the object is not already
			the last saved state */ 
			if(!lastState || !base.equals(lastState, object)) 
			{  
				/* we want to add the new state to the window history*/ 
				window.history.pushState(object, title, url);   
			} 
			
			updateTitle(title);
		}, 
		
		/* this will add a state to the window history 
		@param (object) object = the state object 
		@param (string) title = the state page title 
		@param (string) url = the state url */  
		replaceState: function(object, title, url)
		{  
			title = getStateTitle(title, object); 
			/* we want to add the new state to the window history*/ 
			window.history.replaceState(object, title, url);  
			
			updateTitle(title); 
		},
		
		/* this will go to the next state in the window history */ 
		nextState: function()
		{ 
			window.history.forward();  
		},  
		
		/* this will go to the previous state in the window history */ 
		prevState: function()
		{ 
			window.history.back();  
		}, 
		
		/* this will take you to a specified number in the history 
		index. 
		@param (int) indexNumber= the number to go to */ 
		goTo: function(indexNumber) 
		{ 
			window.history.go(indexNumber); 
		} 
	}; 
})(); 

/* base framework module */ 
/* 
	router module 
*/ 
(function() 
{
	"use strict"; 
	
	/* 
		router 
		
		this will add client side routing to allow routes to be 
		setup and the router to navigate and activate the routes 
		that match the uri. 
		
		@param (string) baseURI = the root of the router uri 
		@param (string) title = the root title 
	*/ 
	var router = function(baseURI, title) 
	{ 
		/* this is the root of the uri for the routing object 
		and the base title */ 
		this.baseURI = baseURI || '/'; 
		this.title = (typeof title !== 'undefined')? title : ''; 
		
		/* this will setup the router and check 
		to add the history support */ 
		this.setup();  
	}; 
	
	router.prototype = 
	{ 
		constructor: router, 
		
		/* this will store each route added to the 
		router. */ 
		routes: [], 
		
		/* this will be used to accessour history object */ 
		history: null, 
		
		/* this will setup our child history object and 
		create a closure to allow our child to retain 
		the parents scope */ 
		setupHistory: function() 
		{ 
			var parent = this; 
			
			this.history = 
			{ 
				/* this will check if the history api is supported 
				and enabled */ 
				enabled: false, 
				
				/* this will check to add history support is 
				the browser supports it */ 
				setup: function() 
				{ 
					/* we want to check if history is enabled */ 
					this.enabled = base.history.isSupported(); 
					
					/* we want to check to add the history event listener 
					that will check the popsate events and select the 
					nav option by the history state object */ 
					if(this.enabled) 
					{ 
						this.addEvent();  
					} 
					return this; 
				}, 
				
				/* this will add an event history listener that will 
				trigger when the window history is changed */ 
				addEvent: function() 
				{   
					base.history.addEvent(this.checkHistoryState); 
					return this; 
				}, 
				
				removeEvent: function() 
				{ 
					base.history.remove(this.checkHistoryState); 
					return this; 
				}, 
				
				checkHistoryState: function(evt) 
				{ 
					base.preventDefault(evt); 
					
					/* we want to check if the event has a state and if the 
					state location is from the background */ 
					var state = evt.state; 
					if(state && state.location === 'base-app-router') 
					{ 
						parent.checkActiveRoutes(state.uri);  
					}   
				}, 
				
				pushState: function(uri, data) 
				{ 
					if(this.enabled) 
					{
						uri = parent.createURI(uri);  
						
						var history = window.history,  
						lastState = history.state; 
						
						var stateObj = { 
							location: 'base-app-router', 
							uri: uri  
						};  
						
						if(data && typeof data === 'object') 
						{ 
							stateObj = base.extendObject(stateObj, data); 
						} 
				
						/* we want to check if the object is not already
						the last saved state */ 
						if(!lastState || lastState.uri !== uri) 
						{  
							/* we want to add the new state to the window history*/ 
							history.pushState(stateObj, null, uri);   
						}
					} 
					
					parent.activate(); 
					return this; 
				}
			}; 
			
			this.history.setup();
		}, 
		
		/* this will add a route to the router. 
		@param (string) uri = the route uri 
		@param (string) template = the template name 
		@param [(function)] callBack = the call back function 
		@param [(string)] title = the route title 
		@return (object) reference to the object */ 
		add: function(uri, template, callBack, title) 
		{ 
			if(typeof uri === 'string') 
			{ 
				var route = 
				{ 
					uri: this.removeSlashes(uri), 
					template: template, 
					callBack: callBack, 
					title: title  
				}; 
				this.routes.push(route); 
			} 
			return this; 
		}, 
		
		/* this will get a route by the route settings. 
		@param (string) uri = the route uri 
		@param (string) template = the template name 
		@param [(function)] callBack = the call back function 
		@return (mixed) the routeobject or false on error */
		getRoute: function(uri, template, callBack) 
		{ 
			if(this.routes.length) 
			{
				for(var i = 0, maxLength = this.routes.length; i < maxLength; i++) 
				{ 
					var route = this.routes[i]; 
					if(route.uri === uri && route.template === template && route.callBack === callBack) 
					{ 
						return route; 
					} 
				} 
			} 
			return false; 
		}, 
		
		/* this will remove a route from the router by the route settings. 
		@param (string) uri = the route uri 
		@param (string) template = the template name 
		@param [(function)] callBack = the call back function  
		@return (object) reference to the object */
		remove: function(uri, template, callBack) 
		{ 
			var route = this.getRoute(uri, template, callBack); 
			if(route) 
			{ 
				var index = base.inArray(this.routes, route); 
				if(index > -1) 
				{ 
					this.routes.splice(index, 1); 
				} 
			} 
			return this;  
		}, 
		
		/* this will setup the history object  
		@return (object) reference to the object */
		setup: function() 
		{ 
			this.setupHistory(); 
			return this;  
		}, 
		
		/* this will reset the router  
		@return (object) reference to the object */
		reset: function() 
		{ 
			this.routes = []; 
			return this;  
		}, 
		
		/* this will activate any active routes   
		@return (object) reference to the object */
		activate: function() 
		{ 
			this.checkActiveRoutes(); 
			return this;  
		}, 
		
		/* this will navigate the router to the uri. 
		@param (string) uri = the relative uri 
		@param [(object)] data = a data object that will 
		be added to the history state object
		@return (object) a reference to the router object */ 
		navigate: function(uri, data) 
		{ 
			this.history.pushState(uri, data); 
			return this; 
		}, 
		
		/* this will update the window title with the route title. 
		@param (object) route = a route that has a title 
		@return (object) a reference to the router object */ 
		updateTitle: function(route) 
		{ 
			if(route && route.title) 
			{ 
				var title = route.title, 
				parent = this; 
				
				var getTitle = function(title) 
				{ 
				
					/* this will uppercase each word in a string
					@param (string) str = the string to uppercase 
					@return (string) the uppercase string */ 
					var toTitleCase = function(str)
					{
						var pattern = /\w\S*/; 
						return str.replace(pattern, function(txt)
						{
							return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
						});
					}; 
					
					/* this will replace the params in the title 
					@param (string) str = the route title 
					@return (string) the title string */ 
					var replaceParams = function(str)
					{
						if(str.indexOf(':') > -1) 
						{ 
							var params = route.params; 
							for(var prop in params) 
							{ 
								var param = params[prop];
								var pattern = new RegExp(':' + prop, 'gi');  
								str = str.replace(pattern, param); 
							} 
						} 
						
						return str; 
					}; 
	 
					if(title) 
					{  
						/* we want to replace any params in the title 
						and uppercase the title */ 
						title = replaceParams(title);
						var pattern = /-/g; 
						title = toTitleCase(title.replace(pattern, ' ')); 
						
						/* we want to tcheck to add the base title to the 
						to the end of the title */ 
						if(parent.title != '') 
						{ 
							title += " - " + parent.title; 
						}
					} 
					return title; 
				}; 
				
				document.title = getTitle(title); 
			} 
			return this; 
		}, 
		
		/* this will get all active routes from a path. 
		@param [(string)] path = the path or the current 
		url path will be used 
		@return (array) an array of active routes */ 
		checkActiveRoutes: function(path) 
		{ 
			var active = []; 
			if(this.routes.length) 
			{ 
				path = path || this.getPath(); 
				
				for(var i = 0, maxLength = this.routes.length; i < maxLength; i++) 
				{ 
					var route = this.routes[i]; 
					var check = this.check(route, path); 
					if(check !== false) 
					{ 
						active.push(route); 
					} 
				} 
			} 
			return active; 
		}, 
		
		/* this will remove the begining and ending slashes on a url. 
		@param (string) uri = the uri to remove 
		@return (string) the uri */ 
		removeSlashes: function(uri) 
		{ 
			if(typeof uri === 'string') 
			{ 
				var pattern = /(^\/|\/$)/g; 
				uri = uri.toString().replace(pattern, '');  
			} 
			
			return uri; 
		}, 
		
		/* this will create a uri with the base path and 
		the route uri. 
		@param (string) uri = the uri 
		@return (string) the uri */
		createURI: function(uri) 
		{ 
			var pathURI = ''; 
			if(this.baseURI !== '/') 
			{ 
				pathURI += this.baseURI; 
			} 
			pathURI += ((pathURI[pathURI.length - 1] !== '/')? '/' : '') + this.removeSlashes(uri); 
			
			return pathURI; 
		}, 
		
		/* this will check to select a route if it the route uri 
		matches the path. 
		@param (object) route = the route 
		@param [(string)] path = the path. if left null the 
		active path will beused 
		@return (bool) true or false if active */ 	
		check: function(route, path) 
		{ 
			var matched = false; 
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			path = path || this.getPath(); 
			
			/* we want to check if the route uri matches the path uri */ 
			var validURI = this.match(route, path); 
			if(validURI) 
			{ 
				matched = true;   
				this.select(route);  
			}  
			return matched; 
		}, 
		
		/* this will match a route if it the route uri 
		matches the path. 
		@param (object) route = the route 
		@param [(string)] path = the path. if left null the 
		active path will beused 
		@return (bool) true or false if active */
		match: function(route, path) 
		{ 
			var parent = this; 
			
			/* this will setup the route uri string to be used in 
			a regexp match. 
			@param (string) uri = the route uri 
			@return (string) the uri to be used in a regexp match */ 
			var setupMatch = function(uri) 
			{ 
				var uriQuery = ""; 
				if(uri) 
				{ 
					/* we want to setup the wild card and param 
					checks to be modified to the route uri string */ 
					var allowAll = /(\*)/g, 
					param = /(:[^\/]*)/g, 
					optionalParams = /(\?\/*)/g, 
					optionalSlash = /(\/):[^\/]*?\?/g, 
					filter = /\//g; 
					uriQuery = uri.replace(filter, "\/").replace(allowAll, '.*'); 
					
					/* this will setup for optional slashes before the optional params */ 
					uriQuery = uriQuery.replace(optionalSlash, function(str)
					{  
						var pattern = /\//g; 
						return str.replace(pattern, '/*');  
					}); 
					
					/* this will setup for optional params and params 
					and stop at the last slash or query start */ 
					uriQuery = uriQuery.replace(optionalParams, '?\/*').replace(param, '([^\/|?]*)');  
				} 
				
				/* we want to set and string end if the wild card is not set */ 
				uriQuery += (uri[uri.length - 1] === '*')? '' : '$'; 
				return uriQuery;  
			}; 
			
			/* this will get the param names from the route uri. 
			@param (string) uri = the route uri 
			@return (array) an array with the param keys */ 
			var setupParamKeys = function(uri) 
			{ 
				var params = []; 
				if(uri) 
				{ 
					var pattern = /:(.[^\/]*)/g, 
					matches = uri.match(pattern); 
					if(matches) 
					{ 
						for(var i = 0, maxLength = matches.length; i < maxLength; i++) 
						{ 
							var param = matches[i]; 
							if(param) 
							{ 
								pattern = /(:|\?)/g; 
								var filter = /\*/g; 
								/* we need to remove the colon, question mark, or asterisk
								 from the key name */ 
								param = param.replace(pattern, '').replace(filter, ''); 
								params.push(param); 
							} 
						} 
					} 
				}
				return params;
			}; 
			
			/* this will get the param names from the route uri. 
			@param (string) routeURI = the route uri 
			@param (array) values = the path param values 
			@return (mixed) an empty object or an object with key 
			and values of the params */
			var getParams = function(routeURI, values) 
			{ 
				var keys = setupParamKeys(routeURI),  
				params = {}; 
				
				if(values && typeof values === 'object') 
				{ 
					/* we want to add the value to each key */ 
					if(keys) 
					{ 
						for(var i = 0, maxL = keys.length; i < maxL; i++) 
						{ 
							var key = keys[i]; 
							if(typeof key !== 'undefined') 
							{ 
								params[key] = values[i]; 
							} 
						} 
					} 
				}
				return params; 
			};  
			
			var uri = route.uri,    
			matched = false;  
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			path = path || this.getPath(); 
			
			 /* we need to setup the uri reg expression to match the 
			 route uri to the path uri */ 
			var matchURI = setupMatch(uri), 
			routeURI = this.createURI(matchURI); 
			
			/* we want to check if the route uri matches the path uri */ 
			var validURI = path.match(routeURI); 
			if(validURI) 
			{ 
				matched = true; 
				
				/* this will remove the first match from the 
				the params */
				if(validURI && typeof validURI === 'object') 
				{   
					validURI.shift(); 
					matched = validURI; 
				}
				
				/* this will get the uri params of the route 
				and if set will save them to the route */    
				var params = getParams(uri, validURI); 
				if(params) 
				{ 
					route.params = params;  
				} 
			}  
			return matched; 
		}, 
		
		/* this will get the param names from the route uri. 
		@param (object) route = the route object */
		select: function(route) 
		{ 
			if(route) 
			{ 
				if(typeof route.callBack === 'function') 
				{ 
					var params = (route.params)? route.params : null; 
					route.callBack.call({}, params); 
				} 
				
				this.updateTitle(route);  
			} 
		}, 
		
		/* this will get the location pathname. 
		@return (string) the location pathname */ 
		getPath: function()
		{ 
			/* we want to get the window location path */  
			return window.location.pathname;  
		}
	}; 
	
	base.extend.router = router; 
	
})();