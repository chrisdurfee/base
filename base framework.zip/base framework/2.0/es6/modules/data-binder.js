/* base framework module */
(function()
{
	"use strict"; 
	
	/**
	 * DataPubSub
	 * 
	 * This is a pub sub class to allow subscribers to 
	 * listen for updates when published by publishers. 
	 * @class 
	 */
	class DataPubSub
	{ 
		/**
		 * @constructor
		 */
		constructor()
		{ 
			/**
			 * @member {object} callBacks
			 * @protected
			 */
			this.callBacks = {}; 
			
			/**
			 * @member {int} lastToken
			 * @protected
			 */
			this.lastToken = -1; 
		} 

		/**
		 * This will get a subscriber array. 
		 * 
		 * @param {string} msg 
		 * @return {array}
		 */
		get(msg) 
		{ 
			let callBacks = this.callBacks;
			return (callBacks[msg] || (callBacks[msg] = []));
		}

		/**
		 * This will reset pub sub. 
		 */
		reset() 
		{ 
			this.callBacks = {}; 
			this.lastToken = -1;
		} 

		/**
		 * This will add a subscriber. 
		 * 
		 * @param {string} msg 
		 * @param {function} callBack 
		 * @return {string} The subscriber token. 
		 */
		on(msg, callBack) 
		{ 
			let token = (++this.lastToken),
			list = this.get(msg);
			list.push({
				token: token, 
				callBack: callBack
			});
			return token; 
		} 
		
		/**
		 * This will remove a subscriber. 
		 * 
		 * @param {string} msg 
		 * @param {string} token 
		 */
		off(msg, token) 
		{ 
			let list = this.callBacks[msg] || false;
			if(list === false)
			{
				return false; 
			}
			
			let length = list.length; 
			for (var i = 0; i < length; i++ ) 
			{
				var item = list[i]; 
				if(item.token === token)
				{
					list.splice(i, 1);
					break;
				}
			}
		} 
		
		/**
		 * This will delete a message. 
		 * 
		 * @param {string} msg 
		 */
		remove(msg) 
		{ 
			var callBacks = this.callBacks; 
			if(callBacks[msg])
			{ 
				delete callBacks[msg]; 
			}
		} 
		
		/**
		 * This will publish a message. 
		 * 
		 * @param {string} msg 
		 * @param {string} value
		 * @param {object} committer
		 */
		publish(msg) 
		{ 
			let i, length,
			list = this.callBacks[msg] || false; 
			if(list === false)
			{ 
				return false; 
			}
			
			let args = Array.prototype.slice.call(arguments, 1);
			
			length = list.length;
			for (i = 0; i < length; i++) 
			{
				var item = list[i]; 
				if(!item)
				{
					continue; 
				}
				item.callBack.apply(this, args);
			}
		}
	}
	
	const pubSub = new DataPubSub(); 
	base.extend.DataPubSub = DataPubSub;
	
	/**
	 * Source
	 * 
	 * This will create a new source to use with 
	 * a connection. 
	 * @class 
	 */
	class Source
	{
		/**
		 * @constructor
		 */
		constructor()
		{ 
			/**
			 * @member {string} msg
			 * @protected
			 */
			this.msg = null; 

			/**
			 * @member {string} token
			 */
			this.token = null; 
		} 
		
		/**
		 * This will set the token. 
		 * 
		 * @param {string} token 
		 */
		setToken(token)
		{
			this.token = token; 
		}
	} 
	
	/**
	 * OneWaySource 
	 * 
	 * This will create a one way source to use with 
	 * a connection. 
	 * @class
	 * @augments Source
	 */
	class OneWaySource extends Source
	{
		/**
		 * This will setup the data source. 
		 * 
		 * @param {object} data 
		 */
		constructor(data)
		{ 
			super();  
			this.data = data; 
		} 
		
		/**
		 * This will subscribe to a message. 
		 * 
		 * @param {string} msg 
		 * @param {function} callBack 
		 */
		subscribe(msg, callBack)
		{
			this.msg = msg; 
			this.token = this.data.on(msg, callBack); 
		} 
		
		/**
		 * This will unsubscribe from the message. 
		 */
		unsubscribe()
		{
			this.data.off(this.msg, this.token); 
		}
	}
	
	/**
	 * TwoWaySource 
	 * 
	 * This will create a two way source to use with 
	 * a connection. 
	 * @class
	 * @augments Source
	 */
	class TwoWaySource extends Source
	{
		/**
		 * @member {function} callBack
		 */
		callBack = null; 
		
		/**
		 * This will subscribe to a message.
		 * 
		 * @param {string} msg 
		 */
		subscribe(msg)
		{
			this.msg = msg; 
			let callBack = base.bind(this, this.callBack); 
			this.token = pubSub.on(msg, callBack); 
		} 
		
		/**
		 * This will unsubscribe from a message. 
		 */
		unsubscribe()
		{
			pubSub.off(this.msg, this.token); 
		}
	}
	
	/**
	 * DataSource 
	 * 
	 * This will create a data source to use with 
	 * a connection. 
	 * @class
	 * @augments TwoWaySource
	 */
	class DataSource extends TwoWaySource
	{
		/**
		 * @constructor
		 * @param {object} data 
		 * @param {string} prop 
		 */
		constructor(data, prop)
		{
			super(); 
			this.data = data;  
			this.prop = prop;   
		} 
		
		/**
		 * This will set the data value. 
		 * 
		 * @param {*} value 
		 */
		set(value)
		{
			this.data.set(this.prop, value); 
		} 
		
		/**
		 * This will get the data value. 
		 */
		get()
		{
			return this.data.get(this.prop);
		} 
		
		/**
		 * The callBack when updated. 
		 * 
		 * @param {*} value 
		 * @param {object} committer 
		 */
		callBack(value, committer) 
		{
			if(this.data !== committer) 
			{
				this.data.set(this.prop, value, committer); 
			}
		}
	} 
	
	/**
	 * ElementSource 
	 * 
	 * This will create an element source to use with 
	 * a connection. 
	 * @class
	 * @augments TwoWaySource
	 */
	class ElementSource extends TwoWaySource
	{
		/**
		 * @constructor
		 * @param {object} element 
		 * @param {string} attr 
		 * @param {(string|function)} [filter] 
		 */
		constructor(element, attr, filter)
		{
			super();   
			this.element = element; 
			this.attr = this.getAttrBind(attr); 
			
			this.filter = (typeof filter === 'string')? this.setupFilter(filter) : filter; 
		} 
		
		/**
		 * This will get the bind attribute. 
		 * 
		 * @param {string} [customAttr] 
		 * @return {string}
		 */
		getAttrBind(customAttr)
		{
			/* this will setup the custom attr if the prop 
			has specified one. */ 
			if(customAttr)
			{
				return customAttr; 
			}
			
			let attr = 'textContent';
			/* if no custom attr has been requested we will get the 
			default attr of the element */ 
			let element = this.element; 
			if(!(element && typeof element === 'object')) 
			{ 
				return attr; 
			}
			
			let tagName = element.tagName.toLowerCase();
			if (tagName === "input" || tagName === "textarea" || tagName === "select") 
			{
				let type = element.type; 
				if(type) 
				{ 
					switch(type)
					{
						case 'checkbox':
							attr = 'checked';
							break;
						case 'file':
							attr = 'files';
							break;
						default:
							attr = 'value';
					}
				}
				else 
				{ 
					attr = 'value';
				}
			} 
			return attr; 
		} 
		
		/**
		 * This will setup a filter callBack. 
		 * 
		 * @param {string} filter 
		 * @return {function}
		 */
		setupFilter(filter)
		{
			let pattern = /(\[\[[^\]]+\]\])/;
			return (value) =>
			{
				return filter.replace(pattern, value);
			}; 
		} 
		
		/**
		 * This will set a value on an element. 
		 * 
		 * @param {*} value 
		 */
		set(value) 
		{ 
			let element = this.element; 
			if(!element || typeof element !== 'object') 
			{ 
				return false; 
			}
				
			/* this will check to apply the option filter before 
			setting the value */ 
			if(this.filter)
			{
				value = this.filter(value); 
			} 

			let attr = this.attr, 
			type = element.type; 
			if(type) 
			{ 
				switch(type)
				{
					case 'checkbox':
						value = (value == 1);
						break; 
					case 'radio':
						element.checked = (element.value === value);
						return true;
				}
			}

			if(attr.substr(4, 1) === '-')
			{
				base.setAttr(element, attr, value); 
			}
			else 
			{
				element[attr] = value; 
			} 
		} 

		/**
		 * This will get the value from an element. 
		 */
		get() 
		{ 
			let element = this.element;
			if(!element || typeof element !== 'object') 
			{ 
				return ''; 
			}
				
			let attr = this.attr; 
			return (attr.substr(4, 1) === '-')? base.getAttr(element, attr) : element[attr];
		} 
		
		/**
		 * The callBack when updated. 
		 * 
		 * @param {*} value 
		 * @param {object} committer 
		 */
		callBack(value, committer) 
		{
			if(committer !== this.element)
			{
				this.set(value);
			}
		}
	}
	
	/**
	 * Connection
	 * 
	 * This will create a connection. 
	 * @class 
	 */
	class Connection
	{
		/**
		 * This will be used to unsubscribe. 
		 */
		unsubscribe()
		{
			
		}
	} 
	
	/**
	 * OneWayConnection
	 * 
	 * This will create a one way connection. 
	 * @class 
	 * @augments Connection
	 */
	class OneWayConnection extends Connection
	{
		/**
		 * @constructor
		 */
		constructor()
		{
			/**
			 * @member {object} source
			 */
			this.source = null; 
		} 
		
		/**
		 * This will setup the connection source. 
		 * 
		 * @param {object} data 
		 * @return {object}
		 */
		addSource(data)
		{
			return (this.source = new OneWaySource(data)); 
		} 
		
		/**
		 * This will be used to unsubscribe. 
		 * @override
		 */
		unsubscribe()
		{
			this.source.unsubscribe();  
			this.source = null; 
		}
	}
	
	/**
	 * TwoWayConnection
	 * 
	 * This will setup a two way connection. 
	 * @class
	 * @augments Connection
	 */
	class TwoWayConnection extends Connection
	{
		/**
		 * @constructor
		 */
		constructor()
		{
			this.element = null; 
			this.data = null; 
		} 
		
		/**
		 * This will add the element source. 
		 * 
		 * @param {object} element 
		 * @param {string} attr 
		 * @param {(string|function)} filter 
		 * @return {object}
		 */
		addElement(element, attr, filter)
		{
			return (this.element = new ElementSource(element, attr, filter)); 
		} 
		
		/**
		 * This will add the data source. 
		 * 
		 * @param {object} data 
		 * @param {string} prop 
		 * @return {object}
		 */
		addData(data, prop)
		{
			return (this.data = new DataSource(data, prop));  
		} 
		
		/**
		 * This will unsubscribe from a source. 
		 * 
		 * @param {object} source 
		 */
		unsubscribeSource(source)
		{
			if(source)
			{
				source.unsubscribe(); 
			}
		} 
		
		/**
		 * This will be used to unsubscribe. 
		 * @override
		 */
		unsubscribe()
		{
			this.unsubscribeSource(this.element); 
			this.unsubscribeSource(this.data); 
			
			this.element = null; 
			this.data = null;
		}
	}
	
	/**
	 * ConnectionTracker
	 * 
	 * This will create a new connection tracker to track active 
	 * connections in the data binder. 
	 * @class
	 */
	class ConnectionTracker
	{ 
		/**
		 * @constructor
		 */
		constructor() 
		{  
			/**
			 * @member {object} connections
			 */
			this.connections = {};  
		}  
		
		/**
		 * This will add a new connection to be tracked. 
		 * 
		 * @param {string} id 
		 * @param {string} attr 
		 * @param {object} connection 
		 * @return {object}
		 */
		add(id, attr, connection)
		{
			let connections = this.find(id); 
			return (connections[attr] = connection);  
		} 
		
		/**
		 * This will get a connection. 
		 * 
		 * @param {string} id 
		 * @param {string} attr 
		 * @return {(object|bool)}
		 */
		get(id, attr)
		{
			let connections = this.connections[id]; 
			if(connections)
			{
				return (connections[attr] || false); 
			}
			return false; 
		} 
		
		/**
		 * This will find a connection. 
		 * 
		 * @param {string} id 
		 * @return {object}
		 */
		find(id)
		{
			let connections = this.connections; 
			return (connections[id] || (connections[id] = {}));
		}
		
		/**
		 * This will remove a connection or all connections by id. 
		 * @param {string} id 
		 * @param {string} [attr] 
		 */
		remove(id, attr)
		{
			let connections = this.connections[id]; 
			if(!connections)
			{
				return false; 
			}

			let connection; 
			if(attr)
			{
				connection = connections[attr]; 
				if(connection)
				{
					connection.unsubscribe(); 
					delete connections[attr]; 
				}
				
				/* this will remove the msg from the elements 
				if no elements are listed under the msg */ 
				if(base.isEmpty(connections))
				{
					delete this.connections[id]; 
				}
			} 
			else 
			{
				for(var prop in connections)
				{
					if(connections.hasOwnProperty(prop))
					{
						connection = connections[prop];
						if(connection)
						{
							connection.unsubscribe(); 
						}
					} 
				}
				
				delete this.connections[id];
			}
		}
	}

	/**
	 * DataBinder
	 * 
	 * This will create a data binder object that can 
	 * create one way and two way data bindings. 
	 * @class
	 */
	class DataBinder
	{ 
		/**
		 * @constructor
		 */
		constructor() 
		{ 
			this.version = "1.0.1";
			this.attr = 'data-bind-id'; 

			this.connections = new ConnectionTracker(); 

			this.idCount = 0; 
			this.setup(); 
		} 

		/**
		 * This will setup the events. 
		 * @protected
		 */
		setup() 
		{ 
			this.setupEvents();
		} 

		/**
		 * This will bind an element to a data property. 
		 * 
		 * @param {object} element 
		 * @param {object} data 
		 * @param {string} prop 
		 * @param {(string|function)} [filter] 
		 * @return {object} an instance of the databinder. 
		 */
		bind(element, data, prop, filter) 
		{ 
			let bindSettings = this.getPropSettings(prop); 
			prop = bindSettings.prop; 
			
			/* this will setup the model bind attr to the 
			element and assign a bind id attr to support 
			two way binding */ 
			let connection = this.setupConnection(element, data, prop, bindSettings.attr, filter);   

			/* we want to get the starting value of the 
			data and set it on our element */ 
			let connectionElement = connection.element, 
			value = data.get(prop); 
			if(typeof value !== 'undefined') 
			{ 
				connectionElement.set(value); 
			}
			else 
			{ 
				/* this will set the element value 
				as the prop value */ 
				value = connectionElement.get(); 
				if(value !== '')
				{ 
					connection.data.set(value);
				} 
			}
			return this; 
		} 
		
		/**
		 * This will bind an element to a data property. 
		 * 
		 * @protected
		 * @param {object} element 
		 * @param {object} data 
		 * @param {string} prop 
		 * @param {string} customAttr
		 * @param {(string|function)} [filter] 
		 * @return {object} The new connection. 
		 */
		setupConnection(element, data, prop, customAttr, filter)
		{
			let id = this.getBindId(element),
			connection = new TwoWayConnection(),

			// this will create the data source 
			dataSource = connection.addData(data, prop); 
			// this will subscribe the data to the element
			dataSource.subscribe(id); 
			
			/* this will add the data binding 
			attr to our element so it will subscribe to 
			the two data changes */
			let dataId = data.getDataId(), 
			msg = dataId + ':' + prop; 
			
			// this will create the element source 
			let elementSource = connection.addElement(element, customAttr, filter); 
			// this will subscribe the element to the data
			elementSource.subscribe(msg); 
			
			this.addConnection(id, 'bind', connection);
			
			return connection;  
		} 
		
		/**
		 * This will add a new connection to the 
		 * connection tracker. 
		 * 
		 * @protected 
		 * @param {string} id 
		 * @param {string} attr 
		 * @param {object} connection 
		 */
		addConnection(id, attr, connection)
		{
			this.connections.add(id, attr, connection);
		} 
		
		/**
		 * This will set the bind id. 
		 * 
		 * @param {object} element 
		 */
		setBindId(element)
		{
			let id = 'bs-db-' + this.idCount++; 
			base.attr(element, this.attr, id);
			return id; 
		} 
		
		/**
		 * This will get the bind id. 
		 * 
		 * @param {object} element 
		 * @return {string}
		 */
		getBindId(element)
		{
			let id = base.attr(element, this.attr); 
			if(!id) 
			{
				id = this.setBindId(element); 
			}
			return id; 
		} 
		
		/**
		 * This will parse the prop to get the settings. 
		 * 
		 * @param {string} prop 
		 * @return {object}
		 */
		getPropSettings(prop)
		{
			let attr = null; 
			
			/* this will setup the custom attr if the prop 
			has specified one. */ 
			let parts = prop.split(':'); 
			if(parts.length > 1)
			{
				[attr, prop] = parts; 
			}
			
			return {
				prop, 
				attr
			}; 
		} 
		
		/**
		 * This will unbind the element. 
		 * 
		 * @param {object} element 
		 * @return {object} an instance of the data binder. 
		 */
		unbind(element) 
		{ 
			let id = base.data(element, this.attr); 
			if(id)
			{
				this.connections.remove(id);
			} 
			return this;
		} 
		
		/**
		 * This will setup a watcher for an element. 
		 * 
		 * @param {object} element 
		 * @param {object} data 
		 * @param {string} prop 
		 * @param {function} callBack 
		 */
		watch(element, data, prop, callBack)
		{
			if(!element || typeof element !== 'object')
			{
				return false; 
			}
			
			let connection = new OneWayConnection();
			
			// this will create the one way source 
			const source = connection.addSource(data); 
			source.subscribe(prop, callBack);
			
			// this will add the new connection to the connection tracker
			const id = this.getBindId(element),
			attr = data.getDataId() + ':' + prop; 
			this.addConnection(id, attr, connection);  
			
			let value = data.get(prop); 
			if(typeof value !== 'undefined')
			{
				callBack(value); 
			}
		} 
		
		/**
		 * This will remove a watcher from an element. 
		 * 
		 * @param {object} element 
		 * @param {object} data 
		 * @param {string} prop 
		 */
		unwatch(element, data, prop)
		{
			if(!element || typeof element !== 'object')
			{
				return false; 
			} 
			
			let id = base.attr(element, this.attr); 
			if(id)
			{
				let attr = data.getDataId() + ':' + prop;
				this.connections.remove(id, attr);
			} 
		} 

		/**
		 * This will publish to the pub sub. 
		 * 
		 * @param {string} msg 
		 * @param {*} value 
		 * @param {object} committer 
		 * @return {object} an instance of the data binder. 
		 */
		publish(msg, value, committer)
		{ 
			pubSub.publish(msg, value, committer);
			return this;
		} 
		
		/**
		 * This will check if an element is bound. 
		 * 
		 * @protected
		 * @param {object} element 
		 * @return {boolean}
		 */
		isDataBound(element) 
		{ 
			if(element)
			{ 
				let id = base.data(element, this.attr); 
				if(id)
				{
					return id; 
				}
			}
			return false; 
		} 
		
		/**
		 * @member {array} blockedKeys
		 * @protected
		 */
		blockedKeys = [
			17, //ctrl 
			9, //tab 
			16, //shift
			18, //alt 
			20, //caps lock 
			37, //arrows 
			38, 
			39, 
			40 
		]; 

		isBlocked(evt)
		{
			if(evt.type !== 'keyup')
			{ 
				return false; 
			}

			/* this will check to block ctrl, shift or alt + 
			buttons */ 
			return (evt.ctrlKey !== false || evt.shiftKey !== false || evt.altKey !== false || base.inArray(this.blockedKeys, evt.keyCode) !== -1);
		}
		
		/**
		 * This is the callBack for the chnage event. 
		 * 
		 * @param {object} evt 
		 */
		bindHandler(evt) 
		{
			if(this.isBlocked(evt))
			{
				return true; 
			}

			let target = evt.target || evt.srcElement,
			id = this.isDataBound(target); 
			if(id)
			{ 
				let connection = this.connections.get(id, 'bind'); 
				if(connection)
				{
					let value = connection.element.get(); 
					/* this will publish to the ui and to the
					model that subscribes to the element */ 
					pubSub.publish(id, value, target);
				} 
			}
			evt.stopPropagation();
		} 

		/* this will setup the on change handler and 
		add the events. this needs to be setup before adding 
		the events. */ 
		changeHandler = null; 

		/**
		 * This wil setup the events. 
		 * @protected
		 */
		setupEvents() 
		{  
			this.changeHandler = base.bind(this, this.bindHandler); 

			this.addEvents();  
		} 

		/**
		 * This will add the events. 
		 */ 
		addEvents() 
		{ 
			base.on(["change", "keyup"], document, this.changeHandler, false); 
		} 

		/**
		 * This will remove the events. 
		 */
		removeEvents() 
		{ 
			base.off(["change", "keyup"], document, this.changeHandler, false);
		}
	} 
	
	base.extend.DataBinder = new DataBinder(); 
})();