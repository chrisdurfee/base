/* base framework module */
(function()
{
	"use strict"; 
	
	/* this will register the route system to the 
	data tracker to remove routes that have been 
	nested in layouts. */ 
	base.DataTracker.addType('routes', (data) =>
	{
		if(!data)
		{
			return false; 
		}
		
		const route = data.route; 
		if(route)
		{
			base.router.removeRoute(route);  
		}
	});
	
	base.DataTracker.addType('switch', (data) =>
	{
		if(!data)
		{
			return false; 
		}
		
		let id = data.id; 
		base.router.removeSwitch(id);
	});
	
	/**
	 * Utils
	 * 
	 * These are some helper functions for the router. 
	 */
	const Utils = 
	{ 
		/**
		 * This will remove the begining and ending slashes from a url. 
		 * 
		 * @param {string} uri 
		 * @return {string}
		 */
		removeSlashes(uri) 
		{ 
			if(typeof uri === 'string') 
			{ 
				if(uri.substr(0, 1) === '/')
				{
					uri = uri.substr(1); 
				}

				if(uri.substr(-1) === '/')
				{
					uri = uri.substr(0, uri.length - 1); 
				}
			} 

			return uri; 
		}
	};
	
	/**
	 * Router
	 * 
	 * This will create a browser router. 
	 * @class 
	 */
	class Router
	{ 
		constructor() 
		{ 
			/**
			 * @member {string} version
			 */
			this.version = '1.0.2'; 

			/* this is the root of the uri for the routing object 
			and the base title */ 
			this.baseURI = '/'; 
			this.title = ''; 
			this.lastPath = null; 

			/* this will be used to access our history object */ 
			this.history = null;
			this.callBackLink = null;
			this.location = window.location;
			
			/* this will store each route added to the 
			router. */ 
			this.routes = [];
			this.switches = {}; 
			this.switchCount = 0; 
			
			/**
			 * @member {object} data
			 */
			this.data = new base.Data(
			{
				path: this.location.pathname
			});    
		}  
		
		/**
		 * This will setup our history object. 
		 */ 
		setupHistory() 
		{ 
			this.history = new History(this);  
			this.history.setup();
		} 
		
		/**
		 * This will create a new route. 
		 * 
		 * @protected
		 * @param {object} settings 
		 * @return {object}
		 */
		createRoute(settings)
		{
			let uri = settings.uri || '*'; 
			settings.baseUri = this.createURI(uri);  
			
			let route = new Route(settings);
			return route; 
		} 
		
		/**
		 * This will add a new route to the router. 
		 * 
		 * @param {object} settings 
		 * @return {object}
		 */ 
		add(settings) 
		{  
			if(typeof settings !== 'object') 
			{ 
				let args = arguments;
				settings = 
				{
					uri: args[0], 
					component: args[1], 
					callBack: args[2], 
					title: args[3], 
					id: args[4],
					container: args[5]
				};
			}
			
			const route = this.createRoute(settings); 
			this.routes.push(route);
			this.checkRoute(route, this.location.pathname);
			return route; 
		} 
		
		/**
		 * This will get the base path. 
		 * 
		 * @protected
		 * @return {string}
		 */
		getBasePath()
		{
			if(!this.basePath)
			{
				let pathURI = this.baseURI || '';  
				if((pathURI[pathURI.length - 1] !== '/'))
				{
					pathURI += '/'; 
				}
				this.basePath = pathURI; 
			}
			return this.basePath; 
		} 
		
		/**
		 * This will create a uri. 
		 * 
		 * @protected
		 * @param {string} uri 
		 * @return {string}
		 */
		createURI(uri) 
		{ 
			let baseUri = this.getBasePath(); 
			return (baseUri + Utils.removeSlashes(uri));  
		} 
		
		/**
		 * This will get a route by uri. 
		 * 
		 * @param {string} uri 
		 * @return {(object|boolean)}
		 */
		getRoute(uri) 
		{ 
			let routes = this.routes, 
			length = routes.length; 
			if(length > 0) 
			{
				for(var i = 0; i < length; i++) 
				{ 
					var route = routes[i]; 
					if(route.uri === uri) 
					{ 
						return route; 
					} 
				} 
			} 
			return false; 
		} 
		
		/**
		 * This will get a route by id. 
		 * 
		 * @param {string} id 
		 * @return {(object|boolean)}
		 */
		getRouteById(id) 
		{ 
			let routes = this.routes, 
			length = routes.length; 
			if(length > 0) 
			{
				for(var i = 0; i < length; i++) 
				{ 
					var route = routes[i]; 
					if(route.id === id) 
					{ 
						return route; 
					} 
				} 
			} 
			return false; 
		} 
		
		/**
		 * This will remove a route. 
		 * 
		 * @param {object} route 
		 */
		removeRoute(route)
		{
			let routes = this.routes,
			index = base.inArray(routes, route); 
			if(index > -1) 
			{ 
				routes.splice(index, 1); 
			}
		} 
		
		/**
		 * This will add a switch. 
		 * 
		 * @param {array} group 
		 * @return {string} the switch id. 
		 */
		addSwitch(group)
		{
			let switches = this.switches,
			id = this.switchCount++,
			switchArray = switches[id] = []; 
			
			for(var i = 0, length = group.length; i < length; i++)
			{
				var route = this.createRoute(group[i]);
				switchArray.push(route); 
			}

			this.checkGroup(switchArray, this.location.pathname);
			return id; 
		} 
		
		/**
		 * This will remove a switch by id. 
		 * 
		 * @param {string} id 
		 */
		removeSwitch(id)
		{
			let switches = this.switches;
			if(switches[id])
			{
				delete switches[id]; 
			}
		}
		
		/**
		 * This will remove a route by uri. 
		 * 
		 * @param {string} uri 
		 * @return {object} a reference to the router object. 
		 */
		remove(uri) 
		{ 
			uri = this.createURI(uri); 
			
			let route = this.getRoute(uri); 
			if(route !== false) 
			{ 
				this.removeRoute(route);  
			} 
			return this;  
		} 
		
		/**
		 * This will setup the router. 
		 * 
		 * @param {string} [baseURI] 
		 * @param {string} [title] 
		 * @return {object} a reference to the router object.
		 */
		setup(baseURI, title) 
		{ 
			this.baseURI = baseURI || '/'; 
			this.title = (typeof title !== 'undefined')? title : '';
			
			this.setupHistory(); 
			
			this.callBackLink = base.bind(this, this.checkLink);
			base.on('click', document, this.callBackLink);
			
			/* this will route to the first url entered 
			when the router loads. this will fix the issue 
			that stopped the first endpoint from being 
			added to the history */ 
			let endPoint = this.getEndPoint(); 
			this.navigate(endPoint, null, true);
			return this;  
		} 
		
		/**
		 * This will get the parent element link. 
		 * 
		 * @param {object} ele 
		 * @return {(object|boolean)}
		 */
		getParentLink(ele)
		{
			let target = ele.parentNode; 
			while(target !== null)
			{ 
				if(target.nodeName.toLowerCase() === 'a')
				{
					return target; 
				} 

				target = target.parentNode; 
			}
			return false; 
		}
		
		/**
		 * This will check if a link was routed. 
		 * 
		 * @protected
		 * @param {object} evt 
		 */
		checkLink(evt)
		{ 
			let target = evt.target || evt.srcElement; 
			if(target.nodeName.toLowerCase() !== 'a')
			{ 
				/* this will check to get the parent to check 
				if the child is contained in a link */ 
				target = this.getParentLink(target); 
				if(target === false)
				{ 
					return true; 
				}
			}

			if(target.target === '_blank' || base.data(target, 'cancel-route'))
			{ 
				return true; 
			}
				
			let href = target.getAttribute('href'); 
			if(typeof href !== 'undefined')
			{ 
				let path = href.replace(this.baseURI, ''); 
				this.navigate(path);

				evt.preventDefault(); 
				evt.stopPropagation();
				return false;
			}
		} 
		
		/**
		 * This will reset the router. 
		 * 
		 * @return {object} a reference to the router object.
		 */
		reset() 
		{ 
			this.routes = []; 
			this.switches = []; 
			this.switchCount = 0;

			return this;  
		} 
		
		/**
		 * This will check the active routes. 
		 * 
		 * @return {object} a reference to the router object.
		 */
		activate() 
		{ 
			this.checkActiveRoutes(); 
			return this;  
		} 
		
		/**
		 * This will navigate the router. 
		 * 
		 * @param {string} uri 
		 * @param {object} [data] 
		 * @param {boolean} [replace] 
		 * @return {object} a reference to the router object.
		 */
		navigate(uri, data, replace) 
		{ 
			uri = this.createURI(uri); 
			this.history.addState(uri, data, replace); 
			this.activate(); 
 
			return this; 
		}  
		
		/**
		 * This will update the data path. 
		 * @protected
		 */
		updatePath()
		{
			let path = this.location.pathname; 
			this.data.set('path', path);
		}
		
		/**
		 * This will update the title. 
		 * 
		 * @protected
		 * @param {object} route 
		 */
		updateTitle(route) 
		{ 
			if(!route || !route.title) 
			{ 
				return this;  
			} 
			
			let getTitle = (title) =>
			{ 
				/* this will uppercase each word in a string
				@param (string) str = the string to uppercase 
				@return (string) the uppercase string */ 
				let toTitleCase = (str) =>
				{
					let pattern = /\w\S*/; 
					return str.replace(pattern, (txt) =>
					{
						return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
					});
				}; 


				/* this will replace the params in the title 
				@param (string) str = the route title 
				@return (string) the title string */ 
				let replaceParams = (str) =>
				{
					if(str.indexOf(':') > -1) 
					{ 
						let params = route.stage; 
						for(var prop in params) 
						{ 
							if(params.hasOwnProperty(prop)) 
							{
								var param = params[prop],
								pattern = new RegExp(':' + prop, 'gi');  
								str = str.replace(pattern, param); 
							}
						} 
					} 
					return str; 
				}; 

				if(title) 
				{  
					/* we want to replace any params in the title 
					and uppercase the title */ 
					title = replaceParams(title);
					let pattern = /-/g; 
					title = toTitleCase(title.replace(pattern, ' ')); 

					/* we want to check to add the base title to the 
					to the end of the title */ 
					if(this.title !== '') 
					{ 
						title += " - " + this.title; 
					}
				} 
				return title; 
			}; 

			let title = route.title;
			document.title = getTitle(title);
		} 
		
		/**
		 * This will check the routes to match the path. 
		 * 
		 * @protected
		 * @param {string} [path] 
		 */
		checkActiveRoutes(path) 
		{ 
			path = path || this.getPath();
			
			let routes = this.routes, 
			length = routes.length; 
				 
			let route; 
			for(var i = 0; i < length; i++) 
			{ 
				route = routes[i]; 
				if(typeof route === 'undefined')
				{ 
					continue; 
				}
					
				this.checkRoute(route, path); 
			} 
			
			this.checkSwitches(path); 
			this.updatePath(); 
		} 
		
		/**
		 * This will check the switches to match the path. 
		 * 
		 * @protected
		 * @param {string} [path] 
		 */
		checkSwitches(path)
		{
			let switches = this.switches; 
			for(var id in switches)
			{
				if(switches.hasOwnProperty(id) === false)
				{
					continue; 
				}
				
				var group = switches[id];
				this.checkGroup(group, path); 
			}
		} 
		
		/**
		 * This will check a group to match a path. 
		 * 
		 * @protected
		 * @param {object} group 
		 * @param {string} path 
		 */
		checkGroup(group, path)
		{
			let check = false, 
			route, firstRoute, lastSelected, selected, hasController = false;
 
			for(var i = 0, length = group.length; i < length; i++) 
			{
				route = group[i]; 
				if(typeof route === 'undefined')
				{ 
					continue; 
				}

				/* we want to save the first route in the switch 
				so it can be selected if no route is active */ 
				if(i === 0)
				{
					firstRoute = route; 
				} 

				if(!lastSelected && route.get('active'))
				{
					lastSelected = route;
				}
				
				if(check !== false)
				{
					if(hasController)
					{
						route.deactivate();
					}
					continue; 
				}

				/* we will break the loop on the first match */ 
				check = route.match(path); 
				if(check !== false) 
				{ 
					selected = route;

					if(route.controller)
					{
						this.select(route);
						hasController = true;
					}
				}
			}

			if(selected === undefined)
			{
				this.select(firstRoute);

				if(lastSelected && firstRoute !== lastSelected)
				{
					lastSelected.deactivate();
				}
			}
			else 
			{
				if(lastSelected)
				{
					if(hasController && selected !== lastSelected)
					{
						lastSelected.deactivate();
					}
				}
				else if(firstRoute && hasController === false)
				{
					this.select(firstRoute);
				}
			}
		} 
		
		/**
		 * This will check if a route matches the path. 
		 * 
		 * @param {object} route 
		 * @param {string} path 
		 * @return {boolean}
		 */
		checkRoute(route, path)
		{
			let check = this.check(route, path); 
			if(check !== false) 
			{ 
				this.select(route); 
			} 
			else 
			{ 
				route.deactivate(); 
			}
			return check; 
		} 
		
		/**
		 * This will select a route if the route matches the path. 
		 * 
		 * @param {object} route 
		 * @param {string} [path] 
		 */
		check(route, path) 
		{ 
			/* we want to check if the route has been 
			deleted from the routes */ 
			if(!route) 
			{ 
				return false; 
			} 
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			path = path || this.getPath(); 
			
			/* we want to check if the route uri matches the path uri */ 
			return (route.match(path) !== false); 
		} 
		
		/**
		 * This will select the route. 
		 * 
		 * @param {object} route 
		 */
		select(route) 
		{ 
			if(!route) 
			{ 
				return false; 
			}
				  
			route.setPath(this.lastPath);
			route.select(); 
			this.updateTitle(route); 
		}  
		
		/**
		 * This will get the endpoint. 
		 * 
		 * @return {string}
		 */
		getEndPoint() 
		{  
			let path = this.getPath(); 
			return (path.replace(this.baseURI, '') || '/');  
		} 

		/**
		 * This will remove the router events. 
		 */
		destroy()
		{
			base.off('click', document, this.callBackLink);
		}  
		
		/**
		 * This will get the location pathname. 
		 * 
		 * @return {string}
		 */
		getPath()
		{ 
			/* we want to get the window location path */  
			let location = this.location, 
			path = this.lastPath = location.pathname; 
			
			return path + location.search + location.hash;  
		}
	} 
	
	let routerNumber = 0;
	
	/**
	 * History
	 * 
	 * This will setup the history controller. 
	 * @class
	 */
	class History 
	{ 
		/**
		 * @constructor
		 * @param {object} router 
		 */
		constructor(router)
		{ 
			this.router = router; 

			/* this will check if the history api is supported 
			and enabled */
			this.enabled = false;
			this.locationId = 'base-app-router-' + routerNumber++; 
			this.callBack = null;
		}  
				
		/**
		 * This will check if the history api is supported
		 * and add events. 
		 * 
		 * @return {object} a reference to the object. 
		 */
		setup() 
		{ 
			/* we want to check if history is enabled */ 
			this.enabled = this.isSupported(); 

			/* we want to check to add the history event listener 
			that will check the popsate events and select the  
			nav option by the history state object */ 
			if(this.enabled !== true) 
			{ 
				return this; 
			}
				  
			this.callBack = base.bind(this, this.check); 
			this.addEvent(); 
			return this; 
		}
		
		/**
		 * This will check if the browser supports the history api. 
		 * 
		 * @return {boolean}
		 */
		isSupported() 
		{ 
			return ('history' in window && 'pushState' in window.history);
		} 

		/**
		 * This will add the events. 
		 * 
		 * @return {object} a reference to the object.
		 */
		addEvent() 
		{   
			base.on('popstate', window, this.callBack);
			return this; 
		} 

		/**
		 * This will remove the events. 
		 * 
		 * @return {object} a reference to the object.
		 */
		removeEvent() 
		{ 
			base.off('popstate', window, this.callBack); 
			return this; 
		} 

		/**
		 * This will check to activate the router. 
		 * 
		 * @param {object} evt 
		 */
		check(evt) 
		{ 
			/* we want to check if the event has a state and if the 
			state location is from the background */ 
			let state = evt.state; 
			if(!state || state.location !== this.locationId) 
			{ 
				return false; 
			}
				  
			evt.preventDefault(); 
			evt.stopPropagation(); 

			this.router.checkActiveRoutes(state.uri);   
		} 

		/**
		 * This will create a state object. 
		 * 
		 * @param {string} uri 
		 * @param {*} data 
		 * @return {object}
		 */
		createState(uri, data) 
		{ 
			let stateObj = { 
				location: this.locationId, 
				uri: uri  
			};  

			if(data && typeof data === 'object') 
			{ 
				stateObj = Object.assign(stateObj, data); 
			} 

			return stateObj; 
		} 

		/**
		 * This will add a state to the history. 
		 * 
		 * @param {string} uri 
		 * @param {object} data 
		 * @param {boolean} replace 
		 * @return {object} a reference to the object.
		 */
		addState(uri, data, replace) 
		{ 
			if(this.enabled !== true) 
			{
				return this; 
			}
				
			let history = window.history, 
			lastState = history.state;   
			
			if(lastState && lastState.uri === uri)
			{
				return this; 
			}

			let stateObj = this.createState(uri, data);

			/* this will check to push state or 
			replace state */ 
			replace = (replace === true); 
			let method = (replace === false)? 'pushState' : 'replaceState'; 
			history[method](stateObj, null, uri); 

			return this; 
		}
	} 
	
	/**
	 * This will setup a route uri pattern. 
	 * 
	 * @param {string} uri 
	 * @return {string}
	 */
	const routePattern = (uri) =>
	{ 
		let uriQuery = ""; 
		if(uri) 
		{ 
			/* we want to setup the wild card and param 
			checks to be modified to the route uri string */ 
			let allowAll = /(\*)/g, 
			param = /(:[^\/?&($]+)/g, 
			optionalParams = /(\?\/+\*?)/g, 
			optionalSlash = /(\/):[^\/(]*?\?/g, 
			filter = /\//g; 
			uriQuery = uri.replace(filter, "\/").replace(allowAll, '.*'); 

			/* this will setup for optional slashes before the optional params */ 
			uriQuery = uriQuery.replace(optionalSlash, (str) =>
			{  
				let pattern = /\//g; 
				return str.replace(pattern, '(?:$|\/)');  
			}); 

			/* this will setup for optional params and params 
			and stop at the last slash or query start */ 
			uriQuery = uriQuery.replace(optionalParams, '?\/*').replace(param, '([^\/|?]+)'); 
		} 

		/* we want to set and string end if the wild card is not set */ 
		uriQuery += (uri[uri.length - 1] === '*')? '' : '$'; 
		return uriQuery;
	}; 
	
	/**
	 * This will get the param keys from the uri. 
	 * 
	 * @param {string} uri 
	 * @return {array}
	 */
	const paramPattern = (uri) =>
	{ 
		let params = []; 
		if(!uri) 
		{ 
			return params; 
		}

		let filter = /[\*?]/g;
		uri = uri.replace(filter, '');
			 
		let pattern = /:(.[^\/?&($]+)\?*/g, 
		matches = uri.match(pattern); 
		if(matches === null) 
		{ 
			return params; 
		}
			 
		for(var i = 0, maxLength = matches.length; i < maxLength; i++) 
		{ 
			var param = matches[i]; 
			if(param) 
			{ 
				param = param.replace(':', ''); 
				params.push(param); 
			} 
		}
		return params;
	}; 
	
	let routeCount = 0; 
	
	/**
	 * Route
	 * 
	 * This will create a route. 
	 * @class
	 * @augments base.SimpleData
	 */
	class Route extends base.SimpleData 
	{ 
		/**
		 * @constructor
		 * @param {object} settings 
		 */
		constructor(settings)
		{  
			this.setupRoute(settings);    
			
			let params = this.getParamDefaults(); 
			super(params); 
			
			this.set('active', false); 
		} 
		
		/**
		 * This will setup the route settings. 
		 * 
		 * @protected
		 * @param {object} settings 
		 */
		setupRoute(settings)
		{
			this.id = settings.id || 'bs-rte-' + routeCount++;
			
			let uri = settings.baseUri; 
			this.uri = uri; 
			this.path = null; 

			/* route reg ex */ 
			let uriMatch = routePattern(uri); 
			this.uriQuery = new RegExp('^' + uriMatch); 

			/* params */ 
			this.paramKeys = paramPattern(uri); 
			this.params = null;

			/* this will setup the template and route component 
			if one has been set */   
			this.setupComponentHelper(settings); 

			this.callBack = settings.callBack;
			this.title = settings.title;
		} 
		
		/**
		 * This will get the default route params. 
		 * 
		 * @return {(object|null)}
		 */
		getParamDefaults()
		{
			let params = this.paramKeys; 
			if(params.length)
			{
				let defaults = {}; 
				for(var i = 0, length = params.length; i < length; i++)
				{
					defaults[params[i]] = null; 
				}
				return defaults; 
			}
			return null; 
		} 
		
		/**
		 * This will deactivate the route. 
		 */
		deactivate()
		{ 
			this.set('active', false);
			
			let controller = this.controller; 
			if(controller)
			{ 
				controller.remove(); 
			}
		}
		
		/**
		 * This will setup the route component. 
		 * 
		 * @protected
		 * @param {object} settings 
		 */
		setupComponentHelper(settings)
		{ 
			if(settings.component)
			{
				let {component, container, persist = false} = settings;

				const helperSettings = 
				{
					component, 
					container, 
					persist
				}; 
				this.controller = new ComponentHelper(this, helperSettings); 
			}
		} 
		
		/**
		 * This will set the route path. 
		 * 
		 * @param {string} path 
		 */
		setPath(path)
		{
			this.path = path; 
		} 
		
		/**
		 * This will select the route. 
		 */
		select()
		{ 
			this.set('active', true);
			
			let params = this.stage,
			callBack = this.callBack; 
			if(typeof callBack === 'function') 
			{ 
				callBack(params); 
			} 

			let controller = this.controller; 
			if(controller)
			{ 
				controller.focus(params); 
			}
		} 
		
		/**
		 * This will check if a route matches the path. 
		 * 
		 * @param {string} path 
		 * @return {(object|boolean)}
		 */
		match(path)
		{
			let matched = false;
			
			/* we want to check to use the supplied uri or get the 
			current uri if not setup */ 
			let result = path.match(this.uriQuery); 
			if(result === null)
			{
				return matched; 
			}
			
			if(result && typeof result === 'object') 
			{   
				/* this will remove the first match from the 
				the params */
				result.shift(); 
				matched = result; 
				/* this will get the uri params of the route 
				and if set will save them to the route */    
				this.setParams(result);
			}

			return matched;
		} 
		
		/**
		 * This will set the params. 
		 * 
		 * @param {object} values 
		 */
		setParams(values)
		{ 
			if(values && typeof values === 'object') 
			{ 
				let keys = this.paramKeys;  
				if(keys) 
				{ 
					let params = {}; 
					for(var i = 0, maxL = keys.length; i < maxL; i++) 
					{ 
						var key = keys[i]; 
						if(typeof key !== 'undefined') 
						{ 
							params[key] = values[i]; 
						} 
					} 
					this.set(params);
				} 
			}
		}
		
		/**
		 * This will get the params. 
		 * 
		 * @return {object}
		 */
		getParams()
		{ 
			return this.stage; 
		}
	} 
	
	/**
	 * ComponentHelper
	 * 
	 * This will create a helper to create and destroy components
	 * that are added to a route. 
	 * @class
	 */
	class ComponentHelper 
	{ 
		/**
		 * @constructor
		 * @param {object} route 
		 * @param {object} settings 
		 */
		constructor(route, settings)
		{ 
			this.route = route; 
			
			this.template = settings.component;
			this.component = null; 
			this.hasTemplate = false; 
			
			this.setup = false; 
			this.container = settings.container; 
			this.persist = settings.persist; 
			
			this.setupTemplate(); 
		} 
		
		/**
		 * This will create the component. 
		 * 
		 * @param {object} params 
		 */
		focus(params)
		{ 
			if(this.setup === false)
			{ 
				this.create();
			}

			this.update(params);
		} 
		
		/**
		 * This will setup the template. 
		 * @protected
		 */
		setupTemplate()
		{
			let template = this.template; 
			if(typeof template === 'string')
			{
				template = this.template = window[template]; 
			} 
			
			let type = typeof template;
			if(type === 'function' || type === 'object')
			{
				if(type === 'object')
				{
					let comp = this.component = this.template;
					comp.route = this.route;
					comp.persist = true;
					this.persist = true;
				}
				
				this.hasTemplate = true; 
			}
		} 
		
		/**
		 * This will create the route component. 
		 * @protected
		 */
		create()
		{ 
			if(!this.hasTemplate)
			{ 
				return false; 
			}
			
			this.setup = true;

			let comp = this.component;
			if(!(this.persist && comp))
			{
				comp = this.component = new this.template({
					route: this.route,
					persist: this.persist
				});
			}

			comp.setup(this.container);
		} 
		
		/**
		 * This will remove the component. 
		 */
		remove()
		{ 
			if(this.setup !== true)
			{ 
				return false; 
			}
				
			this.setup = false;
			
			let component = this.component;
			if(!component)
			{ 
				return false; 
			}
				
			if(typeof component.destroy === 'function')
			{ 
				component.destroy();
			}
			
			// this will remove the reference to the component if persit is false
			if(this.persist === false)
			{
				this.component = null;
			}
		} 
		
		/**
		 * This will call the component update method and pass the params. 
		 * 
		 * @protected
		 * @param {object} params 
		 */
		update(params)
		{ 
			let component = this.component;
			if(!component)
			{ 
				return false; 
			}
			
			if(typeof component.update === 'function')
			{ 
				component.update(params);
			}
		}
	} 

	/**
	 * NavLink
	 * 
	 * This will create a nav link that will add an active 
	 * class when the browser route path matches the link 
	 * href.
	 * 
	 * @class
	 */
	class NavLink extends base.Component
	{
		/**
		 * This will configure the link active class. 
		 * 
		 * @protected
		 */
		beforeSetup()
		{
			this.selectedClass = this.activeClass || 'active'; 
		} 
	
		/**
		 * This will render the component. 
		 * 
		 * @return {object}
		 */
		render()
		{
			let href = this.href, 
			text = this.text,
			watchers = this.setupWatchers(href, text);  
	
			return {
				tag: 'a', 
				className: this.className || null, 
				onState: ['selected', {
					[this.selectedClass]: false
				}],
				href: this.getString(href), 
				text: this.getString(text), 
				children: this.children,
				watch: watchers
			}; 
		}
		
		/**
		 * This will get string. 
		 * 
		 * @param {string} string 
		 * @return {(string|null)}
		 */
		getString(string)
		{
			let type = typeof string;
			return (type !== 'object' && type !== 'undefined')? string : null;
		} 
	
		/**
		 * This will setup the watchers. 
		 * 
		 * @protected
		 * @param {string} href 
		 * @param {string} text 
		 * @return {array}
		 */
		setupWatchers(href, text)
		{
			let exact = (this.exact !== false),
			data = base.router.data; 
	
			let watchers = [
				{
					value: ['[[path]]', data],
					callBack: (ele, value) =>
					{
						let selected = exact? (value === ele.pathname) : (new RegExp(ele.pathname + '($|\/|\\.).*').test(value)); 
						this.update(ele, selected); 
					}
				}
			]; 
	
			if(href && typeof href === 'object')
			{
				watchers.push(
				{
					attr: 'href', 
					value: href
				}); 
			}
	
			if(text && typeof text === 'object')
			{
				watchers.push(
				{
					attr: 'text', 
					value: text
				});
			}
			return watchers; 
		} 
	
		setupStates()
		{
			return {
				selected: false
			}; 
		} 
	
		/**
		 * This will update the class on the element. 
		 * 
		 * @param {object} ele 
		 * @param {bool} selected 
		 */
		update(ele, selected)
		{
			this.state.set('selected', selected); 
		}
	} 
	
	window.NavLink = NavLink;
	
	base.router = new Router(); 
	base.extend.Router = Router; 
})();