/* base framework module */ 
/* 
	css animation add and remove with full object 
	animation tracking 
*/ 
(function() 
{
	"use strict"; 
	
	/**
	 * This will remove a class and hide an element. 
	 * 
	 * @param {object} obj 
	 * @param {string} animationClass 
	 * @param {function} callBack 
	 */
	const removeClassAndHide = (obj, animationClass, callBack) =>
	{  
		obj.style.display = 'none'; 
		removeAnimationClass(obj, animationClass, callBack); 
	}; 
	
	/**
	 * This will remove a class when the animation is finished. 
	 * 
	 * @param {object} obj 
	 * @param {string} animationClass 
	 * @param {function} callBack 
	 */
	const removeAnimationClass = (obj, animationClass, callBack) =>
	{ 
		if(typeof callBack === 'function') 
		{ 
			callBack.call(); 
		}
		
		base.removeClass(obj, animationClass); 
		base.animate.animating.remove(obj);   
	};
	
	const getElement = (element) =>
	{ 
		return (typeof element === 'string')? document.getElementById(element) : element;
	}; 
	
	/* this will add and remove css animations */ 
	base.extend.animate = 
	{ 
		/* this class tracks all objects being animated and can 
		add and remove them when completed */  
		animating: 
		{ 
			objects: [],  
			
			add(object, className, timer) 
			{ 
				if(!object) 
				{ 
					return false; 
				}
				
				this.stopPreviousAnimations(object); 
				this.objects.push({ 
					object, 
					className, 
					timer 
				});  
			}, 
			
			remove(object, removeClass) 
			{ 
				if(!object) 
				{ 
					return false; 
				}
					  
				let animations = this.checkAnimating(object); 
				if(animations === false) 
				{ 
					return false; 
				}

				let animation, indexNumber,
				objects = this.objects;
				for(var i = 0, maxLength = animations.length; i < maxLength; i++) 
				{ 
					animation = animations[i]; 
					/* we want to stop the timer */ 
					this.stopTimer(animation); 

					if(removeClass) 
					{ 
						/* we want to remove the className */ 
						base.removeClass(animation.object, animation.className); 
					}

					/* we want to remove the animation fron the object array */ 
					//var indexNumber = this.objects.indexOf(animation); 
					indexNumber = objects.indexOf(animation);
					if(indexNumber > -1) 
					{ 
						objects.splice(indexNumber, 1); 
					}
				} 
			}, 
			
			stopTimer(animation) 
			{ 
				if(animation) 
				{ 
					let timer = animation.timer; 
					window.clearTimeout(timer); 
				}
			}, 
			
			checkAnimating(obj) 
			{ 
				let animation, 
				animationArray = []; 
				
				/* we want to get any timers set for our object */ 
				let objects = this.objects; 
				for(var i = 0, maxLength = objects.length; i < maxLength; i++) 
				{ 
					animation = objects[i]; 
					if(animation.object === obj) 
					{ 
						animationArray.push(animation); 
					} 
				} 
				
				return (animationArray.length > 0)? animationArray : false;  
			}, 
			
			stopPreviousAnimations(obj) 
			{ 
				/* we want to remove the timers and class names 
				from the object */ 
				this.remove(obj, 1);   
			}, 
			
			reset() 
			{ 
				this.objects = [];   
			}
		}, 
		
		create(obj, animationClass, duration, callBack, endCallBack)
		{ 
			let animationCallBack = base.createCallBack(null, callBack, [obj, animationClass, endCallBack]);
			
			let timer = window.setTimeout(animationCallBack, duration); 
			this.animating.add(obj, animationClass, timer);
		}, 
		
		/* this will perform an animation on the object and 
		then turn the object to display none after the 
		duration */  
		hide(object, animationClass, duration, endCallBack)
		{ 
			let obj = getElement(object); 
			base.addClass(obj, animationClass);     
			
			this.create(obj, animationClass, duration, removeClassAndHide, endCallBack); 
		}, 
		
		/* this will dsiplay the object then perform an animation 
		on the object and remove the class after the duration */ 
		show(object, animationClass, duration, endCallBack)
		{ 
			let obj = getElement(object); 
			base.addClass(obj, animationClass); 
			obj.style.display = 'block'; 
			
			this.create(obj, animationClass, duration, removeAnimationClass, endCallBack);
		},  
		
		/* this will add an animation class on the object then 
		it will remove the class when the duration is done */ 
		set(object, animationClass, duration, endCallBack)
		{ 
			let obj = getElement(object); 
			base.addClass(obj, animationClass);   
			
			this.create(obj, animationClass, duration, removeAnimationClass, endCallBack);
		} 
	}; 
})();